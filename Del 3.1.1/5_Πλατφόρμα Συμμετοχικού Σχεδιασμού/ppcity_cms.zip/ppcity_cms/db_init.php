#!/usr/bin/env php
<?php
define('ABSPATH', __DIR__ . '/app/');

require_once ABSPATH . 'config.php';
require_once ABSPATH . 'includes/ORM/db_conn.php';

use ORM\DbConn;
$db = new DbConn($db_credentials);

if (!empty($argv[1]) && $argv[1]=='admin') {
	$data = ['role' => 'admin'];
	echo "Give below a user name and a password for the administrator." . PHP_EOL;
	echo "User name: ";
	$data['username'] = trim(fgets(STDIN));
	echo "Password: ";
	$pass = trim(fgets(STDIN));
	$data['password'] = password_hash($pass, PASSWORD_DEFAULT);
	$data['uuid'] = uuid();
	$data['active'] = true;

	$db->schema('core')
	   ->table('users')
	   ->insert($data);

	$db->exec("
		CREATE OR REPLACE FUNCTION actions.notify() RETURNS trigger AS $$
		DECLARE
		BEGIN
			PERFORM pg_notify('emails',CAST(NEW.id as text));
			RETURN NEW;
		END;
		$$ LANGUAGE plpgsql;
	");
	$db->exec('CREATE TRIGGER notifications AFTER INSERT ON actions.email FOR EACH ROW EXECUTE PROCEDURE actions.notify();');
	$db->exec('CREATE TRIGGER notifications_update AFTER UPDATE ON actions.email FOR EACH ROW EXECUTE PROCEDURE actions.notify();');
	die('Admin user created.' . PHP_EOL);
}

$clean = (!empty($argv[1]) && $argv[1]=='clean');

echo ($clean) ? 'Cleaning schemas...' : 'Creating schemas...';

// $extension = $clean ? 'DROP EXTENSION IF EXISTS postgis' : 'CREATE EXTENSION IF NOT EXISTS postgis';
// $db->exec($extension);
if ($clean) {
	$db->exec('DROP TRIGGER IF EXISTS notifications ON actions.email;');
	$db->exec('DROP FUNCTION IF EXISTS actions.notify() CASCADE;');
}

$schemas = ['core', 'app', 'plugins', 'actions'];
foreach ($schemas as $schema) {
	echo PHP_EOL . "	$schema";
	if ($clean) {
		$db->schema($schema)
		   ->cascade()
		   ->drop();
		$db->table('phinxlog')
		   ->drop();
	} else {
		$db->schema($schema)
		   ->authorization()
		   ->create();
	}
}
$custom_types = [
	'app.token_scope' => ["'project'", "'variable'", "'location'", "'property'", "'correlation'"],
];
foreach ($custom_types as $type => $values) {
	if (!$clean) {
		try {
			$db->type($type)
			   ->enum($values)
			   ->create();
		} catch (PDOException $e) {
			if (strpos($e->getMessage(), "Duplicate object") === false)
				throw $e;
		}
	}
}

echo PHP_EOL . ' ok.' . PHP_EOL;

echo PHP_EOL;