#!/usr/bin/env php
<?php

define('ABSPATH', __DIR__ . '/app/');

require_once ABSPATH . 'config.php';
require_once ABSPATH . 'includes/ORM/db_conn.php';
require_once ABSPATH . 'includes/PHPMailer/index.php';

use PHPMailer\PHPMailer\Email;

use ORM\DbConn;
$db = new DbConn($db_credentials);
$email = new Email;
$email = $email->setDefaults();

checkForUnsent($db, $email);

$db->exec('LISTEN emails');

while (true) {
	ob_start();
	$result = $db->pgsqlGetNotify(\PDO::FETCH_ASSOC, 300000);

	switch ($result['message']) {
		case 'emails':
			$details = $db->table('actions.email')
						  ->where(['id' => $result['payload']])
						  ->fetch('row')[0];
			if (!$details->sent && $details->retries < 4)
				send($db, $email, $details);
			break;
	}
	$output = ob_get_contents();
	ob_end_clean();
	if (!empty($output))
		file_put_contents(ABSPATH . '../logs/listener.log', $output);
}

function send($db, $email, $details) {
	$comment = $email->to($details->address)
					 ->subject($details->subject)
					 ->body($details->body)
					 ->send();
	$sql = $db->table('actions.email')
			  ->where(['id' => $details->id]);
	if (empty($comment)) {
		$sql->update(['sent' => 'true']);
	} else {
		$sql->update([
			'retries' => $details->retries + 1,
			'comment' => $comment
		]);
	}
}

function checkForUnsent($db, $email)
{
	$unset = $db->table('actions.email')
				->boolean('AND')
				->where(['sent' => 'false'])
				->where(['retries' => 4], '<')
				->select();

	foreach ($unset as $details) {
		ob_start();
		send($db, $email, $details);
		$output = ob_get_contents();
		ob_end_clean();
		if (!empty($output))
			file_put_contents(ABSPATH . '../logs/listener.log', $output);
	}
}
