<?php


use Phinx\Migration\AbstractMigration;

class Users extends AbstractMigration
{
	/**
	 * Change Method.
	 *
	 * Write your reversible migrations using this method.
	 *
	 * More information on writing migrations is available here:
	 * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
	 *
	 * The following commands can be used in this method and Phinx will
	 * automatically reverse them when rolling back:
	 *
	 *    createTable
	 *    renameTable
	 *    addColumn
	 *    addCustomColumn
	 *    renameColumn
	 *    addIndex
	 *    addForeignKey
	 *
	 * Any other distructive changes will result in an error when trying to
	 * rollback the migration.
	 *
	 * Remember to call "create()" or "update()" and NOT "save()" when working
	 * with the Table class.
	 */
	public function change()
	{
			$users = $this->table('core.users');
			$users->addColumn('username', 'string', ['limit' => 20])
				  ->addColumn('uuid', 'uuid')
				  ->addColumn('password', 'string', ['limit' => 255, 'null' => true])
				  ->addColumn('role', 'string', ['limit' => 20, 'default' => 'guest'])
				  ->addColumn('email', 'string', ['limit' => 100, 'null' => true])
				  ->addColumn('firstname', 'string', ['limit' => 30, 'null' => true])
				  ->addColumn('lastname', 'string', ['limit' => 30, 'null' => true])
				  ->addColumn('created', 'datetime', ['default' => 'CURRENT_TIMESTAMP'])
				  ->addColumn('last_login', 'datetime', ['null' => true])
				  ->addColumn('active', 'boolean', ['default' => false])
				  ->addColumn('password_reset', 'boolean', ['default' => false])
				  ->addIndex(['username'], ['unique' => true])
				  ->addIndex(['uuid'], ['unique' => true])
				  ->create();
	}
}
