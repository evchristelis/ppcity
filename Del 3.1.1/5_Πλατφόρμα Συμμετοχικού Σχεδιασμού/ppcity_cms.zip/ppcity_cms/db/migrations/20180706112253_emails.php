<?php


use Phinx\Migration\AbstractMigration;

class Emails extends AbstractMigration
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    addCustomColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Any other distructive changes will result in an error when trying to
     * rollback the migration.
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $email = $this->table('actions.email');
        $email->addColumn('address', 'string', ['limit' => 60])
              ->addColumn('subject', 'string', ['limit' => 255])
              ->addColumn('body', 'text', ['default' => ''])
              ->addColumn('created', 'datetime', ['default' => 'CURRENT_TIMESTAMP'])
              ->addColumn('attachment', 'string', ['limit' => 255, 'null' => true])
              ->addColumn('sent', 'boolean', ['default' => false])
              ->addColumn('retries', 'integer', ['default' => 0])
              ->addColumn('comment', 'string', ['limit' => 255, 'default' => ''])
              ->addColumn('sent_time', 'datetime', ['null' => true, 'default' => null])
              ->create();
    }
}
