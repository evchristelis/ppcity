<?php


use Phinx\Migration\AbstractMigration;

class UserInfo extends AbstractMigration
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    addCustomColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Any other distructive changes will result in an error when trying to
     * rollback the migration.
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $user_info = $this->table('core.user_info');
        $user_info->addColumn('uuid', 'uuid')
                  ->addColumn('phone', 'string', ['limit' => 55, 'null' => true])
                  ->addColumn('vat', 'string', ['limit' => 15, 'null' => true])
                  ->addColumn('amka', 'string', ['limit' => 15, 'null' => true])
                  ->addColumn('address', 'string', ['limit' => 1023, 'null' => true])
                  ->addColumn('zip', 'string', ['limit' => 15, 'null' => true])
                  ->addColumn('area', 'string', ['limit' => 55, 'null' => true])
                  ->addForeignKey('uuid', 'core.users', 'uuid', ['delete' => 'CASCADE', 'update' => 'CASCADE'])
                  ->create();
    }
}
