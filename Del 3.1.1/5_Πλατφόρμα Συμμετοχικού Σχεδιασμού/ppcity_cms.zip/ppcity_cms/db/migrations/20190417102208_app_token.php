<?php


use Phinx\Migration\AbstractMigration;
use Phinx\Util\Literal;

class AppToken extends AbstractMigration
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    addCustomColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Any other destructive changes will result in an error when trying to
     * rollback the migration.
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $token = $this->table('app.token', ['id' => false, 'primary_key' => 'id']);
        $token->addColumn('id', 'biginteger', ['limit' => 20, 'identity' => true])
              ->addColumn('uuid', 'uuid')
              ->addColumn('token', 'string', ['limit' => 255])
              ->addColumn('scope',  Literal::from('app.token_scope'))
              ->addColumn('created', 'datetime', ['default' => 'CURRENT_TIMESTAMP'])
              ->addColumn('owner', 'uuid', ['null' => true])
              ->addIndex(['uuid', 'scope'], ['unique' => true])
              ->addIndex(['token', 'scope'], ['unique' => true])
              ->addForeignKey('owner', 'core.users', 'uuid', ['delete' => 'SET_NULL', 'update' => 'CASCADE'])
              ->create();
    }
}
