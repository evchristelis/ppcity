<?php
namespace Api;
use \ErrorException, \Exception, Api\Requests\ValidationException, Api\Requests\RequestsException;
use \ReflectionClass;

header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require_once dirname(__FILE__, 2) . "/load.php";

require_once ABSPATH . 'includes/model/index.php';
require_once ABSPATH . 'includes/requests/index.php';
global $db;

try {
	if (!empty($_GET['params'])) {
		$params = parseURL($_GET['params']);
		unset($_GET['params']);
		$_GET = array_merge($_GET, $params);
	}
	$xhr = new XHR();
} catch (Exception $e) {
	die( json_encode(['Error' => $e->getMessage()]) );
}

if ( !class_exists('Api\\Requests\\' . $xhr->action) ) {
	http_response_code(404);
	$reply = ['Error' => 'Action not found.'];
} else {
	try {
		set_error_handler(function($errno, $errstr, $errfile, $errline ){
			throw new ErrorException($errstr, $errno, 0, $errfile, $errline);
		});
		$request= "\\Api\\Requests\\{$xhr->action}";
		//  Check if class is abstract:
		$reflection = new ReflectionClass($request);
		if ($reflection->isAbstract())
			throw new RequestsException('Action not found.', 404);
		$action = new $request($xhr->method);
		$action->data = $xhr->data;
		$action->params = $xhr->params;
		$reply = $action->execute();
	} catch (RequestsException $e) {
		http_response_code($e->getCode());
		$reply = ['Error' => $e->getMessage()];
	} catch (ValidationException $e) {
		$http_code = $e->getCode()=='5' ? 409 : 400;
		http_response_code($http_code);
		$reply = ['Error' => $e->getMessage()];
	} catch (ErrorException $e) {
		http_response_code(500);
		$msg = ENV=='production' ? "An unknown problem occurred." : $e->getMessage();
		error_log($e);
		$reply = ['Error' => $msg];
	} catch (Exception $e) {
		http_response_code(500);
		$msg = ENV=='production' ? "An unknown problem occurred." : $e->getMessage();
		error_log($e);
		$reply = ['Error' => $msg];
	}
}

die(json_encode($reply));
