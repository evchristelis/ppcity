<?php
namespace Api\Model;
use \stdClass;
defined( 'ABSPATH' ) or die( 'Sorry, direct access is forbidden.' );

/**
 * The users model class
 */
class Users
{

	const table = 'core.users';
	const limited = true;

	/** @var array Determines which fields are required on insert */
	public static $required = [
		'username',
		'role',
		'email',
		'firstname',
		'lastname'
	];

	/** @var array Specifies the unique indexes */
	public static $index = [
		'username',
		'uuid'
	];

	/** @var array Determines which fields would be visible on a list */
	public static $visible = [
		'uuid',
		'username',
		'firstname',
		'lastname',
		'email',
		'role',
		'created',
		'active'
	];

	/** @var array Determines which fields are searchable */
	public static $searchable = [
		'username',
		'firstname',
		'lastname',
		'email'
	];

	public function __construct()
	{
		$this->username = new stdClass();
		$this->username->type = 'string';
		$this->username->min_size = 8;
		$this->username->max_size = 20;
		$this->username->unique = true;
		$this->username->validation = '[a-z0-9\_\-\.]+';
		$this->username->message = 'A username could consist of lowercase latin characters, numeric digits, underscore (_), dash (-) and period (.) only.';

		$this->uuid =new stdClass();
		$this->uuid->type = 'string';

		$this->password = new stdClass();
		$this->password->type = 'string';
		$this->password->min_size = 8;
		$this->password->max_size = 20;
		$this->password->validation = '[A-Za-z0-9\_\!\$\@\#\^\&]+';
		$this->password->message = 'A password could contain latin characters, numeric digits and the symbols _!$@#^&.';

		$this->role = new stdClass();
		$this->role->type = 'string';

		$this->email = new stdClass();
		$this->email->type = 'string';
		$this->email->validation = '(?:[a-z0-9!#$%&\'*+=?^_`{|}~-]+(?:\.[a-z0-9!#$%&\'*+=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])';
		$this->email->message = 'Please provide a valid email address.';

		$this->firstname = new stdClass();
		$this->firstname->type = 'string';
		$this->firstname->min_size = 3;
		$this->firstname->max_size = 30;
		$this->firstname->validation = '[^0-9]+';
		$this->firstname->message = 'The name could contain only characters.';

		$this->lastname = new stdClass();
		$this->lastname->type = 'string';
		$this->lastname->min_size = 2;
		$this->lastname->max_size = 30;
		$this->lastname->validation = '[^0-9]+';
		$this->lastname->message = 'The name could contain only characters.';

		$this->active = new stdClass();
		$this->active->type = 'boolean';

		$this->password_reset = new stdClass();
		$this->password_reset->type = 'boolean';
	}
}