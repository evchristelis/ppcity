<?php
namespace Api\Model;
use \stdClass;
defined( 'ABSPATH' ) or die( 'Sorry, direct access is forbidden.' );

/**
 * The users model class
 */
class Email
{

	const table = 'actions.email';
	const limited = true;

	/** @var array Determines which fields are required on insert */
	public static $required = [
		'address',
		'subject',
		'body'
	];

	/** @var array Specifies the unique indexes */
	public static $index = [];

	public $data;

	public function __construct()
	{
		$this->data = [];

		$this->address = new stdClass();
		$this->address->type = 'string';
		$this->address->max_size = 60;

		$this->subject = new stdClass();
		$this->subject->type = 'string';
		$this->subject->max_size = 255;

		$this->attachment = new stdClass();
		$this->attachment->type = 'string';
		$this->attachment->max_size = 255;

		$this->body = new stdClass();
		$this->body->type = 'string';
	}

	/**
	 * Set who the message is to be sent to.
	 * @param  string $email The recipient's email address
	 * @param  string $name  The recipient's full name
	 * @return $this
	 */
	public function address(string $email, string $name='')
	{
		$this->data['address'] = $email;
		return $this;
	}

	/**
	 * Set the subject line.
	 * @param  string $subject The email subject
	 * @return $this
	 */
	public function subject(string $subject)
	{
		$this->data['subject'] = $subject;
		return $this;
	}

	/**
	 * Set the email HTML body and its alternative plain text.
	 * @param  string $html The HTML body
	 * @return $this
	 */
	public function body(string $html)
	{
		$this->data['body'] = $html;
		return $this;
	}

	/**
	 * Set an attached file
	 * @param  string $file The path to the file to be attached
	 * @return $this
	 */
	public function attachment(string $file)
	{
		$this->data['attachment'] = $file;
		return $this;
	}

	/**
	 * Send the message, checking and rethrowing errors.
	 * @return void
	 */
	public function send()
	{
		global $db;
		$db->table(self::table)
		   ->insert($this->data);
	}

}