<?php
namespace Api\Model;
use \stdClass;
defined ( 'ABSPATH' ) or die( 'Sorry, direct access is forbidden.' );

/**
 * The notifications model class
 */
class Notifications
{
	const table = 'actions.notifications';
	const limited = true;

	/** @var array Determines which fields are required on insert */
	public static $required = [
		'user_uuid',
		'body',
	];

	/** @var array Specifies the unique indexes */
	public static $index = [];

	/** @var array Determines which fields would be visible on a list */
	public static $visible = [
		'body',
		'read',
		'created',
		'date_read',
		'id'
	];

	/** @var array Determines which fields are searchable */
	public static $searchable = [];

	function __construct()
	{
		$this->scope = new stdClass();
		$this->scope->type = 'string';
		$this->scope->max_size = 55;

		$this->uuid = new stdClass();
		$this->uuid->type = 'uuid';

		$this->user = new stdClass();
		$this->user->type = 'uuid';

		$this->body = new stdClass();
		$this->body->type = 'string';
		$this->body->max_size = 1023;

		$this->read = new stdClass();
		$this->read->type = 'boolean';

		$this->created = new stdClass();
		$this->created->type = 'datetime';

		$this->date_read = new stdClass();
		$this->date_read->type = 'datetime';
	}
}
