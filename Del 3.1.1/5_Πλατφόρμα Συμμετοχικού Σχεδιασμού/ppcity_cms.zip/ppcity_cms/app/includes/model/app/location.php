<?php
namespace Api\Model;
use \stdClass;
defined( 'ABSPATH' ) or die( 'Sorry, direct access is forbidden.' );

class Location
{
	const table = 'app.location';

	public static $required = [
	];

	public static $primary = 'uuid';

	public static $index = [];

	public static $visible = [];

	public function __construct()
	{
		$this->uuid = new stdClass();
		$this->uuid->type = 'uuid';

		$this->point = new stdClass();
		$this->point->type = 'geom';

		$this->line = new stdClass();
		$this->line->type = 'geom';

		$this->polygon = new stdClass();
		$this->polygon->type = 'geom';
	}
}
