<?php
namespace Api\Model;
use \stdClass;
defined( 'ABSPATH' ) or die( 'Sorry, direct access is forbidden.' );

class Metadata
{
	const table = 'app.metadata';

	public static $required = [
		'correlation'
	];

	public static $primary = 'uuid';

	public static $index = [];

	public static $visible = [
		'correlation',
		'image',
		'link',
		'file'
	];

	public function __construct()
	{
		$this->correlation = new stdClass();
		$this->correlation->type = 'uuid';
		$this->correlation->foreign_key = [Correlation::table => 'uuid'];

		$this->image = new stdClass();
		$this->image->type = 'string';
		$this->image->max_size = 255;

		$this->link = new stdClass();
		$this->link->type = 'string';
		$this->link->max_size = 255;

		$this->file = new stdClass();
		$this->file->type = 'string';
		$this->file->max_size = 255;
	}
}
