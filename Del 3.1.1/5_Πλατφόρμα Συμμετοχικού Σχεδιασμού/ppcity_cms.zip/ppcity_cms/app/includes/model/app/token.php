<?php
namespace Api\Model;
use \stdClass;
defined( 'ABSPATH' ) or die( 'Sorry, direct access is forbidden.' );

class AppToken
{
	const table = 'app.token';

	public static $required = [
		'uuid',
		'token',
		'scope'
	];

	public static $index = [];

	public function __construct()
	{
		$this->uuid = new stdClass();
		$this->uuid->type = 'uuid';

		$this->token = new stdClass();
		$this->token->type = 'string';
		$this->token->max_size = 255;

		$this->scope = new stdClass();
		$this->scope->type = 'string';
		$this->scope->validation = 'place|thing|location|sensor|property|datastream|aggregation|service';
		$this->scope->message = 'Please provide a valid scope for the token.';

		$this->owner = new stdClass();
		$this->owner->type = 'uuid';
	}
}
