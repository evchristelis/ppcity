<?php
namespace Api\Model;
use \stdClass;
defined( 'ABSPATH' ) or die( 'Sorry, direct access is forbidden.' );

class Project
{
	const table = 'app.project';

	public static $required = [
		'label',
	];

	public static $primary = 'uuid';

	public static $index = [];

	public static $visible = [
		'label',
		'description',
		'json',
		'created'
	];

	public function __construct()
	{
		$this->uuid = new stdClass();
		$this->uuid->type = 'uuid';

		$this->label = new stdClass();
		$this->label->type = 'string';
		$this->label->max_size = 255;

		$this->description = new stdClass();
		$this->description->type = 'string';

		$this->properties = new stdClass();
		$this->properties->type = 'json';

		$this->created = new stdClass();
		$this->created->type = 'datetime';
	}
}
