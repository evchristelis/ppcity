<?php
namespace Api\Model;
use \stdClass;
defined( 'ABSPATH' ) or die( 'Sorry, direct access is forbidden.' );

class Variable
{
	const table = 'app.variable';

	public static $required = [
		'name',
		'depth'
	];

	public static $primary = 'uuid';

	public static $index = [];

	public static $visible = [
		'name',
		'description',
		'depth'
	];

	public function __construct()
	{
		$this->uuid = new stdClass();
		$this->uuid->type = 'uuid';

		$this->name = new stdClass();
		$this->name->type = 'string';
		$this->name->max_size = 255;

		$this->description = new stdClass();
		$this->description->type = 'string';

		$this->depth = new stdClass();
		$this->depth->type = 'number';
	}
}
