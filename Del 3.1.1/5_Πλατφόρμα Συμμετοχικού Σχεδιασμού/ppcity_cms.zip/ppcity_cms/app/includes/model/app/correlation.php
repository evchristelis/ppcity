<?php
namespace Api\Model;
use \stdClass;
defined( 'ABSPATH' ) or die( 'Sorry, direct access is forbidden.' );

class Correlation
{
	const table = 'app.correlation';

	public static $required = [
		'project',
		'variable',
	];

	public static $primary = 'uuid';

	public static $index = [];

	public static $visible = [
		'project',
		'variable',
		'parent',
		'location'
	];

	public function __construct()
	{
		$this->uuid = new stdClass();
		$this->uuid->type = 'uuid';

		$this->project = new stdClass();
		$this->project->type = 'uuid';
		$this->project->foreign_key = [Project::table => 'uuid'];

		$this->variable = new stdClass();
		$this->variable->type = 'uuid';
		$this->variable->foreign_key = [Variable::table => 'uuid'];

		$this->parent = new stdClass();
		$this->parent->type = 'uuid';

		$this->location = new stdClass();
		$this->location->type = 'uuid';
		$this->location->foreign_key = [Location::table => 'uuid'];
	}
}
