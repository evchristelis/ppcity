<?php
namespace Api\Model;
use \stdClass;
defined( 'ABSPATH' ) or die( 'Sorry, direct access is forbidden.' );

class Property
{
	const table = 'app.property';

	public static $required = [
		'correlation',
		'type'
	];

	public static $primary = 'uuid';

	public static $index = [];

	public static $visible = [
		'correlation',
		'type',
		'options'
	];

	public function __construct()
	{
		$this->correlation = new stdClass();
		$this->correlation->type = 'uuid';
		$this->correlation->foreign_key = [Correlation::table => 'uuid'];

		$this->type = new stdClass();
		$this->type->type = 'string';
		$this->type->max_size = 55;

		$this->options = new stdClass();
		$this->options->type = 'json';

	}
}
