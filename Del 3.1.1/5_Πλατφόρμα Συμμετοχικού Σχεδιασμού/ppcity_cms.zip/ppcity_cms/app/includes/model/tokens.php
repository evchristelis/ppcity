<?php
namespace Api\Model;
use \stdClass;
defined ( 'ABSPATH' ) or die( 'Sorry, direct access is forbidden.' );

/**
 * The tokens model class
 */
class Tokens
{
	const table = 'core.tokens';
	const limited = false;

	/** @var array Determines which fields are required on insert */
	public static $required = [
		'uuid',
		'token',
		'scope',
		'created'
	];

	/** @var array Specifies the unique indexes */
	public static $index = [
		'uuid',
		'scope',
	];

	/** @var array Determines which fields would be visible on a list */
	public static $visible = [];

	/** @var array Determines which fields are searchable */
	public static $searchable = [];

	public function __construct()
	{
		$this->uuid = new stdClass();
		$this->uuid->type = 'uuid';

		$this->token = new stdClass();
		$this->token->type = 'string';
		$this->token->max_size = 256;

		$this->scope = new stdClass();
		$this->scope->type = 'string';
		$this->scope->max_size = 55;

		$this->created = new stdClass();
		$this->created->type = 'date';
	}
}