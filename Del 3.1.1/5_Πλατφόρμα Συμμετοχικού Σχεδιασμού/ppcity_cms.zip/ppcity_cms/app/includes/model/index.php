<?php
/**
 * An index file to load the contained model files.
 */
defined( 'ABSPATH' ) or die( 'Sorry, direct access is forbidden.' );

foreach (glob(dirname(__FILE__) . "/*.php") as $filename) {
	require_once $filename;
}

foreach (glob(dirname(__FILE__) . "/*/*.php") as $filename) {
	require_once $filename;
}
