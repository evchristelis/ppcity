<?php
namespace Api\Model;
use \stdClass;
defined( 'ABSPATH' ) or die( 'Sorry, direct access is forbidden.' );

/**
 * The template model class
 */
class Template
{

	const table = 'core.template';
	const limited = false;

	/** @var array Determines which fields are required on insert */
	public static $required = [
		'type',
		'html',
		'subject'
	];

	/** @var array Specifies the unique indexes */
	public static $index = [
		'type'
	];

	public static $visible = [
		'type',
		'html',
		'subject'
	];

	public function __construct()
	{
		$this->type = new stdClass();
		$this->type->type = 'string';
		$this->type->max_size = 55;

		$this->html = new stdClass();
		$this->html->type = 'text';
		$this->html->min_size = 3;

		$this->subject = new stdClass();
		$this->subject->type = 'string';
		$this->subject->min_size = 4;
		$this->subject->max_size = 255;
	}

}