<?php
namespace Api\Model;
use \stdClass;
defined ( 'ABSPATH' ) or die( 'Sorry, direct access is forbidden.' );
require_once ABSPATH . 'includes/model/users.php';

/**
 * The additional user details model class
 */
class UserInfo extends Users
{
	const secondary_table = 'core.user_info';
	const limited = false;

	public static $join = [
		'core.user_info' => ['uuid' => 'uuid']
	];

	/** @var array Specifies the unique indexes */
	public static $index = [
		'uuid',
	];

	/** @var array Determines which fields would be visible on a list */
	public static $visible = [
		parent::table . '.uuid',
		'username',
		'role',
		'created',
		'last_login',
		'firstname',
		'lastname',
		'email',
		'phone',
		'vat',
		'amka',
		'address',
		'zip',
		'area',
		'active',
	];

	public static $fields = [
		'phone',
		'vat',
		'amka',
		'address',
		'zip',
		'area',
	];

	/** @var array Determines which fields are searchable */
	public static $searchable = [
	];

	function __construct()
	{
		$this->phone = new stdClass();
		$this->phone->type = 'string';
		$this->phone->min_size = 10;
		$this->phone->max_size = 17;
		$this->phone->validation = '[0-9\ \(\)\+]+';
		$this->phone->message = 'Please provide a valid phone number.';

		$this->vat = new stdClass();
		$this->vat->type = 'string';
		$this->vat->validation = '[0-9]{9}';
		$this->vat->message = 'Please provide a valid greek VAT.';

		$this->amka = new stdClass();
		$this->amka->type = 'string';
		$this->amka->validation = '[0-9]{11}';
		$this->amka->message = 'Please provide a valid AMKA.';

		$this->address = new stdClass();
		$this->address->type = 'string';
		$this->address->max_size = 1023;

		$this->zip = new stdClass();
		$this->zip->type = 'string';
		$this->zip->validation = '[0-9]{5}';
		$this->zip->message = 'Please provide a valid ZIP without spaces.';

		$this->area = new stdClass();
		$this->area->type = 'string';
		$this->area->max_size = 55;

		parent::__construct();
	}
}