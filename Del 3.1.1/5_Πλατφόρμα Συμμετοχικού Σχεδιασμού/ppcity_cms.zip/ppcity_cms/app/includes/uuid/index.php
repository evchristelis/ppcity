<?php
require_once dirname(__FILE__, 3) . "/load.php";

global $session;

if ($_GET['action'] == 'templates') {
	if (empty($session->user) || array_search($session->user->role, ['admin', 'editor', 'reviewer']) === false)
		return null;
	$file = DATA_PATH . '/templates/' . $_GET['filename'];
} else {
	$file = isset($_GET['uuid'])
		? DATA_PATH . '/' . $_GET['action'] . '/' . $_GET['uuid'] . '/' . $_GET['application'] . '/'
		: DATA_PATH . '/' . $_GET['action'] . '/';
	$file .= !empty($_GET['subpath']) ? $_GET['subpath'] . '/' . $_GET['filename'] : $_GET['filename'];
}

header('Content-Description: File Transfer');
header('Expires: 0');
header('Content-Type: ' . mime_content_type($file));
header('Cache-Control: must-revalidate');
header('Pragma: public');
header('Content-Length: ' . filesize($file));

readfile($file);
