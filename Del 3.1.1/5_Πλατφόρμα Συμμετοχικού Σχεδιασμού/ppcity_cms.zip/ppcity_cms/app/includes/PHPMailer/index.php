<?php
namespace PHPMailer\PHPMailer;
use \Exception;

foreach (glob(dirname(__FILE__) . "/*.php") as $filename) {
	require_once $filename;
}

/**
 * Wrapper class for PHPMailer
 */
class Email extends PHPMailer
{

	/**
	 * Set basic default configuration for PHPMailer.
	 */
	public function __construct()
	{
		$this->isSMTP();
		$this->SMTPDebug = ENV=='production' ? 0 : 2;
	}

	/**
	 * Set the hostname of the email server.
	 * @param  string $host The hostname of the email server
	 * @return $this
	 */
	public function host(string $host)
	{
		$this->Host = $host;
		return $this;
	}

	/**
	 * Set the SMTP port number - 587 for authenticated TLS, a.k.a. RFC4409 SMTP submission.
	 * @param  integer $port The SMTP port number
	 * @return $this
	 */
	public function port(integer $port)
	{
		$this->Port = $port;
		return $this;
	}

	/**
	 * Set the encryption system to use - ssl (deprecated) or tls.
	 * @param string $SMTPSecure The encryption system
	 * @return void
	 */
	public function SMTPSecure(string $SMTPSecure)
	{
		$this->SMTPSecure = $SMTPSecure;
		return $this;
	}

	/**
	 * Set whether to use SMTP authentication.
	 * @param bool $SMTPAuth Whether to use SMTP authentication
	 * @return $this
	 */
	public function SMTPAuth(bool $SMTPAuth)
	{
		$this->SMTPAuth = $SMTPAuth;
		return $this;
	}

	/**
	 * Username to use for SMTP authentication - use full email address for gmail.
	 * @param  string $username The SMTP authentication username.
	 * @return $this
	 */
	public function username(string $username)
	{
		$this->Username = $username;
		return $this;
	}

	/**
	 * Password to use for SMTP authentication.
	 * @param  string $password SMPT password
	 * @return $this
	 */
	public function password(string $password)
	{
		$this->Password = $password;
		return $this;
	}

	/**
	 * Set who the message is to be sent from.
	 * @param string $email The sender's email address
	 * @param string $name  The sender's full name
	 * @param bool   $auto  Whether to also set the Sender address, defaults to true
	 * @return $this
	 */
	public function setFrom($email, $name='', $auto=true)
	{
		parent::setFrom($email, $name, $auto);
		return $this;
	}

	/**
	 * Set an alternative reply-to address.
	 * @param string $email The alternative reply email
	 * @param string $name  The alternative reply full name
	 * @return $this
	 */
	public function addReplyTo($email, $name='')
	{
		parent::addReplyTo($email, $name);
		return $this;
	}

	/**
	 * Set who the message is to be sent to.
	 * @param  strin $email The recipient's email address
	 * @param  string $name  The recipient's full name
	 * @return $this
	 */
	public function to(string $email, string $name='')
	{
		parent::clearAddresses();
		parent::addAddress($email, $name);
		return $this;
	}

	/**
	 * Set the subject line.
	 * @param  string $subject The email subject
	 * @return $this
	 */
	public function subject(string $subject)
	{
		$this->Subject = $subject;
		return $this;
	}

	/**
	 * Set the email HTML body and its alternative plain text.
	 * @param  string $html The HTML body
	 * @return $this
	 */
	public function body(string $html)
	{
		parent::msgHTML($html);
		$this->AltBody = strip_tags($html);
		return $this;
	}

	/**
	 * Set an attached file
	 * @param  string $file The path to the file to be attached
	 * @return $this
	 */
	public function attachment(string $file)
	{
		parent::addAttachment($file);
		return $this;
	}

	/**
	 * Send the message, checking and rethrowing errors.
	 * @return void
	 */
	public function send()
	{
		parent::send();
		return $this->ErrorInfo;
		// if (!parent::send()) {
		// 	throw new Exception("Mailer Error: " . $this->ErrorInfo);
		// }
	}

	/**
	 * Set the default sending values.
	 * @return $this
	 */
	public function setDefaults()
	{
		$this->CharSet  = 'UTF-8';
		$this->Host = 'smtp.gmail.com';
		$this->Port = 587;
		$this->SMTPSecure = 'tls';
		$this->SMTPAuth = true;
		$this->Username = "pmitropoulos@getmap.gr";
		$this->Password = "f4xe*@D9";
		parent::setFrom('pmitropoulos@getmap.gr', 'Pantelis Mitropoulos');

		return $this;
	}
}

// function sendMail($body) {

// 	//Create a new PHPMailer instance
// 	// $mail = new PHPMailer;
// 	//Tell PHPMailer to use SMTP
// 	// $mail->isSMTP();
// 	//Enable SMTP debugging
// 	// 0 = off (for production use)
// 	// 1 = client messages
// 	// 2 = client and server messages
// 	// $mail->SMTPDebug = 2;
// 	//Set the hostname of the mail server
// 	$mail->Host = 'smtp.gmail.com';
// 	// use
// 	// $mail->Host = gethostbyname('smtp.gmail.com');
// 	// if your network does not support SMTP over IPv6
// 	//Set the SMTP port number - 587 for authenticated TLS, a.k.a. RFC4409 SMTP submission
// 	$mail->Port = 587;
// 	//Set the encryption system to use - ssl (deprecated) or tls
// 	$mail->SMTPSecure = 'tls';
// 	//Whether to use SMTP authentication
// 	$mail->SMTPAuth = true;
// 	//Username to use for SMTP authentication - use full email address for gmail
// 	$mail->Username = "pantelismitr@gmail.com";
// 	//Password to use for SMTP authentication
// 	$mail->Password = "rub*79=3!";
// 	//Set who the message is to be sent from
// 	$mail->setFrom('pantelismitr@gmail.com', 'First Last');
// 	//Set an alternative reply-to address
// 	$mail->addReplyTo('replyto@example.com', 'First Last');
// 	//Set who the message is to be sent to
// 	$mail->addAddress('pantelismitr@yahoo.com', 'Pantelis Mitropoulos');
// 	//Set the subject line
// 	$mail->Subject = 'PHPMailer GMail SMTP test';
// 	//Read an HTML message body from an external file, convert referenced images to embedded,
// 	//convert HTML into a basic plain-text alternative body
// 	$mail->msgHTML('Hello!');
// 	//Replace the plain text body with one created manually
// 	$mail->AltBody = 'This is a plain-text message body';
// 	//Attach an image file
// 	$mail->addAttachment('images/phpmailer_mini.png');
// 	//send the message, check for errors
// 	if (!$mail->send()) {
// 		throw new Exception("Mailer Error: " . $mail->ErrorInfo);
// 	}

// }
