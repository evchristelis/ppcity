<?php
	require_once dirname(__FILE__, 2) . "/load.php";
	require_once ABSPATH . 'includes/model/index.php';
	use Api\Model\Users, Api\Model\Tokens;
	global $db;
	$html = file_get_contents(ABSPATH . '../frontend/build/index.html');
	$pos = strpos($html, '</head>');
	$html = substr($html, 0, $pos + 7);
	$token = $_GET['token'];
	$action = $_GET['action'];
	$fields = ['activation' => 'active', 'recovery' => 'password_reset'];
	$uuid = $db->table(Tokens::table)
			   ->fields('uuid')
			   ->where(['token' => $token, 'scope' => $action])
			   ->fetch('value');
	if (!empty($uuid)) {
		$active = $db->table(Users::table)
					 ->fields($fields[$action])
					 ->where(['uuid' => $uuid])
					 ->fetch('value');
		$active = $action=='recovery' ? !$active : $active;
		$username = $db->table(Users::table)
					   ->fields('username')
					   ->where(['uuid' => $uuid])
					   ->fetch('value');
		// Check if password has been defined
		$pass_exists = true;
		if ($action == 'activation') {
			$pass_exists = $db->table(Users::table)
					   ->fields('password')
					   ->where(['uuid' => $uuid])
					   ->fetch('value');
			$pass_exists = !empty($pass_exists);
		}
	}
	if (empty($uuid) || !$username || $active)
		header("Location: /error/404", true, 301);
	if (isset($_POST['username'])) {
		$exceptionOccured = false;
		try {
			if ($action == 'activation') {
				$activated = ($username == $_POST['username']);
				$values = ($pass_exists) ? ['active' => 'true'] : ['active' => 'true', 'password' => password_hash($_POST['password'], PASSWORD_DEFAULT)];
				if ($activated)
					$db->table(Users::table)
					   ->where(['uuid' => $uuid])
					   ->update($values);
			} else {
				$changed = ($username == $_POST['username']);
				if ($changed) {
					$db->table(Users::table)
					   ->where(['uuid' => $uuid])
					   ->update(['password' => password_hash($_POST['password'], PASSWORD_DEFAULT), 'password_reset' => 'false']);
				}
			}
			if ((isset($activated) && $activated) || (isset($changed) && $changed))
				$db->table(Tokens::table)
				   ->where(['uuid' => $uuid, 'scope' => $action])
				   ->delete();
		} catch (Exception $e) {
			$exceptionOccured = true;
		}
	}
?>

<?= $html; ?>

	<body class="app header-fixed sidebar-fixed">
		<div class="app flex-row align-items-center">
			<div class="container">
				<div class="justify-content-center row">
					<div class="col col-sm-12 col-md-8 col-lg-6">
						<div class="card-group">
							<div class="text-white bg-primary card">
								<div class="card-body">
									<h1><?= $action=='activation' ? 'Ενεργοποίηση Λογαριασμού' : 'Αλλαγή κωδικού πρόσβασης';?></h1>
									<?php if (isset($activated)): ?>
										<?= $activated ? 'Ο λογαριασμός σας ενεργοποιήθηκε.' : 'Το όνομα χρήστη που εισάγατε δεν ταυτοποιήθηκε.'; ?>
									<?php elseif (isset($changed)): ?>
										<?= $changed ? 'Ο κωδικός σας άλλαξε.' : 'Το όνομα χρήστη που εισάγατε δεν ταυτοποιήθηκε.'; ?>
									<?php elseif ($exceptionOccured === true): ?>
										'Εμφανίστηκε κάποιο σφάλμα. Παρακαλούμε δοκιμάστε ξανά.'
									<?php else: ?>
										<form method="POST">
											<label class="w-100">
												Εισάγετε το όνομα χρήστη με το οποίο πραγματοποιήσατε την εγγραφή:<br/>
												<div class="mb-3 input-group">
													<div class="input-group-prepend mt-2">
														<span class="input-group-text">
															<i class="icon-user"></i>
														</span>
													</div>
													<input class="w-75 mt-2 p-2" name="username" type="text" focus maxlength="255" autocomplete="off" />
												</div>
											</label>
											<?php if ($action=='recovery' || !$pass_exists): ?>
												<br/>
												<label class="w-100">
													Εισάγετε τον νέο κωδικό πρόσβασης που θέλετε να χρησιμοποιήσετε:<br/>
													<div class="mb-3 input-group">
														<div class="input-group-prepend mt-2">
															<span class="input-group-text">
																<i class="icon-key"></i>
															</span>
														</div>
														<input class="w-75 mt-2 p-2" id="password" name="password" type="password" maxlength="255" onkeyup="return checkPasswords(event);" />
													</div>
												</label>
												<br/>
												<label class="w-100">
													Επιβεβαιώστε ότι γράψατε σωστά τον κωδικό:<br/>
													<div class="mb-3 input-group">
														<div class="input-group-prepend mt-2">
															<span class="input-group-text">
																<i class="icon-key"></i>
															</span>
														</div>
														<input class="w-75 mt-2 p-2" id="password_repeat" name="password-repeat" type="password" maxlength="255" onkeyup="return checkPasswords(event);" />
													</div>
												</label>
												<br/>
											<?php endif; ?>
											<div class="row">
												<div class="col-9 col-md-8 col-lg-8"></div>
												<div class="text-right col-3 col-md-4 col-lg-4">
													<button id="submit_button" class="btn btn-success" type="submit" <?= ($action=='activation' && $pass_exists) ? '' : 'disabled';?>>Ενεργοποίηση</button>
												</div>
											</div>
										</form>
									<?php endif; ?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>

<script type="text/javascript">
	function checkPasswords(e) {
		var password = document.getElementById('password').value;
		var password_repeat = document.getElementById('password_repeat').value;
		document.getElementById('submit_button').disabled = (password != password_repeat);
	}
</script>