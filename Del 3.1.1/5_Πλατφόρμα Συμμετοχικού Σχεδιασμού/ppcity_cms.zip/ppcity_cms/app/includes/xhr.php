<?php
namespace Api;
use \Exception;
defined( 'ABSPATH' ) or die( 'Sorry, direct access is forbidden.' );

class XHR {
	public $status;
	public $data;
	public $action;
	public $params;

	public function __construct()
	{
		global $session;
		$this->method = $_SERVER['REQUEST_METHOD'];
		if (isset($session)) {
			$token = isset(getallheaders()['X-Csrf-Token']) ? getallheaders()['X-Csrf-Token'] : @getallheaders()['x-csrf-token'];
			// if ($this->method == 'GET') {
				$this->status = true;
			// } else {
			// 	$this->status = !empty($token) ? hash_equals($session->token, $token) : false;
			// }
		} else {
			$this->status = false;
		}

		if ($this->status) {
			$this->data = json_decode(file_get_contents("php://input"));
			$this->params = (object)$_GET;
			if (property_exists($this->params, 'action')) {
				$this->action = $this->params->action;
				unset($this->params->action);
			} else {
				throw new Exception("No action sent.");
			}
			if (array_search($this->method, ['GET', 'PUT', 'DELETE', 'POST']) === false) {
				http_response_code(405);
				header("Allow: GET, POST, DELETE, PUT");
				throw new Exception('Unrecognized HTTP method.');
			}
		} else {
			http_response_code(401);
			throw new Exception('Sorry, access is forbidden.');
		}
	}

}
