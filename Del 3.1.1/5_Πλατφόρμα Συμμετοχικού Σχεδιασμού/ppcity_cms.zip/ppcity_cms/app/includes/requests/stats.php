<?php
namespace Api\Requests;
use \Exception, \stdClass;
use Api\Model\Application, Api\Model\Node, Api\Model\Users, Api\Model\Workflow;

defined( 'ABSPATH' ) or die( 'Sorry, direct access is forbidden.' );

/**
 * Gives back statistical info about users, applications...
 */
class Stats extends Requests
{
	/**
	 * Define the application model.
	 * @param string $method The HTTP request method
	 */
	public function __construct($method)
	{
		parent::__construct($method);
	}

	/**
	 * Get method.
	 * @return array The requested results
	 */
	public function get()
	{
		global $session;
		$output = [];
		if ($session->user->role == 'admin') {
			$users = new stdClass();
			$users->total = $this->db->table(Users::table)
									 ->count();

			$users->status = [];
			foreach (['active', 'inactive'] as $status) {
				$active = ($status=='active') ? 'true' : 'false';
				$users->status[$status] = $this->db->table(Users::table)
												   ->where(['active' => $active])
												   ->count();
			}
			$users->role = [];
			foreach (['admin', 'editor', 'reviewer', 'guest'] as $role) {
				$users->role[$role] = $this->db->table(Users::table)
											   ->where(['role' => $role, 'active' => true])
											   ->count();
			}
			$output['users'] = $users;
		}

		return $output;
	}
}