<?php
namespace Api\Requests;
use \session;
use Api\Model\UserInfo;

defined( 'ABSPATH' ) or die( 'Sorry, direct access is forbidden.' );

/**
 * The login class
 */
class Login extends Requests
{
	/**
	 * The GET request is used to write the cookie.
	 * @return array
	 */
	function get()
	{
		return ['loggedin' => false];
	}
	/**
	 * The login method.
	 * @param  object $data A stdClass object which should contain the username and the password
	 * @return array
	 */
	function post($data)
	{
		global $session;
		if (empty($data->username) || empty($data->password)) {
			$loggedin = !empty($session->user->username);
			return ['loggedin' => $loggedin];
		}
		$sql = $this->db->table(UserInfo::table)
						->fields('password')
						->where(['username' => $data->username, 'active' => true]);
		$pass = $sql->fetch('value');

		$loggedin = password_verify($data->password, $pass);
		if ($loggedin) {
			$user = $sql->fields(UserInfo::$visible)->join(UserInfo::$join)->fetch();
			$GLOBALS['session'] = new session($user);
		}

		return ['loggedin' => $loggedin];
	}

	/**
	 * The logout method.
	 * @return array
	 */
	function delete()
	{
		global $session;

		if (empty($session->user))
			die('No active session');

		$session->user = '';
		return ['loggedin' => false];
	}
}