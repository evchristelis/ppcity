<?php
namespace Api\Requests;
use \Exception;
use Api\Model\Notifications as NotificationsPattern;
use Api\Model\Users, Api\Model\Application, Api\Model\NotificationMessages;

defined( 'ABSPATH' ) or die( 'Sorry, direct access is forbidden.' );

/**
 * The Notifications class
 */
class Notifications extends Requests
{

	/**
	 * Define the notifications model.
	 * @param string $method The HTTP request method
	 */
	public function __construct($method)
	{
		$this->pattern = new NotificationsPattern();
		parent::__construct($method);
	}

	/**
	 * Get method.
	 * @return array The requested results
	 */
	public function get()
	{
		global $session;
		if (empty($session->user))
			return [];

		if (!empty($this->params->count)) {
			if ( array_search($this->params->count, ['read', 'unread']) === false )
				throw new RequestsException('Bad request', 400);
			return $this->db->table(['notifications' => NotificationsPattern::table])
							->where(['notifications.user' => $session->user->uuid, 'read' => $this->params->count=='read'])
							->count();
		}

		$this->params->fq = "user:{$session->user->uuid}";
		$this->params->sort = "created";
		$this->params->sort_method = "desc";
		return parent::list();
	}

	/**
	 * Mark messages as read and send the appropriate receipts.
	 * @param  arrat $data An array containing the ids of the messages
	 *                     to be marked as read
	 * @return void
	 */
	public function post($data)
	{
		global $session;

		if (empty($data))
			return;

		try {
			$this->db->beginTransaction();
			$this->db->table(NotificationsPattern::table)
					 ->where(['id' => $data])
					 ->update(['read' => true]);
			$this->db->commit();
		} catch (Exception $e) {
			$this->db->rollback();
			throw $e;
		}
	}

}
