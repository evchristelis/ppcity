<?php
namespace Api\Requests;
use Api\Model\Users, Api\Model\UserInfo;

defined( 'ABSPATH' ) or die( 'Sorry, direct access is forbidden.' );

/**
 * The profile class
 */
class Profile extends Requests
{

	/**
	 * Define the Users model.
	 * @param string $method The HTTP request method
	 */
	public function __construct($method)
	{
		$this->pattern = new UserInfo();
		parent::__construct($method);
	}

	/**
	 * Retrieve the logged in user profile.
	 * @return object A stdClass object with the logged in user details.
	 */
	function get()
	{
		global $session;
		$this->updateLastLoginInfo($session->user->uuid);
		return $session->user;
	}

	/**
	 * Update details from the profile of the logged in user.
	 * @return object A stdClass object with the updated logged in user details.
	 */
	function put($data)
	{
		global $session;
		if (!empty($data->role) && $session->user->role != 'admin')
			throw new RequestsException('Action not allowed', 402);
		$this->params = (object)[
			// 'action' => $this->params->action,
			'uuid' => $session->user->uuid
		];

		try {
			$reply = parent::update($data);
			$session->update();
		} catch (Exception $e) {
			throw $e;
		}
		return $reply;
	}

	function updateLastLoginInfo($uuid)
	{
		$this->db->table(Users::table)
				 ->where(['uuid' => $uuid])
				 ->update(['last_login' => date('Y-m-d H:i:s')]);
	}
}