<?php
namespace Api\Requests;
use Api\Model\Node, Api\Model\NodeChilds, Api\Model\Graph, Api\Model\PdfTemplates,
	Api\Model\Workflow, Api\Model\NodePermissions, Api\Model\RegisterFields, Api\Model\Template,
	Api\Model\FormBody, Api\Model\Form, Api\Model\NotificationMessages;

defined( 'ABSPATH' ) or die( 'Sorry, direct access is forbidden.' );

/**
 * A collection of requests for various administrative tasks.
 */
class Admin extends Requests
{
	private $request;

	/**
	 * Define the model depending on the request.
	 * @param string $method The HTTP request method
	 */
	public function __construct($method)
	{
		$this->request = $_GET['request'];
		unset($_GET['request']);
		switch ($this->request) {
			case 'forms':
				$this->pattern = empty($_GET['form']) ? new Form() : new FormBody();
				break;
			case 'nodes':
				$this->pattern = new Node();
				break;

			case 'tree':
				$this->pattern = new NodeChilds();
				break;

			case 'graph':
				$this->pattern = new Graph();
				break;

			case 'workflows':
				$this->pattern = new Workflow();
				break;

			case 'permissions':
				$this->pattern = new NodePermissions();
				break;

			case 'check_sanity':
				break;

			case 'notifications':
				$this->pattern = new NotificationMessages();
				break;

			case 'register_fields':
				$this->pattern = new RegisterFields();
				break;

			case 'reindex_db':
			case 'public_upload':
			case 'fieldlist';
				$this->pattern = null;
				break;

			case 'pdftemplate':
				$this->pattern = new PdfTemplates();
				break;

			case 'template':
				$this->pattern = new Template();
				break;

			default:
				throw new RequestsException('Action not found.', 404);
				break;
		}
		parent::__construct($method);
	}

	/**
	 * Get method.
	 * @return array The requested results
	 */
	public function get()
	{
		switch ($this->request) {
			case 'forms':
			case 'graph':
			case 'permissions':
			case 'notifications':
			case 'register_fields':
				if (isset($this->params->form))
					$this->params->sort = 'sequence';
				$list = parent::list();
				break;

			case 'nodes':
				$list = parent::list();
				if (property_exists($this->params, 'mname')) {
					$list->options = json_decode($list->options);
				} else {
					if (!is_array($list))
						$list = [$list];
				}
				break;

			case 'tree':
				$this->fields[Node::table] = array_keys(get_object_vars(new Node()));
				$list = parent::list();
				break;

			case 'workflows':
				$this->params->fields = array_keys(get_object_vars($this->pattern));
				$list = parent::list();
				break;

			case 'reindex_db':
				$list = $this->db->sqlFunction('app.reindex')
								 ->select();
				break;

			case 'pdftemplate':
			case 'template':
				$list = parent::list();
				$list = (is_array($list) && sizeof($list)==0) ? ['html' => null] : $list;
				break;

			/**
			 * Returns all the fields for each form defined in the platform
			 * or, in case a workflow is specified, all the fields for each
			 * form associated with thiw workflow.
			 */
			case 'fieldlist':
				$transform = function($value) {
					$value->fields = json_decode($value->fields);
					return $value;
				};
				$list = $this->db->table(Form::table)
								 ->fields(['mname', Form::table.'.label'])
								 ->aggregate('json_object_agg', [FormBody::table.'.name', FormBody::table.'.label ORDER BY ' . FormBody::table.'.sequence'], 'fields')
								 ->join([FormBody::table => ['mname' => 'form']]);
				if (!empty($this->params->workflow)) {
					$workflow = $this->params->workflow;
					$workflows = $this->db->table(Node::table)
										  ->fields('workflow_content')
										  ->join([NodeChilds::table => ['mname' => 'node']], 'FULL OUTER')
										  ->where([Node::table.'.workflow' => $workflow, 'type' => 'workflow'])
										  ->where([NodeChilds::table.'.node' => null], '!=')
										  ->fetch('column');
					$workflows[] = $workflow;
					$forms = $this->db->table(Node::table)
									  ->fields(['form' => 'content'])
									  ->join([NodeChilds::table => ['mname' => 'node']], 'FULL OUTER')
									  ->where([Node::table.'.workflow' => $workflows, 'type' => 'form'])
									  ->where([NodeChilds::table.'.node' => null], '!=')
									  ->fetch('column');
					if (empty($forms)) {
						$list = [];
						break;
					}
					$list = $list->where(['mname' => $forms]);
				}
				$list = $list->where([FormBody::table.'.type' => ['radio', 'number', 'string', 'select', 'text', 'checkbox', 'map']])
							 ->orderBy(Form::table.'.label')
							 ->groupBy(['mname', Form::table.'.label'])
							 ->groupById()
							 ->select();
				$list = array_map($transform, $list);
				break;

			default:
				throw new RequestsException('Method not supported.', 404);
		}

		return $list;
	}

	public function put($data)
	{
		$return = false;
		switch ($this->request) {
			case 'forms':
				if (!empty($this->params->form)) {
					if (!empty($this->params->id)) {
						if (!empty($data->options)) {
							$options = $data->options;
							$data->options = [];
							foreach ($options->keys as $index => $key) {
								$data->options[$key] = $options->values[$index];
							}
							$data->options = json_encode($data->options);
						}
						$return = parent::update($data);
					} else {
						try {
							$this->db->beginTransaction();
							foreach ($data as $name => $sequence) {
								$this->db->table($this->pattern::table)
										 ->where(['form' => $this->params->form, 'name' => $name])
										 ->update(['sequence' => $sequence]);
							}
							$this->db->commit();
							$return = true;
						} catch (Exception $e) {
							throw $e;
						}
					}
				} else {
					$return = parent::update($data);
				}
				break;
			case 'nodes':
				$data->workflow = $this->params->workflow;
				if (!empty($data->type)) {
					if ($data->type == 'form') {
						$data->content_text = $data->options = $data->transition = $data->workflow_content = null;
					} else if ($data->type == 'workflow') {
						$data->content = $data->options = $data->transition = null;
					} else if ($data->type == 'transition') {
						$data->content = $data->options = $data->workflow_content = null;
					} else if ($data->type == 'register') {
						$data->content = $data->options = $data->transition  = $data->workflow_content= null;
					}
				}
				if (!empty($data->options))
					$data->options = json_encode($data->options);
				$return = parent::update($data);
				break;

			case 'tree':
				try {
					$this->db->beginTransaction();
					foreach ($data as $index => $values) {
						// Check whether the two nodes belong in the same workflow
						$workflow = $this->db->table(Node::table)
											 ->fields('workflow')
											 ->boolean('OR')
											 ->where(['mname' => $values->node])
											 ->where(['mname' => $values->child])
											 ->unique()
											 ->fetch('column');
						if (sizeof($workflow) != 1) {
							throw new RequestsException("Parent and child nodes belong to different workspaces", 402);
						} else {
							$workflow = $workflow[0];
						}
						$where = [
							'node' => $values->node,
							'value' => empty($values->value) ? '' : $values->value
						];
						if ( $this->db->table(NodeChilds::table)
									  ->where($where)
									  ->exists() ) {
							if (!empty($values->child)) {
								$this->db->table(NodeChilds::table)
										 ->where($where)
										 ->update(['child' => "{$values->child}"]);
							} else {
								$this->db->table(NodeChilds::table)
										 ->where($where)
										 ->delete();
							}
						} else {
							if (!empty($values->child))
								parent::insert($values);
						}
					}
					$this->db->commit();
				} catch (Exception $e) {
					throw $e;
				}
				$valid = $this->checkSanity($workflow);
				$this->db->table(Workflow::table)
						 ->where(['mname' => $workflow])
						 ->update(['valid' => $valid]);
				$return = ['valid' => $valid];
				break;

			case 'graph':
				try {
					$this->db->beginTransaction();
					foreach ($data as $index => $values) {
						if ( $this->db->table(Graph::table)
									  ->where(['node' => $values->node])
									  ->exists() ) {
							$this->db->table(Graph::table)
									 ->where(['node' => $values->node])
									 ->update(['pos_x' => $values->pos_x, 'pos_y' => $values->pos_y]);
						} else {
							parent::insert($values);
						}
					}
					$this->db->commit();
				} catch (Exception $e) {
					throw $e;
				}
				$return = true;
				break;

			case 'workflows':
			case 'pdftemplate':
			case 'template':
				$return = parent::update($data);
				break;

			case 'permissions':
				try {
					$this->db->beginTransaction();
					foreach ($data as $values) {
						$this->db->table(NodePermissions::table)
								 ->where(['node' => $this->params->node, 'role' => $values->role])
								 ->update(['read' => $values->read, 'write' => $values->write]);
					}
					$this->db->commit();
				} catch (Exception $e) {
					throw $e;
				}
				break;

			case 'notifications':
				try {
					$this->db->beginTransaction();
						foreach ($data as $scope => $current) {
							foreach ($current as $role => $values) {
								$this->db->table(NotificationMessages::table)
										 ->where(['scope' => $scope, 'role' => $role])
										 ->update($values);
							}
						}
					$this->db->commit();
				} catch (Exception $e) {
					throw $e;
				}
				break;

			default:
				throw new RequestsException('Method not supported.', 404);
		}

		return $return;
	}

	public function post($data)
	{
		$return = false;
		switch ($this->request) {
			case 'forms':
				if (!empty($this->params->form))
					$data->form = $this->params->form;
				if (!empty($data->options)) {
					$options = $data->options;
					$data->options = [];
					foreach ($options->keys as $index => $key) {
						$data->options[$key] = $options->values[$index];
					}
					$data->options = json_encode($data->options);
				} else if (!empty($this->params->form)) {
					$data->options = null;
				}
				$return = parent::insert($data);
				break;
			case 'nodes':
				$data->workflow = $this->params->workflow;
				if ($data->options !== '')
					$data->options = json_encode($data->options);
				foreach ($this->pattern::$nulls as $key) {
					if (empty($data->$key) || $data->$key == '')
						$data->$key = null;
				}
				$return = parent::insert($data);
				break;

			case 'permissions':
				try {
					$this->db->beginTransaction();
					foreach ($data as $values) {
						$values->node = $this->params->node;
						parent::insert($values);
					}
					$this->db->commit();
				} catch (Exception $e) {
					throw $e;
				}
				$return = true;
			break;

			case 'workflows':
			case 'pdftemplate':
			case 'template':
				return parent::insert($data);
				break;

			case 'register_fields':
				$ids = [];
				try {
					$this->db->beginTransaction();
					foreach ($data as $id => $values) {
						if ($id > 0) {
							$this->params->id = $id;
							parent::update($values);
						} else {
							$ids[] = parent::insert($values);
						}
					}
					$this->db->commit();
				} catch (Exception $e) {
					$this->db->rollback();
					throw $e;
				}
				$return = $ids;
				break;

			case 'public_upload':
				if (empty($_FILES))
					throw new RequestsException("No file to upload.", 400);
				$path = DATA_PATH . '/public/';
				$path .= isset($this->params->path) ? $this->params->path . '/' : '';
				if (!is_dir($path))
					mkdir($path);
				foreach ($_FILES as $file) {
					$filename = $path . basename($file['name']);
					if ( move_uploaded_file($file['tmp_name'], $filename ) ) {
						$location = basename($filename);
					} else {
						throw new RequestsException("Resource not accepted.", 406);
					}
				}

				$return = isset($this->params->path) ? "/data/public/{$this->params->path}/$location" : "/data/public/$location";
				break;

			default:
				throw new RequestsException('Method not supported.', 404);
		}

		return $return;
	}

	public function delete()
	{
		$return = false;
		switch ($this->request) {
			case 'forms':
			case 'register_fields':
			case 'template':
				$return = parent::remove();
				break;

			default:
				throw new RequestsException('Method not supported.', 404);
		}

		return $return;
	}

	private function checkSanity($workflow)
	{
		try {
			$node = Application::findParent($workflow, $this->db);
			$nodes = Application::findEndPoints($workflow, $this->db);
			$connections = Application::checkConnections($workflow, $this->db);
			return true;
		} catch (RequestsException $e) {
			return false;
		}
	}

}
