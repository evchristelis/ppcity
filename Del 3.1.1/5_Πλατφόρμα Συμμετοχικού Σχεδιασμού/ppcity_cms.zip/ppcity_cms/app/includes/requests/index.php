<?php
/**
 * Includes all the request classes and defines the abstract Requests class.
 */
namespace Api\Requests;
use \PDOException, \Exception, \stdClass;

defined( 'ABSPATH' ) or die( 'Sorry, direct access is forbidden.' );

foreach (glob(dirname(__FILE__) . "/*.php") as $filename) {
	require_once $filename;
}

foreach (glob(dirname(__FILE__) . "/*/index.php") as $filename) {
	require_once $filename;
}

/**
 * The requests abstract class
 */
abstract class Requests
{
	/** @var string The HTTP method */
	protected $method;
	/** @var PDO The PDO connection object */
	protected $db;
	/** @var object The posted data */
	protected $data;
	/** @var object The parameters included in the request URI */
	protected $params;
	/** @var object The object describing the correspondent model */
	protected $pattern;
	protected $table;
	protected $fields;

	/**
	 * A static variable defining the priviliges for each combination of request type and method.
	 * @var array
	 */
	private static $priviliges = [
		'login' => [
			'delete' => 'authorized'
		],
		'profile' => [
			'get' => 'authorized',
			'put' => 'authorized',
		],
		'users' => [
			'get' => ['admin', 'editor', 'reviewer'],
			'put' => ['admin', 'editor', 'reviewer'],
			'delete' => ['admin', 'editor', 'reviewer']
		],
		'registration' => [
			'post' => ''
		],
		'test' => [
			'get' => 'admin',
			'post' => 'admin'
		],
		'application' => [
			'get' => 'authorized',
			'put' => 'authorized',
			'post' => 'authorized',
			'delete' => 'authorized'
		],
		'upload' => [
			'put' => 'authorized',
			'post' => 'authorized',
			'delete' => 'authorized'
		],
		'locations' => [
			'get' => 'authorized'
		],
		'stats' => [
			'get' => ['admin', 'editor', 'reviewer']
		],
		'admin' => [
			'get' => 'admin',
		],
		'applicationfiles' => [
			'get' => ['admin', 'editor', 'reviewer']
		],
		'fullsearch' => [
			'get' => ['admin', 'editor', 'reviewer']
		],
		'parsepdf' => [
			'get' => 'authorized'
		],
		'apply' => [
			'get' => 'authorized',
			'put' => 'authorized',
			'post' => 'authorized',
			'delete' => 'authorized'
		],
		'createpdf' => [
			'get' => 'authorized',
		],
	];

	/**
	 * The class contruction method.
	 *
	 * During the class construction, it is also checked whether the appropriate
	 * privileges are satisfied. If not, a Request Exception is thrown with the
	 * corresponding http response code.
	 *
	 * @param string $method The HTTP request method
	 */
	public function __construct(string $method)
	{
		global $db, $session;
		$this->method = $method;
		$this->db = $db;
		$className = strtolower(substr(strrchr(get_class($this), "\\"), 1));
		$role = isset(self::$priviliges[$className][strtolower($method)])
			? self::$priviliges[$className][strtolower($method)]
			: '';
		if (!empty($role)) {
			if ($role == 'authorized') {
				if (empty($session->user))
					throw new RequestsException("Access denied.", 401);
			} else if (!hasRole($role)) {
				throw new RequestsException("Access denied.", 403);
			}
		}
		if (isset($this->pattern)) {
			$this->table = isset($this->pattern->table) ? $this->pattern->table : $this->pattern::table;
			$this->fields = [$this->table => array_keys(get_object_vars($this->pattern))];
		}
	}

	/**
	 * Setter function for data and params.
	 * @param string $name  One of 'data' or 'params'
	 * @param mixed $value  The values of the corresponding parameter
	 * @return void
	 */
	public function __set($name, $value)
	{
		if (array_search($name, ['data', 'params']) !== false) {
			$this->$name = $value;
		}
	}

	/**
	 * Executes the method corresponding to HTTP method.
	 * @return mixed The reply to be send to client
	 */
	public function execute()
	{
		if (method_exists($this, $this->method)) {
			$reply = $this->{$this->method}($this->data);
		} else {
			throw new RequestsException(strtoupper($this->method) . " method is not supported for " . substr(strrchr(get_class($this), "\\"), 1) . ".", 405);
		}

		return $reply;
	}

	/**
	 * Validate data against their expected values.
	 *
	 * This method validates the input values with the expected ones obtained from
	 * the corresponding model. The model should have been already loaded into the
	 * public variable `$pattern`. In case a validation fails, it throws an exception
	 * with the appropriate message.
	 *
	 * @param  object  $values          The data to inserted to the db.
	 * @param  boolean $checkForMissing Whether to search for missing fields or not
	 * @return void
	 */
	public function validate($values, $checkForMissing=true)
	{
		$values = (array)$values;
		if ($checkForMissing) {
			$required = isset($this->pattern->required) ? $this->pattern->required : $this->pattern::$required;
			foreach ($required as $field) {
				if ($values[$field] !== false && empty($values[$field]))
					throw new ValidationException("Missing required values for $field.", 0);
			}
		}

		foreach ($values as $key => $value) {
			if ( !property_exists($this->pattern, $key) ) {
				throw new ValidationException("Field $key does not exist in table " . $this->table, 1);
			} else {
				$field = $this->pattern->$key;
			}

			// Set default field type to string
			$field->type = property_exists($field, 'type') ? $field->type : 'string';
			if ($value == '')
				continue;

			switch ($field->type) {
				case 'string':
					if (isset($field->min_size) && strlen($value) < $field->min_size)
						throw new ValidationException("$key should have a minimum size of {$field->min_size} characters.", 2);
					if (isset($field->max_size) && strlen($value) > $field->max_size)
						throw new ValidationException("$key could not exceeds the maximum size of {$field->max_size} characters.", 3);
					if (!empty($field->validation) && !empty($value) && !(boolean)preg_match("/^{$field->validation}$/mu", $value))
						throw new ValidationException($field->message, 4);
					break;

				case 'numeric':
					if (isset($field->min_size) && $value < $field->min_size)
						throw new ValidationException("$key value could not be less than {$field->min_size}.", 2);
					if (isset($field->max_size) && $value > $field->max_size)
						throw new ValidationException("$key value could not be more than {$field->max_size}.", 3);
					break;
			}

			if (isset($field->unique) && $field->unique) {
				$exists = $this->db->table($this->table)
								   ->fields($key)
								   ->where([$key => $value])
								   ->exists();
				if ($exists)
					throw new ValidationException("$key '$value' already exists", 5);
			}
		}
	}

	/**
	 * Gives the table list of the appropriate fields.
	 *
	 * It queries the db for the fields defined in the corresponding
	 * model and for the rows defined in the requested URL.
	 * It is usually called by the GET method.
	 *
	 * @return array The resulting array
	 */
	protected function list()
	{
		$list = $this->db->table($this->table);
		$where_index = $this->whereIndex();
		$where = $this->where();
		$fields = $this->fields();
		$class = get_class($this->pattern);

		$list = $list->fields($fields);
		if (isset($this->pattern::$join))
			$list = $list->join($this->pattern::$join);
		if (isset($this->pattern::$leftJoin))
			$list = $list->leftJoin($this->pattern::$leftJoin);
		$list = !empty($where_index)
			? $list->where($where_index)
			: (
				(
					array_search(array_values($this->pattern::$visible)[0], $this->pattern::$index) !== false
					|| (
						array_keys($this->pattern::$visible)[0] !== 0
						&& array_search(array_keys($this->pattern::$visible)[0], $this->pattern::$index) !== false
					)
				)
				? $list->groupById() : $list
			);
		$list = !empty($where) ? $list->where($where) : $list;
		if (property_exists($this->params, 'sort')) {
			$sort_method = property_exists($this->params, 'sort_method') ? $this->params->sort_method : 'ASC';
			$list = $list->orderBy($this->params->sort, $sort_method);
		}

		if (defined("$class::limited") && $this->pattern::limited) {
			$limit = property_exists($this->params, 'limit') ? (int)$this->params->limit : 10;
			$page = property_exists($this->params, 'page') ? (int)$this->params->page : 1;
			$query = property_exists($this->params, 'query') ? $this->params->query : '';
			$filter_query = property_exists($this->params, 'fq') ? $this->params->fq : '';
			if (!empty($query))
				$like = $this->like($fields);
			if (!empty($filter_query))
				$filters = $this->filters();
			$list = !empty($like) ? $list->like($like, 'OR') : $list;
			$list = !empty($filters) ? $list->where($filters) : $list;
			$list->limit($limit, ($page - 1)*$limit);
			$count = $list->count();
		}
		if ((isset($this->params->fields) && sizeof($this->params->fields) == 1) || sizeof($this->pattern::$visible) == 1 || ($list->group_by_id && sizeof($this->pattern::$visible) == 2)) {
			$list = $list->fetch('column');
		} else {
			$list = $list->select();
		}
		if (!empty($where_index) && sizeof($list)==1) {
			$data = $list[0];
		} else if (!empty($where)) {
			$data = $list;
		} else {

			if (defined("$class::limited") && $this->pattern::limited) {
				$data = new stdClass();
				$data->values = $list;
				$data->limit = $limit;
				$data->page = $page;
				$data->total_pages = ceil($count/$limit);
				$data->query = $query;
				$data->filter_query = $filter_query;
			} else {
				$data = $list;
			}
		}
		return $data;
	}

	/**
	 * It inserts new data into a table.
	 *
	 * First it validates the data and subsequently tries to
	 * write them to the db. Usually called by POST method.
	 *
	 * @param  object $data The data to be inserted to the table.
	 * @return string       The id of the inserted data.
	 */
	protected function insert($data)
	{
		$class = get_class($this->pattern);
		if ( defined("$class::secondary_table") ) {
			$primary_data = $secondary_data = [];
			foreach ($data as $key => $value) {
				if (array_search($key, $this->pattern::$fields) !== false) {
					$secondary_data[$key] = $value;
				} else {
					$primary_data[$key] = $value;
				}
			}
			$data = $primary_data;
			foreach ($this->pattern::$join[$this->pattern::secondary_table] as $primary_index => $secondary_index) {
				$secondary_data[$secondary_index] = $data[$primary_index];
			}
		}
		try {
			$this->validate($data);
			if (is_object($data)) {
				if (isset($data->password))
					$data->password = password_hash($data->password, PASSWORD_DEFAULT);
			} else {
				if (isset($data['password']))
					$data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
			}
			if (isset($this->pattern::$primary) && $this->pattern::$primary === 'uuid') {
				$id = uuid();
				$data->uuid = $id;
				$this->db->table($this->pattern::table)->insert($data);
			} else {
				$this->db->table($this->pattern::table)->insert($data);
				$id = $this->db->lastInsertId();
			}
			if (!empty($secondary_data)) {
				$this->validate($secondary_data, false);
				$reply = $this->db->table($this->pattern::secondary_table)
								  ->insert($secondary_data);
			}
		} catch (ValidationException $e) {
			throw $e;
		} catch (PDOException $e) {
			$msg = ENV=='production' ? "An unknown problem occurred." : $e->getMessage();
			throw new Exception($msg);
		} catch (Exception $e) {
			$msg = ENV=='production' ? "An unknown problem occurred." : $e->getMessage();
			throw new Exception($msg);
		}

		return $id;
	}

	/**
	 * Updates existing data in db.
	 *
	 * Validates and updates data in db. Usually called by PUT method.
	 *
	 * @param  object $data The updated data
	 * @return array        The response to the client.
	 */
	protected function update($data)
	{
		$where = $this->whereIndex();
		if ( empty($where) )
			throw new RequestsException("Please specify where to update the data", 400);
		$className = strtolower(substr(strrchr(get_class($this->pattern), "\\"), 1));
		if (defined("$className::secondary_table") && $this->pattern::secondary_table !== null ) {
			$primary_data = $secondary_data = [];
			foreach ($data as $key => $value) {
				if (array_search($key, $this->pattern::$fields) !== false) {
					$secondary_data[$key] = $value;
				} else {
					$primary_data[$key] = $value;
				}
			}
			$data = $primary_data;
		}
		try {
			$this->validate($data, false);
			if ( !empty($data->password) )
				$data->password = password_hash($data->password, PASSWORD_DEFAULT);
			if ($this->db->inTransaction()) {
				$already_in_transaction = true;
			} else {
				$already_in_transaction = false;
				$this->db->beginTransaction();
			}
			if (!empty($data)) {
				$reply = $this->db->table($this->table)
								  ->where($where)
								  ->update($data);
			}
			if (!empty($secondary_data)) {
				$this->validate($secondary_data, false);
				$reply = $this->db->table($this->pattern::secondary_table)
								  ->where($where)
								  ->update($secondary_data);
			}
			if (!$already_in_transaction)
				$this->db->commit();
		} catch (ValidationException $e) {
			throw $e;
		} catch (PDOException $e) {
			$msg = ENV=='production' ? "An unknown problem occurred." : $e->getMessage();
			throw new RequestsException($msg, 500);
		} catch (Exception $e) {
			$msg = ENV=='production' ? "An unknown problem occurred." : $e->getMessage();
			throw new RequestsException($msg, 500);
		}

		return ['updated' => $reply];
	}

	/**
	 * Removes a specific row from a db table.
	 *
	 * Removes a row defined either by its id either by a unique key (defined in the model).
	 * These are given in the requested URL.
	 *
	 * @return array The response to the client
	 */
	protected function remove()
	{
		$where = $this->whereIndex();
		if ( empty($where) )
			throw new Exception("Please specify which data to remove");
		try {
			$reply = $this->db->table($this->table)
							  ->where($where)
							  ->delete();
		} catch (PDOException $e) {
			$msg = ENV=='production' ? "An unknown problem occurred." : $e->getMessage();
			throw new Exception($msg);
		} catch (Exception $e) {
			throw $e;
		}

		return ['deleted' => $reply];

	}

	/**
	 * Auxiliary method to construct the "where" array for indices according to request URL parameters.
	 * @return array
	 */
	private function whereIndex()
	{
		$indices = isset($this->pattern::$index) ? $this->pattern::$index : [];
		if (isset($this->pattern::$primary)) {
			array_push($indices, $this->pattern::$primary);
		} else {
			array_push($indices, 'id');
		}
		$where = [];
		foreach ($indices as $index) {
			if (!empty($this->params->$index)) {
				$fields = explode(';', $this->params->$index);
				$where[$index] = $fields;
			}
		}
		return $where;
	}

	/**
	 * Auxiliary method to construct the "where" array according to request URL parameters.
	 * @return array
	 */
	private function where()
	{
		$where = [];
		foreach ($this->fields as $table => $fields) {
			foreach ($fields as $field) {
				if (!empty($this->params->$field)) {
					$where["$table.$field"] = $this->params->$field;
				}
			}
		}
		return $where;
	}

	/**
	 * Auxiliary method to construct the query string
	 * @param  array $fields
	 * @return array
	 */
	protected function like($fields)
	{
		$like = [];
		foreach ($fields as $key => $field) {
			if (
				array_search($field, $this->pattern::$searchable) !== false ||
				(!is_numeric($key) && array_search($key, $this->pattern::$searchable) !== false)
			) {
				$field = is_array($field) ? 'CONCAT(' . implode(', ', $field) . ')' : $field;
				$like[$field] = "%{$this->params->query}%";
			}
		}
		return $like;
	}

	protected function filters($fields=null)
	{
		$fields = !isset($fields) ? $this->fields[$this->table] : $fields;
		$filters = [];
		$fq = explode(';', $this->params->fq);
		foreach ($fq as $value) {
			$value = explode(':', $value);
			if (isset($value[0]) && isset($value[1])) {
				$key = $value[0];
				$value = $value[1];
				if (array_search($key, $fields) !== false) {
					if (array_search($key, array_keys($filters)) === false) {
						$filters[$key] = $value;
					} else {
						$filters[$key] = is_array($filters[$key]) ? $filters[$key] : [$filters[$key]];
						$filters[$key][] = $value;
					}
				}
			}
		}
		return $filters;
	}

	/**
	 * Auxiliary method to construct the fields array to feed sql.
	 * @return null|array
	 */
	private function fields()
	{
		$fields = [$this->table . '.id'];
		if (isset($this->params->fields)) {
			if (is_array($this->params->fields)) {
				$fields = $this->params->fields;
			} else {
				$this->params->fields = explode(';', $this->params->fields);
				foreach ($this->pattern as $key => $obj) {
					if (array_search($key, $this->params->fields) !== false)
						$fields[] = $key;
				}
			}
		} else if (isset($this->pattern::$visible)) {
			$fields = $this->pattern::$visible;
		} else {
			$fields = null;
		}

		return $fields;
	}

}
