<?php
namespace Api\Requests;
use \Exception;

defined( 'ABSPATH' ) or die( 'Sorry, direct access is forbidden.' );

/**
 * The Upload class
 */
class Upload extends Requests
{
	public function __construct($method)
	{
		parent::__construct($method);
	}

	public function get()
	{
		try {
			if (isset($this->params->uuid)) {
				$file = $this->getFile(DATA_PATH . "/tmp/{$this->params->uuid}/grant.sql"); //TODO
			} else {
				$user = $this->params->user;
				$application = $this->params->application;
				$filename = $this->params->filename;
				$file = $this->getFile(DATA_PATH . "/private/$user/$application/$filename");
			}
			$meta = ['type' => $file['type'], 'size' => $file['length'], 'name' => $file['name']];
		} catch (Exception $e) {
			throw new RequestsException("Resource not found.", 404);
		}

		return $meta;
	}

	public function post($data)
	{
		if (empty($_FILES))
			throw new RequestsException("No file to upload.", 400);
		$uuid = uuid();
		$path = DATA_PATH . "/tmp/$uuid/";
		mkdir($path);
		$location_id = false;
		foreach ($_FILES as $file) {
			$filename = $path . basename($file['name']);
			if ( move_uploaded_file($file['tmp_name'], $filename ) ) {
				$location_id = $uuid;
			} else {
				rmdir($path);
				throw new RequestsException("Resource not accepted.", 406);
			}
		}

		return $location_id;
	}

	public function delete($location_id)
	{
		if (empty($location_id) || !is_string($location_id))
			throw new RequestsException("Resource not found.", 404);
		try {
			if (strlen($location_id)==36) {
				$path = DATA_PATH . "/tmp/$location_id/";
				shell_exec("rm -rf $path");
			} else {
				$file = DATA_PATH . $location_id;
				unlink($file);
			}
		} catch (Exception $e) {
			throw new RequestsException("Resource not found.", 404);
		}
	}

	private function getFile($filename)
	{
		$handle = fopen($filename, 'r');
		$content = fread($handle, filesize($filename));
		fclose($handle);

		return array(
			'name' => basename($filename),
			'content' => $content,
			'type' => mime_content_type($filename),
			'length' => filesize($filename)
		);
	}

}