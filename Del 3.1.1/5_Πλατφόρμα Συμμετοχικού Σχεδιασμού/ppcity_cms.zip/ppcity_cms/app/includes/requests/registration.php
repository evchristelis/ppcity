<?php
namespace Api\Requests;
use \Exception, \PDOException;
use Api\Model\Users, Api\Model\UserInfo;
use Api\Model\Email, Api\Model\Template;

defined( 'ABSPATH' ) or die( 'Sorry, direct access is forbidden.' );

/**
 * The registration request class
 */
class Registration extends Requests
{

	public function __construct($method)
	{
		global $session;
		$this->pattern = new UserInfo();
		parent::__construct($method);
	}

	/**
	 * Post method.
	 * @param  object $data A stdClass object containing the data to be inserted
	 * @return string       The inserted data id.
	 */
	public function post($data)
	{
		global $session;

		if ( empty($data) )
			throw new RequestsException('Empty data', 400);
		try {
			$data->uuid = uuid();
			$data->role = (isset($data->role) && isset($session->user) && $session->user->role == 'admin') ? $data->role : 'guest';
			$this->db->beginTransaction();
			$id = parent::insert($data);
			createToken($data->uuid, 'activation');
			sendEmail($data->uuid, 'registration');
			$this->db->commit();
		} catch (PDOException $e) {
			$this->db->rollBack();
			throw $e;
		} catch (Exception $e) {
			throw $e;
		}

		return $id;
	}

}