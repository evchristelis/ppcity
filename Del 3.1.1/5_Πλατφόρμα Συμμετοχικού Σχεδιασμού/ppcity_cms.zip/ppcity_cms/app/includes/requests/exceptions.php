<?php
namespace Api\Requests;
use \Exception;

/**
 * Exceptions for requests.
 *
 * The exception code correspond to the HTTP response code.
 */
class RequestsException extends Exception
{
}

class ValidationException extends Exception
{
}

