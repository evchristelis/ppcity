<?php
namespace Api\Requests;
use \Exception, \ErrorException, \stdClass;

defined( 'ABSPATH' ) or die( 'Sorry, direct access is forbidden.' );

/**
 * Serving validation rules
 */
class Validation extends Requests
{

	function get()
	{
		try {
			if (!empty($this->params->fields))
				$fields = explode(';', $this->params->fields);
			if (empty($this->params->category)) {
				$rules = [];
			} else {
				$category = $this->params->category;
				$class = "\\Api\\Model\\$category";
				if (!class_exists($class))
					throw new RequestsException("Category '$category' not found", 404);
				$rules = new $class();
				if (isset($fields)) {
					$new_rules = new stdClass();
					foreach ($fields as $field) {
						if (property_exists($rules, $field))
							$new_rules->$field = $rules->$field;
					}
					$rules = $new_rules;
				}
			}
		} catch (Exception $e) {
			throw $e;
		}

		return $rules;
	}
}