<?php
namespace Api\Requests;
use \Exception;
use Api\Model\Users;

defined( 'ABSPATH' ) or die( 'Sorry, direct access is forbidden.' );

/**
 * The password recovery class
 */
class Recovery extends Requests
{

	/**
	 * Define the application model.
	 * @param string $method The HTTP request method
	 */
	public function __construct($method)
	{
		parent::__construct($method);
	}

	public function post($data)
	{
		global $db;
		if (isset($data->username)) {
			$uuid = $this->db->table(Users::table)
							 ->fields('uuid')
							 ->where(['username' => $data->username])
							 ->fetch('value');

			if (!empty($uuid)) {
				try {
					$this->db->beginTransaction();
					$this->db->table(Users::table)
							 ->where(['uuid' => $uuid])
							 ->update(['password_reset' => true]);
					createToken($uuid, 'recovery');
					sendEmail($uuid, 'recovery');
					$this->db->commit();
				} catch (Exception $e) {
					throw new RequestsException('Error Processing Request', 500);
				}
			} else {
				throw new RequestsException('User not found', 404);
			}
		} else {
			throw new RequestsException('You have to provide a username', 402);
		}
	}
}
