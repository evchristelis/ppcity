<?php
namespace Api\Requests;
use \Exception;
use Api\Model\Users as UsersPattern, Api\Model\UserInfo;

defined( 'ABSPATH' ) or die( 'Sorry, direct access is forbidden.' );

/**
 * The users class
 */
class Users extends Requests
{

	/**
	 * Define the Users model.
	 * @param string $method The HTTP request method
	 */
	public function __construct($method)
	{
		$this->pattern = new UsersPattern();
		parent::__construct($method);
	}

	/**
	 * Get method.
	 * @return array The requested results
	 */
	public function get()
	{
		global $session;
		if (property_exists($this->params, 'uuid'))
			$this->pattern = new UserInfo;

		if ($session->user->role != SYSTEM_ROLES[0]) {
			$roles = array_slice(SYSTEM_ROLES, array_search($session->user->role, SYSTEM_ROLES));
			$fq = isset($this->params->fq) ? explode(';', $this->params->fq) : [];
			foreach ($roles as $role) {
				$fq[] = "role:$role";
			}
			$this->params->fq = implode(';', $fq);
		}
		return parent::list();
	}

	/**
	 * Put method
	 * @param  object $data
	 * @return array
	 */
	public function put($data)
	{
		global $session;
		if (property_exists($this->params, 'uuid')) {
			$this->pattern = new UserInfo;
			if ($session->user->role != SYSTEM_ROLES[0]) {
				$role = $this->db->table($this->pattern::table)
								 ->fields('role')
								 ->where(['uuid' => $this->params->uuid])
								 ->fetch('value');
				if (array_search($session->user->role, SYSTEM_ROLES) > array_search($role, SYSTEM_ROLES) )
					throw new RequestsException('Insufficient permissions', 403);
				if (isset($data->role) && array_search($session->user->role, SYSTEM_ROLES) > array_search($data->role, SYSTEM_ROLES))
					throw new RequestsException('Insufficient permissions', 403);
			}
		}
		return parent::update($data);
	}

	/**
	 * Delete method.
	 * @return array
	 */
	public function delete()
	{
		global $session;
		if (property_exists($this->params, 'uuid')) {
			if ($session->user->role != SYSTEM_ROLES[0]) {
				$role = $this->db->table($this->pattern::table)
								 ->fields('role')
								 ->where(['uuid' => $this->params->uuid])
								 ->fetch('value');
				if (array_search($session->user->role, SYSTEM_ROLES) > array_search($role, SYSTEM_ROLES) )
					throw new RequestsException('Insufficient permissions', 403);
			}
		}
		return parent::remove();
	}

}