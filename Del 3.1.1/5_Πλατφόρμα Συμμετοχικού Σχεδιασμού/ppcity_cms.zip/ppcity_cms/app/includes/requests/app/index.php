<?php
namespace Api\Requests;
use Api\Model\AppToken;
use Api\Requests\Requests as ParentRequests;
use \Exception, \stdClass;

defined( 'ABSPATH' ) or die( 'Sorry, direct access is forbidden.' );

foreach (glob(dirname(__FILE__) . "/*.php") as $filename) {
	require_once $filename;
}

abstract class AppRequests extends ParentRequests
{
	public function __construct($method)
	{
		parent::__construct($method);
	}

	protected function list()
	{
		$list = [];
		if (isset($this->params->token) && isset($this->pattern::$primary) && $this->pattern::$primary === 'uuid') {
			$table = $this->pattern::table;
			$dot_pos = strpos($table, '.');
			$scope = $dot_pos === false ? $table : substr($table, $dot_pos + 1);
			$uuid = $this->db->table(AppToken::table)
							 ->fields('uuid')
							 ->where(['token' => $this->params->token, 'scope' => $scope])
							 ->fetch('value');
			$this->params->uuid = $uuid;
		}
		$list = parent::list();
		$class = get_class($this->pattern);
		if (defined("$class::limited") && $this->pattern::limited && property_exists($list, 'values')) {
			foreach ($list->values as $index => $item) {
				$item = self::getChild($item);
			}
		} else {
			if (is_array($list)) {
				foreach ($list as $index => &$item) {
					$item = self::getChild($item);
				}
			} else if (is_object($list)) {
				$list = self::getChild($list);
			}
		}

		return $list;
	}

	protected function getChild($item)
	{
		foreach ($item as $property => &$value) {
			if ($this->pattern->$property->type === 'json') {
				$value = json_decode($value);
			} else if (isset($this->pattern->$property->foreign_key) && $this->pattern->$property->type = 'uuid') {
				$request = '\\Api\Requests\\' . ucwords($property);
				$request = new $request('GET');
				$request->params = new stdClass();
				$request->params->token = self::findToken($value, $property);
				$value = $request->get();

			}
		}

		return $item;
	}

	protected function findToken($uuid, $scope)
	{
		$token = $this->db->table(AppToken::table)
						  ->fields('token')
						  ->where(['uuid' => $uuid, 'scope' => $scope])
						  ->fetch('value');
		return $token;
	}

	protected function createToken($uuid, $scope, $owner=null)
	{
		$token = hash_hmac('sha256', $uuid, SALT);
		$this->db->table(AppToken::table)->insert([
			'uuid' => $uuid,
			'token' => $token,
			'scope' => $scope,
			'owner' => $owner,
		]);
		return $token;
	}

	protected function getFromToken($token, $scope)
	{
		$uuid = $this->db->table(AppToken::table)
						 ->fields('uuid')
						 ->where(['token' => $token, 'scope' => $scope])
						 ->fetch('value');
		if (empty($uuid))
			throw new RequestsException("$scope not found.", 400);

		return $uuid;
	}

}