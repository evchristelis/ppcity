<?php
/**
 * Yet Another Minimalistic ORM.
 *
 * @filesource
 * @author Pantelis Mitropoulos <pantelismitr@gmail.com>
 * @package  Yet Another Minimalistic ORM
 * @version 0.1.0 Development stage
 */

namespace ORM;

/**
 * A fluent interface for ORM.
 */
interface dbInterface {

	/**
	 * Selects a function to execute
	 * @param  string $function_name The name of the function to call
	 * @param  array  $args          The arguments to pass to the function
	 */
	public function sqlFunction($function_name, $args=null);

	/**
	 * Selects a specific schema.
	 *
	 * @param string $schema
	 */
	public function schema($schema);

	/**
	 * Set the boolean operator that connect where statements.
	 * @param  string $operator One of 'AND', 'OR'.
	 */
	public function boolean($operator);

	/**
	 * Creates an enum statement
	 * @param  array $values
	 */
	public function enum($values);

	/**
	 * Selects a new type.
	 * @param  string $type
	 */
	public function type($type);

	/**
	 * Selects a specific table.
	 *
	 * @param mixed $table
	 */
	public function table($table);

	/**
	 * Authorize the current db user.
	 */
	public function authorization();

	/**
	 * Determines the table as temporary.
	 */
	public function temporary();

	/**
	 * Select as a table.
	 *
	 * @param string $table
	 */
	public function asTable($table);

	/**
	 * Switch cascade mode on/off.
	 *
	 * @param boolean $mode
	 */
	public function cascade($mode=true);

	/**
	 * Left join with tables.
	 *
	 * @param array $tables
	 */
	public function leftJoin($tables);

	/**
	 * Right join with tables.
	 *
	 * @param array $tables
	 */
	public function rightJoin($tables);

	/**
	 * Inner join with tables.
	 *
	 * @param array $tables
	 */
	public function innerJoin($tables);

	/**
	 * General join (default inner) with tables.
	 *
	 * Parent method for leftJoin, rightJoin and innerJoin methods.
	 *
	 * @param array $tables
	 * 	It has the form ['table1' => ['key1' => 'key2', ...], ...]
	 * @param string $type (optional)
	 */
	public function join($tables, $type='INNER');

	/**
	 * Determines the fields of a table.
	 *
	 * @param mixed $fields (optional)
	 */
	public function fields($fields='*');

	/**
	 * Defines the aggregate function to be used.
	 *
	 * @param string $aggregate_function The PostgreSQL aggregate function to be used.
	 * @param array  $arguments The arguments (fields) that will passed to aggregate function.
	 * @param string $name The name of the resulting field.
	 */
	public function aggregate($aggregate_function, $arguments, $name);

	/**
	 * Defines a WHERE SQL statement.
	 *
	 * Could either provide the WHERE statement directly by
	 * determining the SQL string either translate an array
	 * into SQL. In the latter case, the keys correspond to
	 * field names, while the values to the values of the
	 * fields, joined with boolean AND. In case the values
	 * are themselves arrays, they are joined with boolean OR.
	 *
	 * @param string|array $conditions
	 * @param string $relation (optional)
	 */
	public function where($conditions, $relation='=');

	/**
	 * Defines a WHERE SQL statement with LIKE as relation operator.
	 *
	 * @param mixed $conditions
	 */
	public function like($conditions);

	/**
	 * Defines a PostGIS statement to search for geometries inside the bounding box.
	 */
	public function within($within);

	/**
	 * Creates a point to insert or update a geometric object.
	 */
	public function makePoint($coordinates, $srid);

	/**
	 * Defines a LIMIT statement.
	 *
	 * @param integer $offset
	 * @param integer $count
	 */
	public function limit($offset, $count);

	/**
	 * Defines an ORDER BY statement.
	 *
	 * @param string $field
	 * @param string $type (optional) One of 'ASC' [default], 'DESC'
	 */
	public function orderBy($field, $type='ASC');

	/**
	 * Defines a GROUP BY statement.
	 *
	 * @param mixed $fields
	 */
	public function groupBy($fields);

	/**
	 * Executes a select query.
	 *
	 * It joins all the sql statements, before calling
	 * the parent method for the actual execution.
	 */
	public function select();

	/**
	 * Counts the results.
	 */
	public function count();

	/**
	 * Executes a CREATE action.
	 */
	public function create();

	/**
	 * Executes a DROP action.
	 */
	public function drop();

	/**
	 * Executes a DESCRIBE action.
	 */
	public function describe();

	/**
	 * Executes a SELECT action of the specific content (default: object).
	 *
	 * @param string $type
	 * 	Could be one of object, column, value.
	 */
	public function fetch($type);

	/**
	 * Check for the existence of a value.
	 */
	public function exists();

	/**
	 * Change return type to associative array by keys.
	 */
	public function group();

	/**
	 * Change return type to associative array grouped by id.
	 */
	public function groupById();

	/**
	 * Change return type to column unique values.
	 */
	public function unique();

	/**
	 * Insert a row into a table.
	 *
	 * @param object $data
	 * 	The data to be inserted in the form field->value.
	 */
	public function insert($data);

	/**
	 * Deletes a selected row from a table.
	 */
	public function delete();

	/**
	 * Updates data in a table.
	 *
	 * @param array $data
	 * 	An associative array with the corresponding new values.
	 */
	public function update($data);

}