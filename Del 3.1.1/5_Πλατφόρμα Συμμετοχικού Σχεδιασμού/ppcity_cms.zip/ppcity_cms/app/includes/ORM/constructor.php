<?php
/**
 * Yet Another Minimalistic ORM.
 *
 * @filesource
 * @author Pantelis Mitropoulos <pantelismitr@gmail.com>
 * @package  Yet Another Minimalistic ORM
 * @version 0.1.0 Development stage
 */

namespace ORM;

use \PDO, \Exception;
require_once "db_interface.php";

/**
 * The minimalistic ORM class.
 *
 * @class_implements(dbInterface)
 */
class Constructor implements dbInterface {

	/**
	 * The constructed sql statement
	 * @var string
	 */
	public $sql;
	/**
	 * The fetch method
	 * @var iinteger
	 */
	public $fetch;
	/**
	 * The used schema (PostgreSQL only)
	 * @var string
	 */
	public $schema;
	/**
	 * The fields to be fetched
	 * @var string|array|object
	 */
	public $fields;
	/**
	 * Contains the SQL WHERE statements
	 * @var array
	 */
	public $where;
	/**
	 * The boolean operator which will be used to join where queries [default: AND]
	 * @var string
	 */
	public $boolean_operator;
	/**
	 * Contains information about JOIN statement.
	 * @var array
	 */
	public $join;
	/**
	 * The prepared values with their names.
	 * @var array
	 */
	public $prepared_values;
	/**
	 * ORDER BY part of SQL statement
	 * @var string
	 */
	public $orderby;
	/**
	 * GROUP BY part of SQL statement
	 * @var string
	 */
	public $groupby;
	/**
	 * LIMIT part of SQL statement
	 * @var string
	 */
	public $limit;
	/**
	 * Determines whether the results should be grouped or not
	 * @var boolean
	 */
	public $group;
	/**
	 * Determines whether the results should be brouped by their id.
	 * @var boolean
	 */
	public $group_by_id;
	/**
	 * Determines whether only a value should be fetched
	 * @var boolean
	 */
	public $value;
	/**
	 * Determines whether a row should be fetched
	 * @var boolean
	 */
	public $row;
	/**
	 * Determines whether only unique values should be fetched
	 * @var boolean
	 */
	public $unique;
	/**
	 * Keeps track of defined points
	 * @var array
	 */
	protected $points;

	public function __construct(DbConn $conn)
	{
		$this->conn = $conn;
		$this->settingsReset();
		$this->boolean_operator = 'AND';
		$this->points = [];
	}

	/**
	 * Selects a function to execute
	 * @param  string $function_name The name of the function to call
	 * @param  array  $args          The arguments to pass to the function
	 * @param  $this
	 */
	public function sqlFunction($function_name, $args=null)
	{
		if (!empty($args)) {
			$args = self::prepareSql($args, '', 'function');
			$args = implode(', ', $args);
		}
		$this->table = !empty($args) ? "$function_name($args)" : "$function_name()";
		return $this;
	}

	/**
	 * Selects a specific schema.
	 *
	 * @param string $schema
	 * @return $this
	 */
	public function schema($schema)
	{
		$this->schema = $schema;
		$this->sql = "SCHEMA %s $schema";
		return $this;
	}

	/**
	 * Set the boolean operator that connect where statements.
	 * @param  string $operator One of 'AND', 'OR'.
	 * @return $this
	 */
	public function boolean($operator)
	{
		$operator = strtoupper(trim($operator));
		if ($operator != 'AND' && $operator != 'OR')
			return $this;
		$this->boolean_operator = $operator;
		return $this;
	}

	/**
	 * Selects a new type.
	 * @param  string $type
	 * @return $this
	 */
	public function type($type)
	{
		$this->sql = "TYPE $type";
		return $this;
	}

	/**
	 * Creates an enum statement.
	 * @param  array $values
	 * @return $this
	 */
	public function enum($values)
	{
		$values = implode(', ', $values);
		$this->sql .= " AS ENUM ($values)";
		return $this;
	}

	/**
	 * Selects a specific table.
	 *
	 * @param mixed $table
	 * @return $this
	 */
	public function table($table)
	{
		$table = is_array($table) ? $table : [$table];
		$tables = [];
		foreach ($table as $as => $tb) {
			$tb = !empty($this->schema) ? "{$this->schema}.$tb" : $tb;
			$tables[] = is_string($as) ? "$tb $as" : $tb;
		}
		$table = implode(', ', $tables);
		$this->table = $table;
		$this->sql = "TABLE %s $table";
		return $this;
	}

	/**
	 * Authorize the current db user.
	 *
	 * @return $this
	 */
	public function authorization()
	{
		$this->sql .= " AUTHORIZATION {$this->conn->dbuser}";
		return $this;
	}

	/**
	 * Determines the table as temporary.
	 *
	 * @return $this
	 */
	public function temporary()
	{
		$this->sql = "TEMPORARY {$this->sql}";
		return $this;
	}

	/**
	 * Select as a table.
	 *
	 * @param string $table
	 * @return $this
	 */
	public function asTable($table)
	{
		$table = !empty($this->schema) ? "{$this->schema}.$table" : $table;
		$this->sql .= " AS (SELECT * FROM $table)";
		return $this;
	}

	/**
	 * Switch cascade mode on/off.
	 *
	 * @param boolean $mode
	 * @return $this
	 */
	public function cascade($mode=true)
	{
		$this->cascade = $mode;
		return $this;
	}

	/**
	 * Left join with tables.
	 *
	 * @param array $tables
	 * @return $this
	 */
	public function leftJoin($tables)
	{
		return $this->join($tables, 'LEFT');
	}

	/**
	 * Right join with tables.
	 *
	 * @param array $tables
	 * @return $this
	 */
	public function rightJoin($tables)
	{
		return $this->join($tables, 'RIGHT');
	}

	/**
	 * Inner join with tables.
	 *
	 * @param array $tables
	 * @return $this
	 */
	public function innerJoin($tables)
	{
		return $this->join($tables);
	}

	/**
	 * General join (default inner) with tables.
	 *
	 * Parent method for leftJoin, rightJoin and innerJoin methods.
	 *
	 * @param array $tables
	 * 	It has the form ['table1' => ['key1' => 'key2', ...], ...]
	 * @param string $type (optional)
	 * @return $this
	 */
	public function join($tables, $type='INNER')
	{
		$types = ['LEFT', 'LEFT OUTER', 'FULL', 'RIGHT', 'RIGHT OUTER', 'INNER', 'FULL OUTER', 'NATURAL'];
		if (array_search($type, $types) === false)
			throw new Exception('Join type should be one of ' . implode(', ', $types) . '.');

		$join = [];
		$main_table = explode(' ', $this->table);
		$main_table = $main_table[sizeof($main_table) - 1];
		foreach ($tables as $table => $on) {
			$pairs = [];
			foreach ($on as $key1 => $key2) {
				if (strpos($table, ' ') !== false) {
					$j_table = trim(explode(' ', $table)[1]);
				} else {
					$j_table = $table;
				}
				$pairs[] = (strpos($key1, '.') === false) ? "$main_table.$key1 = $j_table.$key2" : "$key1=$key2";
			}
			$pairs = implode(" AND ", $pairs);
			$join[] = "$type JOIN $table ON ($pairs)";
		}
		array_push($this->join, ...$join);
		return $this;
	}

	/**
	 * Determines the fields of a table.
	 *
	 * @param string|array|object $fields (optional)
	 * @return $this
	 */
	public function fields($fields='*')
	{
		$this->fields = self::prepareFields($fields);
		return $this;
	}

	/**
	 * Defines the aggregate function to be used.
	 *
	 * @param string $aggregate_function The PostgreSQL aggregate function to be used.
	 * @param array  $arguments The arguments (fields) that will passed to aggregate function.
	 * @param string $name The name of the resulting field.
	 * @return $this
	 */
	public function aggregate($aggregate_function, $arguments, $name)
	{
		$fields = self::prepareFields($arguments);
		$prev_fields = explode(', ', $this->fields);
		$prev_fields[] = "$aggregate_function($fields) AS $name";
		$this->fields = implode(', ', $prev_fields);
		return $this;
	}

	/**
	 * Defines a WHERE SQL statement.
	 *
	 * Could either provide the WHERE statement directly by
	 * determining the SQL string either translate an array
	 * into SQL. In the latter case, the keys correspond to
	 * field names, while the values to the values of the
	 * fields, joined with boolean AND. In case the values
	 * are themselves arrays, they are joined with boolean OR.
	 *
	 * @param string|array $conditions
	 * @param string $relation (optional)
	 * @return $this
	 */
	public function where($conditions, $relation='=', $operator='AND')
	{
		if (is_string($conditions)) {
			array_push($this->where, $conditions);
		} else {
			$where = self::prepareSql($conditions, $relation);
			$where = implode(" {$operator} ", $where);
			array_push($this->where, "($where)");
		}
		return $this;
	}

	/**
	 * Defines a WHERE SQL statement with LIKE as relation operator.
	 *
	 * @param mixed $conditions
	 * @return $this
	 */
	public function like($conditions, $operator='AND')
	{
		$where = self::prepareSql($conditions, 'LIKE');
		$where = implode(" {$operator} ", $where);
		array_push($this->where, "($where)");
		return $this;
	}

	/**
	 * Defines a PostGIS statement to search for geometries inside the bounding box.
	 * @param  array $within The bounding box in the form [column_name => [xmin, ymin, xmax, ymax, SRID]]
	 * @return $this
	 */
	public function within($within)
	{
		foreach ($within as $field => $bounding_box) {
			$bounding_box = implode(',', $bounding_box);
			$sql = "ST_CONTAINS(ST_MakeEnvelope($bounding_box), $field)";
			array_push($this->where, $sql);
		}
		return $this;
	}

	/**
	 * Creates a point to insert or update a geometric object.
	 * @param  string $coordinates lat;lon
	 * @param  number $srid
	 * @return $this
	 */
	public function makePoint($coordinates, $srid)
	{
		$coordinates = explode(';', $coordinates);
		$x = $coordinates[1];
		$y = $coordinates[0];
		$this->points[] = "ST_SetSRID(ST_MakePoint($x, $y), $srid)";
		return $this;
	}

	/**
	 * Defines a LIMIT statement.
	 *
	 * @param integer $count
	 * @param integer $offset (optional)
	 * @return $this
	 */
	public function limit($count, $offset=null)
	{
		if (isset($offset)) {
			$this->limit = " LIMIT $count OFFSET $offset";
		} else {
			$this->limit = " LIMIT $count";
		}
		return $this;
	}

	/**
	 * Defines an ORDER BY statement.
	 *
	 * @param string $field
	 * @param string $type (optional) One of 'ASC' [default], 'DESC'
	 * @return $this
	 */
	public function orderBy($field, $type='ASC')
	{
		$this->orderby = " ORDER BY $field $type";
		return $this;
	}

	/**
	 * Defines a GROUP BY statement.
	 *
	 * @param mixed $fields
	 * @return $this
	 */
	public function groupBy($fields)
	{
		$fields = is_array($fields) ? implode(', ', $fields): $fields;
		$this->groupby = " GROUP BY $fields";
		return $this;
	}

	/**
	 * Executes a select query.
	 *
	 * It joins all the sql statements, before calling
	 * the parent method for the actual execution.
	 *
	 * @return mixed
	 */
	public function select()
	{
		$where = sizeof($this->where) > 0 ? "WHERE " . implode(" {$this->boolean_operator} ", $this->where) : '';
		$join = implode(' ', $this->join);
		$this->sql = $this->unique ? 'DISTINCT ' : '';
		$this->sql .= "$this->fields";
		if (!empty($this->table))
			$this->sql .= " FROM {$this->table}";
		$this->sql .= " $join $where";
		$post = $this->groupby . $this->orderby . $this->limit;
		return self::actions('SELECT', $post);
	}

	/**
	 * Counts the results.
	 *
	 * @return integer The number of results.
	 */
	public function count() {
		$where = sizeof($this->where) > 0 ? "WHERE " . implode(" {$this->boolean_operator} ", $this->where) : '';
		$join = implode(' ', $this->join);
		$this->sql = "(*) FROM {$this->table} $join $where";
		return self::actions('SELECT COUNT');
	}

	/**
	 * Executes a CREATE action.
	 *
	 * @return void
	 */
	public function create()
	{
		$this->sql = sprintf($this->sql, 'IF NOT EXISTS');
		self::actions('CREATE');
	}

	/**
	 * Executes a DROP action.
	 *
	 * @return void
	 */
	public function drop()
	{
		$this->sql = sprintf($this->sql, 'IF EXISTS');
		if (isset($this->cascade) && !$this->cascade) {
			self::actions('DROP');
		} else {
			self::actions('DROP', 'CASCADE');
		}
	}

	/**
	 * Executes a DESCRIBE action.
	 *
	 * @return void
	 */
	public function describe()
	{
		$this->fetch = 'COLUMN';
		self::actions('DESCRIBE');
	}

	/**
	 * Executes a SELECT action of the specific content (default: object).
	 *
	 * @param string $type
	 * 	Could be one of object, column, row, value.
	 *
	 * @return mixed
	 */
	public function fetch($type='object')
	{
		switch ($type) {
			case 'object':
				$this->fetch = PDO::FETCH_OBJ;
				break;
			case 'value':
				$this->value = true;
			case 'column':
				$this->fetch = PDO::FETCH_COLUMN;
				break;
			case 'row':
				$this->row = true;
				break;
		}
		return $this->select();
	}

	/**
	 * Check for the existence of a value.
	 *
	 * @return boolean
	 */
	public function exists()
	{
		$this->fetch = PDO::FETCH_COLUMN;
		$list = $this->select();
		return sizeof($list) > 0;
	}

	/**
	 * Change return type to associative array by keys.
	 *
	 * @return void
	 */
	public function group()
	{
		$this->group = true;
		return $this;
	}

	/**
	 * Change return type to associative array grouped by id.
	 *
	 * @return void
	 */
	public function groupById()
	{
		$this->group_by_id = true;
		return $this;
	}

	/**
	 * Change return type to column unique values.
	 *
	 * @return void
	 */
	public function unique()
	{
		$this->unique = true;
		return $this;
	}

	/**
	 * Main actions method.
	 *
	 * @param string $action
	 * @param string $post (optional)
	 * @return void
	 */
	protected function actions($action, $post=null)
	{
		$this->sql = "$action {$this->sql} $post;";
		// error_log($this->sql);
		// error_log(serialize($this->prepared_values));
		try {
			$sth = $this->conn->prepare($this->sql, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
			$result = $sth->execute($this->prepared_values);
			if (array_search($action, ['SELECT', 'DESCRIBE']) !== false) {
				if ($this->group_by_id) {
					$list = array_map('reset', $sth->fetchAll(PDO::FETCH_GROUP|$this->fetch));
				} else if ($this->group) {
					$list = $sth->fetchAll(PDO::FETCH_GROUP|$this->fetch);
				} else if ($this->value) {
					$list = $sth->fetch($this->fetch);
				} else {
					$list = $sth->fetchAll($this->fetch);
					$list = ($this->row && sizeof($list)==1) ? $list[0] : $list;
				}
			} else if ($action == 'SELECT COUNT') {
				$list = $sth->fetch(PDO::FETCH_COLUMN);
			}
		} catch (PDOException $e) {
			$this->conn->error = $e->getMessage();
			throw $e;
		}

		return array_key_exists('list', get_defined_vars())===true ? $list : null;
	}

	/**
	 * Insert a row into a table.
	 *
	 * @param object $data
	 * 	The data to be inserted in the form field->value.
	 * @return void
	 */
	public function insert($data)
	{
		$this->data = $data;
		return $this->logbook('insert');
	}

	/**
	 * The actual insert method.
	 *
	 * @param object $data
	 * @return void
	 */
	private function protected_insert() {
		$into = array();
		$values = array();
		$counter = 0;
		foreach ( $this->data as $key=>$value ) {
			$into[] = "\"$key\"";
			if (!empty($this->points) && substr($value, 0, 5) == 'point') {
				$index = (integer)substr($value, 5);
				$values[] = $this->points[$index];
			} else {
				if (is_null($value)) {
					$values[] = 'NULL';
				} else {
					$value = $value === false ? 'false' : $value;
					$value = $value === true ? 'true' : $value;
					$values[] = ":value$counter";
					$this->prepared_values[":value$counter"] = is_string($value) ? trim($value) : $value;
					$counter++;
				}
			}
		}
		$into = implode(', ', $into);
		$values = implode(', ', $values);
		$this->sql = "{$this->table}($into) VALUES ($values);";
		return self::actions('INSERT INTO');
	}

	/**
	 * Deletes a selected row from a table.
	 *
	 * @return void
	 */
	public function delete() {
		return $this->logbook('delete');
	}

	/**
	 * The actual delete method.
	 *
	 * @return void
	 */
	private function protected_delete() {
		$where = sizeof($this->where) > 0 ? "WHERE " . implode(' AND ', $this->where) : '';
		$this->sql = "$this->table $where";
		return self::actions('DELETE FROM');
	}

	/**
	 * Updates data in a table.
	 *
	 * @param array $data
	 * 	An associative array with the corresponding new values.
	 * @return void
	 */
	public function update($data) {
		$this->data = $data;
		return $this->logbook('update');
	}

	/**
	 * The actual update method.
	 *
	 * @param array $data
	 * @return void
	 */
	private function protected_update() {
		$where = sizeof($this->where) > 0 ? "WHERE " . implode(' AND ', $this->where) : '';
		$set = self::prepareSql($this->data, '=', 'update');
		$set = implode(', ', $set);

		$this->sql = "$this->table SET $set $where";
		return self::actions('UPDATE');
	}

	private function logbook($action) {
		$method = "protected_$action";
		// if (php_sapi_name() === 'cli') {
			return $this->$method();
		// }
		// global $session;
		// if (array_search($table, $this->logged) === false) {
		// 	$this->$method($table, $data, $where);
		// 	return;
		// }
		// $opts = new stdClass();
		// $logdata = new stdClass();
		// switch ($action) {
		// 	case 'delete':
		// 		$logdata->table_id = $this->getValue($table, 'id', $where);
		// 		$opts->where = array('id'=>$logdata->table_id);
		// 		$olddata = $this->select($table, $opts)[0];
		// 		foreach ($olddata as $key=>$value) {
		// 			$old_values[$key] = $value;
		// 			$new_values[$key] = '';
		// 		}
		// 		break;
		// 	case 'update':
		// 		$logdata->table_id = $this->getValue($table, 'id', $where);
		// 		$opts->fields = implode(', ', array_keys($data));
		// 		$opts->where = array('id'=>$logdata->table_id);
		// 		$olddata = $this->select($table, $opts)[0];
		// 		break;
		// }

		// try {
		// 	$this->$method($table, $data, $where);
		// } catch (Exception $e) {
		// 	throw $e;
		// }

		// switch ($action) {
		// 	case 'insert':
		// 		$logdata->table_id = $this->lastInsertId();
		// 		$opts->fields = implode(', ', array_keys((array)$data));
		// 		$opts->where = array('id'=>$logdata->table_id);
		// 		$newdata = $this->select($table, $opts)[0];
		// 		$old_values = $new_values = array();
		// 		foreach ($newdata as $key=>$value) {
		// 			$old_values[$key] = '';
		// 			$new_values[$key] = $value;
		// 		}
		// 		break;
		// 	case 'update':
		// 		$newdata = $this->select($table, $opts)[0];
		// 		if ($olddata != $newdata) {
		// 			$old_values = $new_values = array();
		// 			foreach ($newdata as $key=>$value) {
		// 				if ($olddata->$key != $value) {
		// 					$old_values[$key] = $olddata->$key;
		// 					$new_values[$key] = $value;
		// 				}
		// 			}
		// 		}
		// 		break;
		// }

		// if (isset($logdata->table_id) && (!empty($new_values) || !empty($old_values))) {
		// 	if ($table != 'candidates')
		// 		$logdata->registration_number = $this->getValue($table, 'registration_number', array('id'=>$logdata->table_id));
		// 	$logdata->action_no = (int)$this->extremum('max', 'logbook', 'action_no');
		// 	$logdata->action_no = empty($logdata->action_no) ? 1 : $logdata->action_no + 1;
		// 	$logdata->user_id = $session->user->id;
		// 	$logdata->ip = @$_SERVER['REMOTE_ADDR'];
		// 	$logdata->forwarded_ip = @$_SERVER['HTTP_X_FORWARDED_FOR'];
		// 	$logdata->tablename = $table;
		// 	$logdata->activity = $action;
		// 	foreach (array_keys($new_values) as $key) {
		// 		$logdata->keyname = $key;
		// 		$logdata->old_value = $old_values[$key];
		// 		$logdata->new_value = $new_values[$key];
		// 		$this->insert('logbook', $logdata);
		// 	}
		// }
	}

	/**
	 * Auxiliary method to rewrite the selected fields.
	 *
	 * @param mixed $fields
	 * @return string
	 */
	private function prepareFields($fields)
	{
		if (empty($fields)) {
			$fields = '*';
		} else if (is_array($fields)) {
			if (count(array_filter(array_keys($fields), 'is_string')) > 0) {
				$entry = [];
				foreach ($fields as $name=>$field) {
					if (!is_array($field)) {
						if (is_numeric($name) && $name < sizeof($fields)) {
							$entry[] = "$field";
						} else {
							$entry[] = "$field as $name";
						}
					} else {
						$field = implode(', ', $field);
						$entry[] = "CONCAT($field) as $name";
					}
				}
				$fields = implode(', ', $entry);
			} else {
				$fields = implode(", ", $fields);
			}
		}
		return $fields;
	}

	/**
	 * Auxiliary method to prepare an SQL statement.
	 *
	 * @param array $values
	 * @param string $relation
	 * @return string
	 */
	private function prepareSql($values, $relation='=', $scope='where')
	{
		if ($scope != 'function') {
			$table = explode(' ', $this->table);
			$table = $table[sizeof($table) - 1];
		}
		$pos = array();
		$prepare = array();
		$counter = sizeof($this->prepared_values);
		$relation = $relation=='LIKE' ? ' LIKE ' : $relation;
		foreach ($values as $key=>$value) {
			if ($scope != 'function') {
				$table_key = (strpos($key, '.') === false && !empty($this->join)) ? "$table.$key" : $key;
				$table_key = $relation==' LIKE ' ? "LOWER($key)" : $table_key;
			}
			$value = $value === false ? 'false' : $value;
			$value = $value === true ? 'true' : $value;
			$value = $relation==' LIKE ' ? mb_strtolower($value) : $value;
			if (is_array($value)) {
				$sub = array();
				foreach($value as $index=>$element) {
					if ($element===null) {
						$rel = $relation=='!=' ? 'IS NOT' : 'IS';
						$sub[] = $scope=='where'
							? "$table_key $rel NULL"
							: ($scope=='function' ? 'NULL' : "$table_key = NULL");
					} else {
						$sub[] = $scope=='function' ? ":where_$counter" : "$table_key$relation:where_$counter";
						$prepare[":where_$counter"] = $element;
						$counter++;
					}
				}
				$operator = ' OR ';
				$pos[] = $scope=="function" ? implode(', ', $sub) : ' (' . implode($operator, $sub) . ') ';
			} else {
				if ($value===null) {
					$rel = $relation=='!=' ? 'IS NOT' : 'IS';
					$pos[] = $scope=='where'
						? "$table_key $rel NULL"
						: ($scope=='function' ? 'NULL' :"$table_key = NULL");
				} else {
					$pos[] = $scope=='function' ? ":where_$counter" : "$table_key$relation:where_$counter";
					$prepare[":where_$counter"] = $value;
					$counter++;
				}
			}
		}
		$this->prepared_values += $prepare;
		return $pos;
	}

	/**
	 * Auxiliary method to reset settings.
	 *
	 * It is usually called in the beginning
	 * or after a query execution.
	 *
	 * @return void
	 */
	private function settingsReset()
	{
		$this->where = [];
		$this->prepared_values = [];
		$this->join = [];
		$this->fields = '*';
		$this->limit = '';
		$this->orderby = '';
		$this->groupby = '';
		$this->fetch = PDO::FETCH_OBJ;
		$this->value = false;
		$this->row = false;
		$this->group = false;
		$this->group_by_id = false;
		$this->unique = false;
	}
}