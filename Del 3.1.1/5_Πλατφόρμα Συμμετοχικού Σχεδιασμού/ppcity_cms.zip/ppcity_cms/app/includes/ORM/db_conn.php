<?php
/**
 * Yet Another Minimalistic ORM.
 *
 * @filesource
 * @author Pantelis Mitropoulos <pantelismitr@gmail.com>
 * @package  Yet Another Minimalistic ORM
 * @version 0.1.0 Development stage
 */

namespace ORM;

use \PDO;
require_once "db_interface.php";
require_once "constructor.php";

/**
 * The minimalistic ORM class.
 *
 * @class_implements(dbInterface)
 */
class DbConn extends PDO implements dbInterface {

	/**
	 * Database name
	 * @var string
	 */
	public $dbname;
	/**
	 * DB host server
	 * @var string
	 */
	public $dbhost;
	/**
	 * DB port
	 * @var string
	 */
	public $dbport;
	/**
	 * DB user name
	 * @var string
	 */
	public $dbuser;
	/**
	 * DB user password
	 * @var string
	 */
	public $dbpassword;
	/**
	 * DB character set
	 * @var string
	 */
	public $charset;
	/**
	 * DB collation set (MySQL only)
	 * @var string
	 */
	public $collate;
	/**
	 * Error message
	 * @var string
	 */
	public $error;
	/**
	 * Contains the db tables for which the changes should be logged
	 * @var array
	 */
	private $logged;

	/**
	 * Class construction method.
	 *
	 * Here the database details are defined and
	 * the connection to db is established.
	 *
	 * @param array $logged (optional)
	 * 	Contains the name of the fields for which
	 * 	the changes will be tracked.
	 *
	 * @return void
	 */
	public function __construct($logged=[])
	{
		$this->logged = $logged;
		$this->dbname = DB_NAME;
		$this->dbhost = DB_HOST;
		$this->dbport = DB_PORT;
		$this->dbuser = DB_USER;
		$this->dbpassword = DB_PASS;
		$this->charset = DB_CHARSET;
		$this->collate = DB_COLLATE;
		$this->adapter = DB_ADAPTER;

		$this->db_connect();
	}

	/**
	 * Connects to the database server.
	 *
	 * @return void
	 */
	protected function db_connect()
	{
		$dsn = "{$this->adapter}:dbname={$this->dbname};host={$this->dbhost};";
		try {
			parent::__construct($dsn, $this->dbuser, $this->dbpassword, array(PDO::MYSQL_ATTR_LOCAL_INFILE=>1));
			$this->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		} catch (PDOException $e) {
			$this->error = $e->getMessage();
			die($this->error . PHP_EOL);
		}
	}

	/**
	 * Selects a function to execute
	 * @param  string $function_name The name of the function to call
	 * @param  array  $args          The arguments to pass to the function
	 * @return Constructor
	 */
	public function sqlFunction($function_name, $args=null)
	{
		$c = new Constructor($this);
		return $c->sqlFunction($function_name, $args);
	}

	/**
	 * Selects a specific schema.
	 *
	 * @param string $schema
	 * @return Constructor
	 */
	public function schema($schema)
	{
		$c = new Constructor($this);
		return $c->schema($schema);
	}

	/**
	 * Set the boolean operator that connect where statements.
	 * @param  string $operator One of 'AND', 'OR'.
	 * @return Constructor
	 */
	public function boolean($operator)
	{
		$c = new Constructor($this);
		return $c->boolean($operator);
	}

	/**
	 * Selects a new type.
	 * @param  string $type
	 * @return Constructor
	 */
	public function type($type)
	{
		$c = new Constructor($this);
		return $c->type($type);
	}

	/**
	 * Creates an enum statement
	 * @param  array $values
	 * @return Constructor
	 */
	public function enum($values)
	{
		$c = new Constructor($this);
		return $c->enum($values);
	}

	/**
	 * Selects a specific table.
	 *
	 * @param mixed $table
	 * @return Constructor
	 */
	public function table($table)
	{
		$c = new Constructor($this);
		return $c->table($table);
	}

	/**
	 * Authorize the current db user.
	 *
	 * @return Constructor
	 */
	public function authorization()
	{
		$c = new Constructor($this);
		return $c->authorization();
	}

	/**
	 * Determines the table as temporary.
	 *
	 * @return Constructor
	 */
	public function temporary()
	{
		$c = new Constructor($this);
		return $c->temporary();
	}

	/**
	 * Select as a table.
	 *
	 * @param string $table
	 * @return Constructor
	 */
	public function asTable($table)
	{
		$c = new Constructor($this);
		return $c->asTable();
	}

	/**
	 * Switch cascade mode on/off.
	 *
	 * @param boolean $mode
	 * @return Constructor
	 */
	public function cascade($mode=true)
	{
		$c = new Constructor($this);
		return $c->cascade($mode);
	}

	/**
	 * Left join with tables.
	 *
	 * @param array $tables
	 * @return Constructor
	 */
	public function leftJoin($tables)
	{
		$c = new Constructor($this);
		return $c->leftJoin($tables);
	}

	/**
	 * Right join with tables.
	 *
	 * @param array $tables
	 * @return Constructor
	 */
	public function rightJoin($tables)
	{
		$c = new Constructor($this);
		return $c->rightJoin($tables);
	}

	/**
	 * Inner join with tables.
	 *
	 * @param array $tables
	 * @return Constructor
	 */
	public function innerJoin($tables)
	{
		$c = new Constructor($this);
		return $c->innerJoin($tables);
	}

	/**
	 * General join (default inner) with tables.
	 *
	 * Parent method for leftJoin, rightJoin and innerJoin methods.
	 *
	 * @param array $tables
	 * 	It has the form ['table1' => ['key1' => 'key2', ...], ...]
	 * @param string $type (optional)
	 * @return Constructor
	 */
	public function join($tables, $type='INNER')
	{
		$c = new Constructor($this);
		return $c->join($tables, $type);
	}

	/**
	 * Determines the fields of a table.
	 *
	 * @param mixed $fields (optional)
	 * @return Constructor
	 */
	public function fields($fields='*')
	{
		$c = new Constructor($this);
		return $c->fields($fields);
	}

	/**
	 * Defines the aggregate function to be used.
	 *
	 * @param string $aggregate_function The PostgreSQL aggregate function to be used.
	 * @param array  $arguments The arguments (fields) that will passed to aggregate function.
	 * @param string $name The name of the resulting field.
	 * @return Constructor
	 */
	public function aggregate($aggregate_function, $arguments, $name)
	{
		$c = new Constructor($this);
		return $c->aggregate($aggregate_function, $arguments);
	}

	/**
	 * Defines a WHERE SQL statement.
	 *
	 * Could either provide the WHERE statement directly by
	 * determining the SQL string either translate an array
	 * into SQL. In the latter case, the keys correspond to
	 * field names, while the values to the values of the
	 * fields, joined with boolean AND. In case the values
	 * are themselves arrays, they are joined with boolean OR.
	 *
	 * @param string|array $conditions
	 * @param string $relation (optional)
	 * @return Constructor
	 */
	public function where($conditions, $relation='=')
	{
		$c = new Constructor($this);
		return $c->where($conditions, $relation);
	}

	/**
	 * Defines a WHERE SQL statement with LIKE as relation operator.
	 *
	 * @param mixed $conditions
	 * @return Constructor
	 */
	public function like($conditions)
	{
		$c = new Constructor($this);
		return $c->like($conditions);
	}

	/**
	 * Defines a PostGIS statement to search for geometries inside the bounding box.
	 * @param  array $within The bounding box in the form [column_name => [xmin, ymin, xmax, ymax, SRID]]
	 * @return Constructor
	 */
	public function within($within)
	{
		$c = new Constructor($this);
		return $c->within($within);
	}

	/**
	 * Creates a point to insert or update a geometric object.
	 * @param  string $coordinates lat;lon
	 * @param  number $srid
	 * @return Constructor
	 */
	public function makePoint($coordinates, $srid)
	{
		$c = new Constructor($this);
		return $c->makePoint($coordinates, $srid);
	}

	/**
	 * Defines a LIMIT statement.
	 *
	 * @param integer $offset
	 * @param integer $count
	 * @return Constructor
	 */
	public function limit($offset, $count)
	{
		$c = new Constructor($this);
		return $c->limit($offset, $count);
	}

	/**
	 * Defines an ORDER BY statement.
	 *
	 * @param string $field
	 * @param string $type (optional) One of 'ASC' [default], 'DESC'
	 * @return Constructor
	 */
	public function orderBy($field, $type='ASC')
	{
		$c = new Constructor($this);
		return $c->orderBy($field, $type);
	}

	/**
	 * Defines a GROUP BY statement.
	 *
	 * @param mixed $fields
	 * @return Constructor
	 */
	public function groupBy($fields)
	{
		$c = new Constructor($this);
		return $c->groupBy($fields);
	}

	/**
	 * Executes a select query.
	 *
	 * It joins all the sql statements, before calling
	 * the parent method for the actual execution.
	 *
	 * @return mixed
	 */
	public function select()
	{
		$c = new Constructor($this);
		return $c->select();
	}

	/**
	 * Counts the results.
	 *
	 * @return  integer The number of results
	 */
	public function count() {
		$c = new Constructor($this);
		return $c->count();
	}

	/**
	 * Executes a CREATE action.
	 *
	 * @return void
	 */
	public function create()
	{
		$c = new Constructor($this);
		return $c->create();
	}

	/**
	 * Executes a DROP action.
	 *
	 * @return void
	 */
	public function drop()
	{
		$c = new Constructor($this);
		return $c->drop();
	}

	/**
	 * Executes a DESCRIBE action.
	 *
	 * @return void
	 */
	public function describe()
	{
		$c = new Constructor($this);
		return $c->describe();
	}

	/**
	 * Executes a SELECT action of the specific content (default: object).
	 *
	 * @param string $type
	 * 	Could be one of object, column, value.
	 *
	 * @return mixed
	 */
	public function fetch($type)
	{
		$c = new Constructor($this);
		return $c->fetch();
	}

	/**
	 * Check for the existence of a value.
	 *
	 * @return boolean
	 */
	public function exists()
	{
		$c = new Constructor($this);
		return $c->exists();
	}

	/**
	 * Change return type to associative array by keys.
	 *
	 * @return void
	 */
	public function group()
	{
		$c = new Constructor($this);
		return $c->group();
	}

	/**
	 * Change return type to associative array grouped by id.
	 *
	 * @return void
	 */
	public function groupById()
	{
		$c = new Constructor($this);
		return $c->groupById();
	}

	/**
	 * Change return type to column unique values.
	 *
	 * @return void
	 */
	public function unique()
	{
		$c = new Constructor($this);
		return $c->unique();
	}

	/**
	 * Insert a row into a table.
	 *
	 * @param object $data
	 * 	The data to be inserted in the form field->value.
	 * @return void
	 */
	public function insert($data)
	{
		$c = new Constructor($this);
		return $c->insert($data);
	}

	/**
	 * Deletes a selected row from a table.
	 *
	 * @return void
	 */
	public function delete() {
		$c = new Constructor($this);
		return $c->delete();
	}

	/**
	 * Updates data in a table.
	 *
	 * @param array $data
	 * 	An associative array with the corresponding new values.
	 * @return void
	 */
	public function update($data) {
		$c = new Constructor($this);
		return $c->update($data);
	}

}