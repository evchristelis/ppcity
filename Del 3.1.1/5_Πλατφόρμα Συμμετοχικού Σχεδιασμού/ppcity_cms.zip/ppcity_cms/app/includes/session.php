<?php
defined( 'ABSPATH' ) or die( 'Sorry, direct access is forbidden.' );
use Api\Model\UserInfo;

class session {

	public $user, $id, $name, $runlevel, $messages;

	public function __construct($user=null, $session=null, $messages=null)
	{
		$this->user = isset($user) ? $user : (object)['role' => 'guest', 'uuid' => ''];
		$this->id = isset($session) ? $session['id'] : session_id();
		$this->name = isset($session) ? $session['name'] : session_name();
		$this->token = isset($session) ? $session['token'] : hash_hmac("sha256", $this->id, APPSEC);
		// $secure = ENV == 'production' ? true : false;
		$secure = false;
		setcookie($this->name, $this->id, time()+3600, '/', "", $secure, true);
		setcookie("token", $this->token, time()+3600, '/', "", $secure, false);

		$this->messages = (isset($messages)) ? $messages : array();
	}

	public function __destruct()
	{
		$_SESSION['session'] = serialize($this);
	}

	/**
	 * Update the user profile, useful e.g. in case of profile update.
	 * @return void
	 */
	public function update()
	{
		global $db;
		$this->user = $db->table(UserInfo::table)
						 ->fields(UserInfo::$visible)
						 ->join(UserInfo::$join)
						 ->where(['uuid' => $this->user->uuid])
						 ->fetch()[0];
	}

}
