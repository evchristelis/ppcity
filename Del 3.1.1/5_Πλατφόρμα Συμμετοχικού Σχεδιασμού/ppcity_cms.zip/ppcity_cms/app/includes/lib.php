<?php
/**
 * A collection of pure functions for global use.
 */

declare(strict_types=1);

define('APPLICATION_STATUS', ['progressing', 'with_editor', 'under_review', 'author_actions', 'under_editor_evaluation', 'revise', 'rejected', 'accepted', 'completed', 'on_hold', 'suspended']);

define('APPLICATION_ROLES', ['author', 'editor', 'reviewer']);

define('SYSTEM_ROLES', ['admin', 'editor', 'reviewer', 'guest']);


function parseURL($url): array
{
	$values = explode('/', $url);
	$params = [];
	foreach ($values as $index => $value) {
		if ($index%2 == 0) {
			$key = $value;
		} else {
			$params[$key] = $value;
		}
	}
	return $params;
}

/**
 * Create a uuid using random bytes.
 * @return string UUID
 */
function uuid(): string
{
        $data = random_bytes(16);
        $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
        $data[8] = chr(ord($data[8]) & 0x3f | 0x80);
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
}

/**
 * Parse a string replacing shortcodes.
 *
 * Shortcodes are either in the form [[table::field]] which will
 * be replaced by the corresponding values in the database either
 * in the form [[code]] which will be replaced by the appropriate
 * calculated values.
 *
 * @param  string $html     The string which will be searched for shortcodes.
 * @param  string $id 		The uuid of the db entry.
 * @return string           The resulting string
 */
function parseHtml(string $html, string $id): string
{
	global $db;

	$patterns = [
		'sql' => "/\[\[(?<table>[a-z.]+)::(?<field>[a-z]+)\]\]/m",
		'plain' => "/\[\[(?<plain>[a-z]+)\]\]/m"
	];

	foreach ($patterns as $key => $pattern) {
		preg_match_all($pattern, $html, $$key, PREG_SET_ORDER);
	}

	$patterns = [];
	foreach ($sql as $match) {
		$table = $match['table'];
		$field = $match['field'];
		$createToken = false;
		$sub = $db->table($table)
				  ->fields($field)
				  ->where(['uuid' => $id])
				  ->fetch('value');
		$patterns["/\[\[$table::$field\]\]/m"] = $sub;
	}

	foreach ($patterns as $pattern => $sub) {
		$html = preg_replace($pattern, $sub, $html);
	}

	return $html;
}

function createToken(string $uuid, string $scope): string
{
	global $db;
	try {
		$token = hash_hmac('sha256', $uuid, SALT);
		$table = 'core.tokens';
		$exists = $db->table($table)
					 ->where(['uuid' => $uuid, 'scope' => $scope])
					 ->exists();
		if ($exists) {
			$db->table($table)
			   ->where(['uuid' => $uuid, 'scope' => $scope])
			   ->update(['token' => $token, 'created' => now()]);
		} else {
			$db->table($table)
			   ->insert(['uuid' => $uuid, 'token' => $token, 'scope' => $scope, 'created' => now()]);
		}
	} catch (Exception $e) {
		throw $e;
	}

	return $token;
}

/**
 * Sends email using a preconfigured template.
 *
 * Actually, this function does not send the emails itself,
 * but it inserts a row to a table which should trigger an
 * event. An external script should listen on this event and
 * finally send the email.
 * @param  string $user     The recipient's uuid or username
 * @param  string $template The template which will be used for the email
 * @return void
 */
function sendEmail($user, $template)
{
	global $db;
	try {
		$email = $db->table('core.template')
					->where(['type' => $template])
					->select();

		if (empty($email)) {
			return;
		} else {
			$email = $email[0];
		}

		$field = (preg_match("/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/", $user)) ? 'uuid' : 'username';
		$address = $db->table('core.users')
					  ->fields('email')
					  ->where([$field => $user])
					  ->fetch('value');

		$uuid = $field=='uuid' ? $user : $db->table('core.users')->fields('uuid')->where(['username' => $user])->fetch('value');
		$body = parseHtml($email->html, $uuid);
		$db->table('actions.email')
		   ->insert([
		   		'address' => $address,
		   		'subject' => $email->subject,
		   		'body' => $body
		   ]);
	} catch (Exception $e) {
		throw $e;
	}
}

/**
 * Check whether the session user has the specific role(s).
 * @param  string|array  $role
 * @return boolean
 */
function hasRole($role): bool
{
	global $session;
	if (empty($role)) {
		return true;
	} else if (empty($session->user)) {
		return false;
	} else {
		$role = is_string($role) ? [$role] : $role;
		return !(array_search($session->user->role, $role) === false);
	}
}

/**
 * Check whether the session user has editor permissions on workflows.
 * @return boolean
 */
function canEdit(): bool
{
	global $session;
	if (empty($session->user))
		return false;
	$role = $session->user->role;
	return ($role=='ADMIN' || $role=='EDITOR');
}

/**
 * Check whether the session user can review a workflow.
 * @return boolean
 */
function canReview(): bool
{
	global $session;
	if (empty($session->user))
		return false;
	$role = $session->user->role;
	return ($role=='ADMIN' || $role=='EDITOR' || $role=='REVIEWER');
}

/**
 * Returns the timestamp in sql-friendly format.
 * @return string
 */
function now(): string
{
	$timestamp = date('Y-m-d G:i:s');
	return $timestamp;
}
