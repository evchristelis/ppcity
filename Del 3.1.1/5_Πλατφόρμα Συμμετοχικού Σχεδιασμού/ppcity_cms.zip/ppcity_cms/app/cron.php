#!/usr/bin/env php
<?php
(PHP_SAPI !== 'cli' || isset($_SERVER['HTTP_USER_AGENT'])) && die('cli only');

define('ABSPATH', __DIR__ . '/');

require_once ABSPATH . 'config.php';
require_once ABSPATH . 'includes/ORM/db_conn.php';
require_once ABSPATH . 'includes/model/application.php';
require_once ABSPATH . 'includes/model/inactive_applications.php';
require_once ABSPATH . 'includes/model/application_data.php';
require_once ABSPATH . 'includes/model/inactive_data.php';

use ORM\DbConn;
use Api\Model\Application, Api\Model\ApplicationData;
use Api\Model\InactiveApplications, Api\Model\InactiveData;

$src1 = Application::table;
$tgt1 = InactiveApplications::table;
$src2 = ApplicationData::table;
$tgt2 = InactiveData::table;

$db = new DbConn($db_credentials);

try {
	$db->beginTransaction();
	$sql = "
WITH moved_rows AS (
	DELETE FROM $src1
	WHERE status = 'progressing' AND age(now(), last_action) > '6 months'
	RETURNING workflow, workflow_revision, \"name\", uuid, author, reviewer, created, current_node, revision, \"final\", primary_registry, editor, last_action, secondary_registry
), inserted AS (
	INSERT INTO $tgt1 (workflow, workflow_revision, \"name\", uuid, author, reviewer, created, current_node, revision, \"final\", primary_registry, editor, last_action, secondary_registry)
	SELECT * FROM moved_rows
	RETURNING uuid AS a_uuid
)
INSERT INTO $tgt2
SELECT * FROM $src2
WHERE a_uuid IN (SELECT uuid FROM moved_rows);
	";
	$db->exec($sql);
	$db->commit();
} catch (Exception $e) {
	$msg = $e->getMessage();
}

$sql = "DELETE FROM $tgt1 WHERE age(now(), inactive_date) > '1 month'";
$db->exec($sql);
