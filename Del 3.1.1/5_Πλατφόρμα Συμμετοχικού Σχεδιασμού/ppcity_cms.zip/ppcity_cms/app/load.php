<?php

if (!defined('ABSPATH'))
	define( 'ABSPATH', dirname(__FILE__) . '/' );

include ABSPATH . '../vendor/autoload.php';
require_once ABSPATH . 'config.php';
require_once ABSPATH . 'includes/ORM/db_conn.php';
require_once ABSPATH . 'includes/session.php';
require_once ABSPATH . 'includes/xhr.php';
// require_once ABSPATH . 'includes/login.php';
require_once ABSPATH . 'includes/PHPMailer/index.php';

use ORM\DbConn;

session_start();

if ( isset($_SESSION['session'])  ) {
	$session = unserialize($_SESSION['session']);
	$session = new session($session->user, array('id'=>$session->id, 'name'=>$session->name, 'token'=>$session->token));
} else {
	$session = new session();
}

$db = !isset($db) ? new DbConn() : $db;
// $variables = !isset($variables) ? new variables() : $variables;
// $messages = !isset($messages) ? new Messages() : $messages;

$GLOBALS['db'] = $db;
$GLOBALS['session'] = $session;
