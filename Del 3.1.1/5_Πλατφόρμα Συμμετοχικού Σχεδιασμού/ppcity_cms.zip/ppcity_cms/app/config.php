<?php
defined( 'ABSPATH' ) or die( 'Sorry, direct access is forbidden.' );

// Application salt
define('APPSEC', "zB[su7Pgp^G5'TMD");

require_once ABSPATH . 'includes/lib.php';
require_once ABSPATH . '../vendor/autoload.php';
use Symfony\Component\Yaml\Yaml;

try {
	$settings = (object)Yaml::parseFile(ABSPATH . '../config.yml');
} catch (Exception $e) {
	$message = 'Something is going wrong with the configuration file.';
	$message = php_sapi_name() === 'cli'
		? "\033[01;31m$message\033[0m" . PHP_EOL
		: '<span style="color: red">' . $message . '</span>';
	die($message);
}

define('ENV', $settings->global['environment']);
define('PASS_COST', 10);
define('BASE_URL', $settings->global['hostname']);
define('DATA_PATH', ABSPATH . '../' . $settings->global['data_path']);
define('SALT', 'j?9?KCLe5dHmxKf3');

$db_credentials = $settings->environments[ENV];

foreach ($db_credentials as $key => $value) {
	define('DB_' . strtoupper($key), $value);
}