import React, { Component } from 'react';

class Footer extends Component {

	render() {

		return (
			<footer className="app-footer">
				<span>
					<img width={200} height="auto" src="/espa.jpg" alt="getmap" />
				</span>
				<span className="ml-auto">Power By<a target="_blank" href="http://getmap.eu" rel="noopener noreferrer">{' '}Geospatial Enabling Technologies{' '}</a><a target="_blank" href="http://getmap.eu" rel="noopener noreferrer"><img width={36} height="auto" src="/get-small-logo.png" alt="getmap" /></a></span>
			</footer>
		);
	}
}

export default Footer;
