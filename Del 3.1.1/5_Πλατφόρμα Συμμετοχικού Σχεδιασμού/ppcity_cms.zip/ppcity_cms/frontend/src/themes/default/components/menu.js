import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import { Nav, NavItem } from 'reactstrap';

import { menuItems as moduleItems } from 'modules';
import * as roles from 'core/model/roles';
import T from 'modules/i18n';

class Menu extends Component {

	render() {

		const front = {name: 'front', url: '/', role: roles.GUEST};

		const menuItems = [front, ...moduleItems];

		let items = menuItems
			.filter(item => (item.role === roles.GUEST))
			.map((item, index) => (
				<NavItem key={`menu_item_${index}`}>
					<NavLink exact lang="el" to={item.url || ''} className="menu-items">
						<T>{item.name}</T>
					</NavLink>
				</NavItem>
			));

		return (
			<Nav className={'ml-auto navbar ' + this.props.className}>
				{items}
			</Nav>
		);
	}
}

export default Menu;
