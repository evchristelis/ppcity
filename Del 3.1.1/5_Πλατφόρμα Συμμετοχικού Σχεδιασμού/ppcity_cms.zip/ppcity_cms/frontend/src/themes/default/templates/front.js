import React, { Component } from 'react';
import { withRouter } from "react-router";
import { Container } from 'reactstrap';

import { Header, Footer } from '../components';

import '../style/style.scss';

class Front extends Component {

	constructor(props) {
		super(props);
		this.state = {
			scrolled: false,
		};

		this.handleScroll = this.handleScroll.bind(this);
	}

	componentDidMount() {
		document.addEventListener('scroll', this.handleScroll);
	}

	componentWillUnmount() {
		document.removeEventListener('scroll', this.handleScroll);
	}

	handleScroll() {
		const isAtTop = (window.pageYOffset < 85);
		if (isAtTop) {
			if (this.state.scrolled)
				this.setState({scrolled: false});
		} else {
			if (!this.state.scrolled)
				this.setState({scrolled: true});
		}
	}

	render() {

		const cssClasses = [
			'app',
			'header-fixed',
			'sidebar-hidden',
			'sidebar-minimized',
			'default-theme',
			this.state.scrolled ? 'scrolled' : null
		];

		return (
			<div className={cssClasses.join(' ')}>
				<Header/>
				{ this.props.location.pathname === '/' &&
					<div className="top-image"/>
				}
				<div className="app-body">
					<div id="main" className="main">
						<Container fluid>
							<div className="animated fadeIn content">
								{this.props.children}
							</div>
						</Container>
					</div>
				</div>
				<Footer />
			</div>
		);
	}
}

export default withRouter(Front);
