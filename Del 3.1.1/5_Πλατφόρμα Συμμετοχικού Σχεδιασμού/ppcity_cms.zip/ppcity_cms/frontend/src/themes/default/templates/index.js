export { default as Template } from './front';
