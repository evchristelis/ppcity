import React, { Component } from 'react';
import { withRouter } from "react-router";
import { connect } from 'react-redux';
import {
	Navbar,
	NavbarBrand,
	Dropdown,
	DropdownMenu,
	DropdownToggle
} from 'reactstrap';

import Menu from './menu';
import { toggleMobileSidebar } from 'core/ducks/ui/menu';

class Header extends Component {

	render() {

		const { showMenu, dispatch } = this.props;

		return (
			<Navbar className="app-header">
				<NavbarBrand target="_blank" href="https://ppcity.eu//"></NavbarBrand>
				<Dropdown className="d-lg-none" isOpen={showMenu} toggle={() => dispatch(toggleMobileSidebar())}>
					<DropdownToggle style={{backgroundColor: 'inherit', borderWidth: 0}}>
						<span className="navbar-toggler-icon"/>
					</DropdownToggle>
					<DropdownMenu style={{padding: 0}}>
						<Menu className="main-dropdown-menu"/>
					</DropdownMenu>
				</Dropdown>
				<Menu className="d-none d-lg-flex"/>
			</Navbar>
		);
	}
}

const mapStateTopProps = (state) => ({
	showMenu: state.ui.menu.sidebarMobileShow,
});

Header = connect(mapStateTopProps)(Header);

export default withRouter(Header);
