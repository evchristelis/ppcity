import React, { Component } from 'react';

class Footer extends Component {
	render() {
		return (
			<>
				<span><a target="_blank" href="http://getmap.eu" rel="noopener noreferrer">{' '}Geospatial Enabling Technologies</a> &copy; 2019</span>
				<span className="ml-auto">Powered by <a target="_blank" href="http://getmap.eu" rel="noopener noreferrer"><img width={36} height="auto" src="/get-small-logo.png" alt="getmap" /></a></span>
			</>
		);
	}
}

export default Footer;
