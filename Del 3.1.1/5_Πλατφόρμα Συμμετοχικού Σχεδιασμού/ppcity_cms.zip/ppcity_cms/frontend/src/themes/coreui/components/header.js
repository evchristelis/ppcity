import React, { Component } from 'react';
import { connect } from 'react-redux';
import {
	AppNavbarBrand as NavbarBrand,
} from '@coreui/react';
import { NavbarToggler } from 'reactstrap';

import { Header as CoreHeader } from 'core/components';
import { toggleSidebar, toggleMobileSidebar, toggleMobileAside, toggleAside } from 'core/ducks/ui/menu';

class Header extends Component {

	constructor(props) {
		super(props);
		this.handleNavbarToggler = this.handleNavbarToggler.bind(this);
		this.handleMobileNavbarToggler = this.handleMobileNavbarToggler.bind(this);
		this.handleAsideToggler = this.handleAsideToggler.bind(this);
		this.handleMobileAsideToggler = this.handleMobileAsideToggler.bind(this);
	}

	handleNavbarToggler() {
		this.props.dispatch(toggleSidebar());
	}

	handleMobileNavbarToggler() {
		this.props.dispatch(toggleMobileSidebar());
	}

	handleAsideToggler() {
		this.props.dispatch(toggleAside());
	}

	handleMobileAsideToggler() {
		this.props.dispatch(toggleMobileAside());
	}

	render() {
		return (
			<header className="app-header navbar bg-secondary">
				<NavbarToggler
					className="d-lg-none"
					display="md"
					onClick={this.handleMobileNavbarToggler}
				/>
				<NavbarBrand
					target="_blank"
					href="https://chalandri.gr/"
					rel="noopener noreferrer"
					full={{
						src: '/img/logo.png',
						width: 140,
						height: 29,
						alt: 'Logo'
					}}
					minimized={{
						src: '/img/logo-symbol.png',
						width: 30,
						height: 30,
						alt: 'Logo'
					}}
				/>
				<NavbarToggler
					className="d-md-down-none mr-auto"
					onClick={this.handleNavbarToggler}
				/>
				<CoreHeader />
				<NavbarToggler
					className="d-md-down-none"
					onClick={this.handleAsideToggler}
				/>
				<NavbarToggler
					className="d-lg-none"
					onClick={this.handleMobileAsideToggler}
				/>
			</header>
		);
	}
}

Header = connect(null)(Header);

export default Header;
