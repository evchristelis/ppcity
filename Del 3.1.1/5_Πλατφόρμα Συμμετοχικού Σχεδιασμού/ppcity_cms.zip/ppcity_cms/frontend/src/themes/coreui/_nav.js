import { StaticRoutes } from 'core/model/routes';
// import { buildPath } from 'core/model/lib/urlTools';
import * as roles from 'core/model/roles';
import { menuItems } from 'modules';

export default {
	items: [
		{
			name: 'dashboard',
			url: StaticRoutes.AdminDashboard,
			icon: 'icon-speedometer',
			role: roles.REVIEWER
		},
		{
			name: 'dashboard',
			url: StaticRoutes.Dashboard,
			icon: 'icon-speedometer',
			role: roles.GUEST
		},
		...menuItems,
		// {
		// 	name: 'settings',
		// 	url: StaticRoutes.Settings,
		// 	icon: 'icon-wrench',
		// 	role: roles.ADMIN,
		// 	children: [
		// 		{
		// 			name: 'messages',
		// 			url: StaticRoutes.SettingsMessages
		// 		},
		// 		{
		// 			name: 'templates',
		// 			url: StaticRoutes.Templates
		// 		},
		// 		// {
		// 		// 	name: 'SMTP',
		// 		// 	url: StaticRoutes.SMTP
		// 		// }
		// 		{
		// 			name: 'register fields',
		// 			url: StaticRoutes.RegisterFields
		// 		},
		// 		{
		// 			name: 'pdf templates',
		// 			url: StaticRoutes.PdfTemplates
		// 		}
		// 	]
		// },
		// {
		// 	name: 'edit',
		// 	url: StaticRoutes.Edit,
		// 	icon: 'icon-pencil',
		// 	role: roles.ADMIN,
		// 	children: [
		// 		{
		// 			name: 'forms',
		// 			url: StaticRoutes.EditForms
		// 		},
		// 		{
		// 			name: 'draw workflow',
		// 			url: StaticRoutes.EditWorkflows
		// 		}
		// 	]
		// },
		// {
		// 	name: 'users',
		// 	url: StaticRoutes.Users,
		// 	icon: 'icon-people',
		// 	role: roles.ADMIN,
		// 	children: [
		// 		{
		// 			name: 'list',
		// 			icon: 'icon-list',
		// 			url: StaticRoutes.UsersList
		// 		},
		// 		{
		// 			name: 'add',
		// 			icon: 'icon-plus',
		// 			url: StaticRoutes.UsersAdd,
		// 			role: roles.ADMIN
		// 		}
		// 	]
		// },
		// {
		// 	name: 'users',
		// 	url: StaticRoutes.UsersList,
		// 	icon: 'icon-people',
		// 	role: [roles.EDITOR, roles.REVIEWER]
		// },
		// {
		// 	name: 'workflows',
		// 	url: StaticRoutes.AdminWorkflowsList,
		// 	icon: 'fa fa-tasks',
		// 	role: roles.REVIEWER
		// },
		// {
		// 	name: 'QR Reader',
		// 	url: StaticRoutes.QRReader,
		// 	icon: 'fa fa-qrcode',
		// 	role: roles.REVIEWER,
		// },
		// {
		// 	name: 'organizations',
		// 	url: StaticRoutes.Organizations,
		// 	icon: 'fa fa-university',
		// 	role: roles.GUEST,
		// 	children: [
		// 		{
		// 			name: 'your organizations',
		// 			url: StaticRoutes.OrganizationsList,
		// 			role: roles.GUEST,
		// 		},
		// 		{
		// 			name: 'new organization',
		// 			url: buildPath(DynamicRoutes.Workflows, ['foreas']),
		// 			role: roles.GUEST,
		// 		}
		// 	]
		// },
		// {
		// 	name: 'register_application',
		// 	url: StaticRoutes.WorkflowDashboard,
		// 	icon: 'icon-plus',
		// 	role: roles.GUEST
		// },
		// {
		// 	name: 'workflows',
		// 	url: StaticRoutes.WorkflowsList,
		// 	icon: 'icon-book-open',
		// 	role: roles.GUEST
		// },
		// {
		// 	name: 'inactive_workflows',
		// 	url: StaticRoutes.Inactive,
		// 	icon: 'icon-trash',
		// 	role: roles.GUEST
		// },
		// {
		// 	name: 'map',
		// 	url: StaticRoutes.WorkflowsMap,
		// 	icon: 'icon-map',
		// 	role: roles.REVIEWER
		// },
		// {
		// 	name: 'notify',
		// 	url: buildPath(DynamicRoutes.Workflows, ['notify_business']),
		// 	icon: 'fa fa-exclamation',
		// 	role: roles.REVIEWER
		// }
	]
};
