import React, { Component } from 'react';

class Aside extends Component {

	constructor(props) {
		super(props);
		this.isResizing = false;
		this.state = {
			width: 0,
		}

		this.container = React.createRef();

		this.startResize = this.startResize.bind(this);
		this.stopResize = this.stopResize.bind(this);
		this.resize = this.resize.bind(this);
		this.resetSize = this.resetSize.bind(this);
	}

	startResize(e) {
		e.preventDefault();
		this.isResizing = true;
	}

	resize(e) {
		if (!this.isResizing)
			return;
		e.preventDefault();
		const container = this.container.current;
		const width = container.clientWidth - (e.clientX - container.offsetLeft);
		if ( Math.abs(width - this.state.width) > 10 )
			this.setState({ width });
	}

	stopResize(e) {
		this.isResizing = false;
	}

	resetSize(e) {
		this.setState({
			width: this.state.initialWidth,
		});
	}

	componentDidMount() {
		this.setState({
			width: this.container.current.clientWidth,
			initialWidth: this.container.current.clientWidth
		})
		document.addEventListener('mousemove', this.resize);
		document.addEventListener('mouseup', this.stopResize);
	}

	componentWillUnmount() {
		document.removeEventListener('mousemove', this.resize);
		document.removeEventListener('mouseup', this.stopResize);
	}

	render() {
		const Sidebar = this.props.sidebar;
		return (
			<aside className="aside-menu" ref={this.container} style={{width: this.state.width + 'px', minWidth: this.state.width}}>
				<div
					className="aside-menu-resizer"
					onMouseDown={this.startResize}
					onDoubleClick={this.resetSize}
					style={{right: this.width - 4 + 'px'}}
				/>
				<Sidebar content={this.props.content} />
			</aside>
		);
	}
}

export default Aside;
