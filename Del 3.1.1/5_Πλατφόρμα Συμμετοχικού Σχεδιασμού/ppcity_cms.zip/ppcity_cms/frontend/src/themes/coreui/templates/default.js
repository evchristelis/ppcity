import React, { Component, Suspense } from 'react';
import { Container } from 'reactstrap';
import { withRouter } from 'react-router';
import { connect } from 'react-redux';

import {
	AppSidebarNav,
	AppFooter,
	AppHeader,
	AppBreadcrumb
} from '@coreui/react';

import nav from '../_nav';
import { hierarchy } from 'core/model/roles';
import T from 'modules/i18n';
import { minimizeSidebar } from 'core/ducks/ui/menu';
import { matchRoute } from 'core/model/lib/urlTools';

const Aside = React.lazy(() => import('../components/aside'));
const Footer = React.lazy(() => import('../components/footer'));
const Header = React.lazy(() => import('../components/header'));

class DefaultTemplate extends Component {

	constructor(props) {
		super(props);
		let navigation = {
			items: []
		};
		this.state = { navigation, routes: [] };
	}

	componentDidMount() {
		const navigation = this.sanitizeNavigation(nav);
		const routes = this.sanitizeRoutes(this.props.routes);
		this.setState({ navigation, routes });
	}

	loading = () => <div className="animated fadeIn pt-1 text-center">Loading...</div>

	sanitizeNavigation = (navigation) => {
		const { user } = this.props;
		const items = navigation.items.filter(elem => {
			if (!elem.role)
				return true;
			const role = elem.role;
			if (!user || !role)
				return false;
			if (Array.isArray(role))
				return role.includes(user.role);
			if (hierarchy.indexOf(role) === -1)
				return false;
			if (hierarchy.indexOf(role) === hierarchy.length - 1)
				return role === user.role;
			return (hierarchy.indexOf(role) >= hierarchy.indexOf(user.role));
		}).map(elem => {
			const { name } = elem;
			elem.name = <T>{name}</T>;
			if (elem.children)
				elem.children = this.sanitizeNavigation({items: elem.children}).items;
			return elem;
		});
		return {items};
	}

	sanitizeRoutes = (routes) => {
		const { messages } = this.props.i18n || {messages: {}};
		const items = Object.keys(routes).map((path) => {
			let elem = routes[path];
			elem.path = path;
			elem.name = messages[elem.name] || elem.name;
			return elem;
		});
		return items;
	}

	toggleSidebarMinimize = () => {
		this.props.dispatch(minimizeSidebar());
	}

	render() {
		const { children, menuStatus, routes, sidebar, ...other } = this.props;
		const { sidebarOpen, sidebarMinimized, sidebarMobileShow, hideAsideMenu, hideAsideMobileMenu } = menuStatus;

		const cssClasses = [
			'app',
			'sidebar-fixed',
			sidebarOpen ? 'sidebar-lg-show' : null,
			sidebarMinimized ? 'sidebar-minimized brand-minimized' : null,
			sidebarMobileShow ? 'sidebar-show' : null,
			hideAsideMenu ? null : 'aside-menu-lg-show',
			hideAsideMobileMenu ? null : 'aside-menu-show'
		].filter(className => className);

		if (this.state.routes.length === 0)
			return null;

		return (
			<div className={cssClasses.join(' ')}>
				<AppHeader fixed>
					<Suspense fallback={this.loading()}>
						<Header />
					</Suspense>
				</AppHeader>
				<div className="app-body">
					<div className="sidebar">
						<AppSidebarNav navConfig={this.state.navigation} {...other} />
						<button
							className="sidebar-minimizer"
							type="button"
							onClick={this.toggleSidebarMinimize}
						/>
					</div>
					<main className="main">
						<AppBreadcrumb appRoutes={this.state.routes}/>
						<Container fluid>
							<div className="animated fadeIn">
								{this.props.children || null}
							</div>
						</Container>
					</main>
					<Suspense fallback={this.loading()}>
						<Aside
							sidebar={sidebar}
							content={routes[matchRoute(this.props.location.pathname, routes)].contextComponent}
							/>
					</Suspense>
				</div>
				<AppFooter>
					<Suspense fallback={this.loading()}>
						<Footer />
					</Suspense>
				</AppFooter>
			</div>
		);
	}
}

const mapStateToProps = (state) => ({
	user: state.profile.user,
	menuStatus: state.ui.menu,
	i18n: state.i18n
});

DefaultTemplate = connect(mapStateToProps)(DefaultTemplate);

export default withRouter(DefaultTemplate);
