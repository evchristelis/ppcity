import * as reducers from './ducks';
import * as layout from './views/layout';
import { default as routes } from './model/routes';
import * as headerItems from './components/headerItems';

export default { reducers, layout, ...routes, headerItems };
