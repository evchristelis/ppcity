import React, { Component } from 'react';
import { Button as ReactstrapButton } from 'reactstrap';
import { TableContextConsumer } from './table';

class Button extends Component {

	render() {
		let { type, disabled, ...other } = this.props;
		let button;
		switch (type) {
			case 'toolbox':
				button = (
					<TableContextConsumer>
						{ (context) =>
							<i
								{...other}
								className={`fa fa-1x fa-filter ${this.props.className}`}
								role="button"
								onClick={context.onToolboxButtonClick}
							/>
						}
					</TableContextConsumer>
				);
				break;

			case 'resetFilters':
				button = (
					<TableContextConsumer>
						{ (context) =>
							<ReactstrapButton
								{...other}
								className={`mt-3 ${this.props.className}`}
								type="reset"
							>
								{this.props.children}
							</ReactstrapButton>
						}
					</TableContextConsumer>
				);
			break;

			case 'csv':
				button = (
					<span
						{...other}
						className={`px-3 ${this.props.className}`}
						role="button"
					>
						<i className="fa fa-file-text py-3 px-1" />
						{this.props.children}
					</span>
				);
				break;

			case 'view':
			case 'edit':
			case 'drop':
			case 'activate':
				let buttonClass;
				if (type === 'view') {
					buttonClass = 'fa fa-eye'
				} else if (type === 'edit') {
					buttonClass = 'fa fa-pencil-square-o'
				} else if (type === 'drop') {
					buttonClass = 'fa fa-trash-o';
				} else {
					buttonClass = 'fa fa-check-circle-o';
				}
				let { index } = this.props.data;
				// let data = type=='view' ? unindexed_data : (type=='drop' ? index : this.props.data);
				let data = (type==='drop' || type==='activate') ? index : this.props.data;
				disabled = (disabled && typeof disabled==='function')
					? disabled(this.props.data)
					: false;
				let disabledClass = disabled ? 'text-muted' : '';
				button = (
					<i
						{...other}
						className={`${buttonClass} ${this.props.className} ${disabledClass}`}
						role={disabled ? '' : 'button'}
						onClick={() => {
							if (disabled)
								return null;
							if (typeof this.props.onClick === 'function')
								this.props.onClick(data);
						}}
					/>
				);
				break;

			default:
				button = null;
		}
		return button;
	}
}

Button.displayName = 'Button';

export default Button;
