import { default as routes } from './model/routes';
import { default as menuItems } from './menu';
import * as layout from './views/layout';
import * as sidebars from './views/sidebars';

export default { ...routes, menuItems, layout, sidebars };
