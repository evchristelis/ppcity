import {inherits as ol_inherits} from 'ol'
import ol_control_LayerSwitcher from 'ol-ext/control/LayerSwitcher'
import ol_ext_element from 'ol-ext/util/element';

/**
 * OpenLayers Layer Switcher Control.
 *
 * @constructor
 * @extends {ol_control_LayerSwitcher}
 * @param {Object=} options Control options.
 */
let ol_control_LayerPopup = function (options) {
    options = options || {};
    options.switcherClass = "ol-layerswitcher-popup";
    if (options.mouseover !== false) options.mouseover = true;
    ol_control_LayerSwitcher.call(this, options);
};
ol_inherits(ol_control_LayerPopup, ol_control_LayerSwitcher);

/** Disable overflow
 */
ol_control_LayerPopup.prototype.overflow = function () {
};

/** Render a list of layer
 * @param {elt} element to render
 * @layers {Array{ol.layer}} list of layer to show
 * @api stable
 */
ol_control_LayerPopup.prototype.drawList = function (ul, layers) {
    let self = this;

    let setVisibility = function (e) {
        e.preventDefault();
        let l = self._getLayerForLI(this);
        self.switchLayerVisibility(l, layers);
        if (e.type === "touchstart") self.element.classList.add("ol-collapsed");
    };

    layers.forEach(function (layer) {
        if (self.displayInLayerSwitcher(layer)) {

            // title
            let d = ol_ext_element.create('LI', {
                html: layer.get("title") || layer.get("name"),
                on: {'click touchstart': setVisibility},
                parent: ul
            });

            // legend
            let legend = ol_ext_element.create('DIV', {
                html: '<img src="' + layer.get('source').urls[0] + '?REQUEST=GetLegendGraphic&VERSION=1.0.0&FORMAT=image/png&LAYER=' + layer.get("id") + '" alt="legend" >',
                parent: d
            });

            // // opacity
            // let opacity = ol_ext_element.create('DIV', {
            //     className: 'layerswitcher-opacity',
            //     click: function(e){
            //         if (e.target !== this) return;
            //         e.stopPropagation();
            //         e.preventDefault();
            //         let op = Math.max ( 0, Math.min( 1, e.offsetX / ol_ext_element.getStyle(this, 'width')));
            //         layer.setOpacity(op);
            //     },
            //     parent: d
            // });
            // // Start dragging
            // ol_ext_element.create('DIV', {
            //     className: 'layerswitcher-opacity-cursor',
            //     style: { left: (layer.getOpacity()*100)+"%" },
            //     on: {
            //         'mousedown touchstart': function(e) { self.dragOpacity_ (e); }
            //     },
            //     parent: opacity
            // });

            self._setLayerForLI(d, layer);

            if (self.testLayerVisibility(layer)) d.classList.add("ol-layer-hidden");
            if (layer.getVisible()) d.classList.add("select");
        }
    });
};

export default ol_control_LayerPopup
