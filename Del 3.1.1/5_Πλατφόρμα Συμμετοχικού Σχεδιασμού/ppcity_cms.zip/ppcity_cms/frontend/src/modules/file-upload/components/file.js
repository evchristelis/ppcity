import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { FilePond, File as FileElem, registerPlugin } from 'react-filepond';
import FilePondPluginFileValidateType from 'filepond-plugin-file-validate-type';
import FilePondPluginFileValidateSize from 'filepond-plugin-file-validate-size';
import 'filepond/dist/filepond.min.css';

import en from '../i18n/en';
import el from '../i18n/el';
import { Api } from 'core/api';

registerPlugin(FilePondPluginFileValidateType, FilePondPluginFileValidateSize);

class File extends Component {

	constructor(props) {
		super(props);
		this.api = new Api('upload');
		this.state = {
			value: props.value,
			files: {},
			i18n: {en, el}
		}

		this.handleLocationResponse = this.handleLocationResponse.bind(this);
		this.handleRemove = this.handleRemove.bind(this);
	}

	handleLocationResponse(response) {
		this.setState({
			value: response.replace(/"/g,"")
		});
		this.props.onChange({target: {name: this.props.name, value: this.state.value}});
		return response;
	}

	handleRemove() {
		this.setState({
			value: ''
		});
		this.props.onChange({target: {name: this.props.name, value: ''}});
	}

	componentDidMount() {
		const file = this.state.value;
		if (file !== '') {
			let parts = file.split('/');
			let user = parts[3];
			let application = parts[4];
			let filename = parts[5]
			let a = new Api(`upload/user/${user}/application/${application}/filename/${filename}`);
			a.Get().then((response) => {
				return response.json();
			}).then((json) => {
				this.setState({
					files: {
						...this.state.files,
						[file]: json,
					}
				});
			});
		}
	}

	render() {
		const { value, locale, onChange, readOnly, required, ...other } = this.props;
		const { i18n } = this.state;
		let downloads;
		if (readOnly && Object.keys(this.state.files).length === 0)
			return (
				<p className="text-center text-muted">{i18n[locale].noFile}</p>
			);

		return (
			<>
				<fieldset disabled={readOnly}>
					<FilePond
						{...other}
						allowMultiple={false}
						required={required ? required : false}
						onremovefile={this.handleRemove}
						acceptedFileTypes={this.props.filetype || undefined}
						allowFileSizeValidation={this.props.maxFileSize ? true : false}
						maxFileSize={this.props.maxFileSize || undefined}
						server={{
							process: {
								url: this.api.url,
								method: 'POST',
								headers: {
									'X-Csrf-Token': this.api.token,
								},
								credentials: 'same-origin',
								onload: this.handleLocationResponse
							},
							revert: {
								url: this.api.url,
								method: 'DELETE',
								headers: {
									'X-Csrf-Token': this.api.token,
								},
								credentials: 'same-origin'
							},
							restore: {
								url: `${this.api.url}/uuid`,
								method: 'GET',
								headers: {
									'X-Csrf-Token': this.api.token,
								},
								credentials: 'same-origin',
							},
							load: {
								url: `${this.api.url}/uuid/`,
								method: 'GET',
								headers: {
									'X-Csrf-Token': this.api.token,
								},
								credentials: 'same-origin',
							},
							fetch: {
								url: `${this.api.url}/uuid/`,
								method: 'GET',
								headers: {
									'X-Csrf-Token': this.api.token,
								},
								credentials: 'same-origin',
							}
						}}
						{...this.state.i18n[locale]}
					>
						{ Object.keys(this.state.files).map((key) => {
							let file = this.state.files[key];
							downloads = (
								<p className="text-right">
									<a className="d-inline-block text-info px-4 small" key={key} href={key} download target="_blank" rel="noopener noreferrer">i18n[download file]</a>
								</p>
							);
							return (<FileElem key={key} className="d-none" src={key} origin="local" name={file.name} size={file.size} type={file.type}/>);
						}) }
					</FilePond>
				</fieldset>
				{ downloads }
			</>

		);
	}
}

File.propTypes = {
	id: PropTypes.string,
	readOnly: PropTypes.bool,
	required: PropTypes.bool,
	name: PropTypes.string.isRequired,
	value: PropTypes.string.isRequired,
	locale: PropTypes.string,
	filetype: PropTypes.array,
	maxFileSize: PropTypes.string,
	onChange: PropTypes.func.isRequired,
};

export default File;
