import React, { Component } from 'react';
import { FormGroup, Input, Label } from 'reactstrap';
import PropTypes from 'prop-types';

class Radio extends Component {

	constructor(props) {
		super(props);
		this.state = {value: props.value}
		this.handleChange = this.handleChange.bind(this);
	}

	handleChange(event) {
		const target = event.target;
		this.setState({value: target.value});
		this.props.onChange({target: {name: this.props.name, value: target.value}});
	}

	render() {
		const {required, name, readOnly} = this.props;

		let input_field = this.props.text && Object.values(this.props.text).map((value) => {
			return (
				<FormGroup key={`form_group_${value}`} className="mb-1" check >
					<Label check >
						<Input
							type="radio"
							required={required}
							name={name}
							checked={this.state.value===value}
							value={value}
							onChange={this.handleChange}
							readOnly={readOnly}
						/>
						{` ${value}`}
					</Label>
				</FormGroup>
			);
		});

		return input_field;
	}

}

Radio.propTypes = {
	value: PropTypes.string.isRequired,
	required: PropTypes.bool.isRequired,
	name: PropTypes.string.isRequired,
	text: PropTypes.string.isRequired,
	onChange: PropTypes.func.isRequired,
	readOnly: PropTypes.bool,
};

export default Radio;
