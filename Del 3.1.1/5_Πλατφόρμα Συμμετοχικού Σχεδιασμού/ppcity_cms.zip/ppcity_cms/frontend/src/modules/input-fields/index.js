export { default as GeneralInput } from './components/generalInput';
export { default as Map } from './components/map';
export { default as OlMap } from './components/olmap';
export { default as PlainText } from './components/plaintext';
export { default as Radio } from './components/radio';
export { default as CheckBox } from './components/checkbox';
