import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Input } from 'reactstrap';

class GeneralInput extends Component {

	render() {
		const { options, ...other } = this.props;
		let selectOptions = options
			? Object.values(options).map(value => <option key={value} value={value}>{value}</option>)
			: undefined;

		if (selectOptions)
			return (
				<Input
					{...other}
					autoComplete="off"
				>
					<option value="">-----</option>
					{selectOptions}
				</Input>
			);

		return (
			<Input
				{...other}
				autoComplete="off"
			/>
		);
	}
}

GeneralInput.propTypes = {
	id: PropTypes.string,
	type: PropTypes.string.isRequired,
	required: PropTypes.bool,
	maxLength: PropTypes.number,
	name: PropTypes.string.isRequired,
	value: PropTypes.oneOfType([
		PropTypes.string,
		PropTypes.number
	]).isRequired,
	onChange: PropTypes.func,
	valid: PropTypes.string,
	readOnly: PropTypes.bool,
	options: PropTypes.object,
};

export default GeneralInput;
