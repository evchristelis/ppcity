import * as reducers from './ducks';
import { default as menuReducers, initialState as menuInitialState } from './ducks/ui/menu';
import * as components from './components';
import * as headerItems from './components/headerItems';

export default { reducers, components, headerItems, menuReducers, menuInitialState };
