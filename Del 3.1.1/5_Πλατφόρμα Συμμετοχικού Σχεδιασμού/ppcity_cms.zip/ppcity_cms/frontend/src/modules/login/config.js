import { default as routes } from './model/routes';
import { default as menuItems } from './menu';
import * as layout from './views/layout';
import * as modals from './views/modals/loginModal';

export default { ...routes, menuItems, layout, modals };
