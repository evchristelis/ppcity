import { default as Dashboard } from './views/dashboard';
import { default as routes } from './model/routes';
import { default as menuItems } from './menu';
import * as layout from './views/layout';

const dashboardItems = [Dashboard];

export default { ...routes, menuItems, layout, dashboardItems };
