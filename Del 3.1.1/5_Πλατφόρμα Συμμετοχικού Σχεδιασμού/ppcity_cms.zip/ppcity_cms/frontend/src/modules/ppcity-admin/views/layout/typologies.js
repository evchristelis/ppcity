import React, { Component } from 'react';

class Typologies extends Component {
	render() {
		return null;
	}
}

export default Typologies;
