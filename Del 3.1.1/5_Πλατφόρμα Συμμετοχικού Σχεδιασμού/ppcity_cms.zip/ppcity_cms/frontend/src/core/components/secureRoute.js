import * as React from 'react';
import { connect } from 'react-redux';
import { Route, Redirect } from 'react-router-dom';
import { hierarchy } from '../model/roles';

class SecureRoute extends React.Component {

	hasRights(role) {
		const { user } = this.props;
		let authenticated = (user && user.role && user.role !== '');
		if (!authenticated || !role)
			return false;
		return (hierarchy.indexOf(role) >= hierarchy.indexOf(user.role));
	}

	render() {
		let { role, ...rest } = this.props;
		if (this.hasRights(role)) {
			return <Route {...rest} />;
		} else {
			return <Redirect to='/login' />;
		}
	}
}

const mapStateToProps = (state) => ({
	user: state.profile.user
});

SecureRoute = connect(mapStateToProps)(SecureRoute);

export default SecureRoute;
