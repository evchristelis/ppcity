import { Api } from '../api';
import { pushNotification } from './notifications';
import { checkCookie } from './profile';


// Actions

const REQUESTING_VALIDATION = 'api/forms/validation/REQUESTING';
const FETCHED_VALIDATION = 'api/forms/validation/FETCHED';
const FAILED_REQUEST = 'api/forms/validation/FAILED';
const SET_VALIDATION_MSGS = 'forms/validation/validation_msgs/SET';
const SET_EMPTY_MSGS = 'forms/validation/validation_msgs/INIT';
const VALIDATE = 'forms/validation/CHECK';
const UNSAVED_DATA = 'forms/UNSAVED_DATA';
const SET_CONTENT = 'forms/content/SET';
const GET_CONTENT = 'forms/content/GET';
const REQUESTING_CONTENT = 'forms/content/REQUESTING';
const RESET = 'forms/content/RESET';
const SEND_CONTENT = 'forms/content/SEND';
const SUBMIT_CONTENT = 'forms/content/SUBMITTED';


// Initial state

const initialState = {
	validation: {
		pending: false,
		rules: {},
		status: '',
		errorMsg: ''
	},
	initialValues: {},
	validation_msgs: {},
	empty_msgs: {},
	unsaved_data: false,
	valid: false,
	content: {},
	pending: false,
	submitting: {},
	post: {},
	status: ''
};


// Reducer

export default (state=initialState, action) => {
	switch (action.type) {
		case REQUESTING_VALIDATION:
			return {
				...state,
				validation: {
					...state.validation,
					pending: action.pending
				}
			};

		case FETCHED_VALIDATION:
		case FAILED_REQUEST:
			return {
				...state,
				validation: {
					pending: action.pending,
					rules: action.rules,
					status: action.status,
					errorMsg: action.errorMsg
				}
			};

		case UNSAVED_DATA:
			return {
				...state,
				unsaved_data: action.unsaved_data
			};

		case SET_VALIDATION_MSGS:
			return {
				...state,
				validation_msgs: action.validation_msgs
			}

		case SET_EMPTY_MSGS:
			return {
				...state,
				empty_msgs: action.empty_msgs
			}

		case VALIDATE:
			return {
				...state,
				validation_msgs: action.validation_msgs,
				valid: action.valid
			}

		case SET_CONTENT:
			let this_content = (!state.content[action.scope] || state.content[action.scope] instanceof Array)
				? { [action.scope]: action.content }
				: { [action.scope]: { ...state.content[action.scope], ...action.content } };
			let this_state = {
				content: Object.assign(
					{},
					state.content,
					this_content
				)
			}
			if (this_content !== state.content[action.scope]) {
				this_state.post = Object.assign({}, state.post, {[action.scope]: true});
				this_state.initialValues = {
					...state.initialValues,
					[action.scope]: action.content
				};
			}
			return {
				...state,
				...this_state
			}

		case RESET:
			let content = Object.keys(state.content)
				.filter(scope => scope !== action.scope)
				.reduce((obj, scope) => ({
					...obj,
					[scope]: state.content[scope]
				}), {});
			let post = Object.keys(state.post)
				.filter(scope => scope !== action.scope)
				.reduce((obj, scope) => ({
					...obj,
					[scope]: state.post[scope]
				}), {});
			return {
				...state,
				content,
				post,
			}

		case REQUESTING_CONTENT:
			return {
				...state,
				pending: action.pending
			}

		case GET_CONTENT:
			return {
				...state,
				content: Object.assign({}, state.content, {[action.scope]: action.content}),
				pending: action.pending,
				post: Object.assign({}, state.post, {[action.scope]: false}),
				initialValues: Object.assign({}, state.initialValues, {[action.scope]: action.content})
			}

		case SEND_CONTENT:
			return {
				...state,
				submitting: {...state.submitting, [action.scope]: true}
			}

		case SUBMIT_CONTENT:
			content = action.status===200 ? {...state.content[action.scope], ...action.content} : state.initialValues[action.scope];
			return {
				...state,
				post: Object.assign({}, state.post, {[action.scope]: (state.post[action.status] && action.status!==200)}),
				initialValues: Object.assign({}, state.initialValues, {[action.scope]: content}),
				status: action.status,
				submitting: {...state.submitting, [action.scope]: false},
			}

		default:
			return state;
	}
}


// Action creators

const requestingValidation = () => ({
	type: REQUESTING_VALIDATION,
	pending: true
});

const fetchedValidation = (rules) => ({
	type: FETCHED_VALIDATION,
	pending: false,
	rules,
	status: 200,
	errorMsg: ''
});

const failedRequest = (status, errorMsg) => ({
	type: FAILED_REQUEST,
	pending: false,
	rules: {},
	status,
	errorMsg
});

const setValidationMsgs = (msgs) => ({
	type: SET_VALIDATION_MSGS,
	validation_msgs: msgs
});

const requestingContent = () => ({
	type: REQUESTING_CONTENT,
	pending: true
})

export const validate = (data, rules) => {
	let validation_msgs = {};
	let valid = true;
	Object.keys(rules).forEach((key) => {
		const rule = rules[key];
		if (data[key] && data[key] !== '') {
			let msg = ''
			if (rule.min_size)
				msg = data[key].length < rule.min_size ? `Το ελάχιστο μήκος είναι ${rule.min_size}.` : msg;
			if (rule.max_size)
				msg = data[key].length > rule.max_size ? `Το μέγιστο μήκος είναι ${rule.max_size}.` : msg;
			if (msg==='' && rule.validation) {
				let regex = new RegExp('^' + rule.validation + '$');
				msg = regex.test(data[key]) ? '' : rule.message;
			}
			validation_msgs[key] = msg;
			valid = (msg !== '') ? false : valid;
		}
	});
	return {
		type: VALIDATE,
		validation_msgs,
		valid
	};
}

export const unsavedData = (cond) => ({
	type: UNSAVED_DATA,
	unsaved_data: cond
});

export const setContent = (scope, content) => ({
	type: SET_CONTENT,
	scope,
	content
});

export const resetContent = (scope) => ({
	type: RESET,
	scope
});

/**
 * Replace null values with empty string.
 * The replacement occurs only in first level.
 *
 * @param  {object} data
 * @return {object}
 */
const convertNull = (data) => {
	if (data instanceof Array)
		return data;
	let nulls = Object.keys(data)
		.filter((key) => data[key] === null)
		.reduce((obj, key) => ({
			...obj,
			[key]: ''
		}), {});
	return {...data, ...nulls};
}

// Thunk action creators

export const getContent = (request, scope) => (dispatch, getState) => {
	let promise = new Promise((resolve, reject) => {
		dispatch( checkCookie() ).then(() => {
			dispatch(requestingContent());
			let a = new Api(request);
			let status;
			a.Get().then((response) => {
				status = response.status;
				return response.json();
			}).then((initial_content) => {
				if (status === 200) {
					let content = convertNull(initial_content);
					dispatch({
						type: GET_CONTENT,
						scope,
						content,
						pending: false
					});
				}
				resolve();
			});
		});
	});

	return promise;
}

export const getValidation = (scope, fields='') => (dispatch, getState) => {
	dispatch(requestingValidation());
	let url = `validation/category/${scope}`;
	url += fields!=='' ? '/fields/' + fields : '';
	let a = new Api(url);
	let status;
	a.Get().then((response) => {
		status = response.status;
		return response.json();
	}).then((json) => {
		if (status === 200) {
			dispatch(fetchedValidation(json));
			let keys = {};
			Object.keys(getState().forms.validation.rules).forEach((key) => {keys[key] = ''});
			dispatch(setValidationMsgs(keys));
		} else {
			dispatch(failedRequest(status, json.Error));
		}
	});
}

export const submit = (request, scope, method=undefined) => (dispatch, getState) => {
	let promise = new Promise((resolve, reject) => {
		dispatch( checkCookie() ).then(() => {
			dispatch({
				type: SEND_CONTENT,
				scope,
			});
			let a = new Api(request);
			let requestPromise;
			let data = getState().forms.content[scope];
			if ( (method && method==='Put') || !getState().forms.post[scope] ) {
				const initialValues = getState().forms.initialValues[scope];
				if (data instanceof Array) {
					data = data.filter((entry, index) =>
						entry!==initialValues[index]
					);
				} else {
					data = Object.keys(data)
						.filter(key => data[key]!==initialValues[key])
						.reduce((obj, key) => ({
							...obj,
							[key]: data[key]
						}), {});
				}
			}
			if ((data instanceof Array && data.length === 0) || (data instanceof Object && Object.keys(data).length === 0)) {
				resolve();
				return promise;
			}
			if ((method && method==='Post') || method==='Put') {
				requestPromise = a[method](data);
			} else {
				requestPromise = getState().forms.post[scope] ? a.Post(data) : a.Put(data);
			}
			requestPromise.then((response) => {
				dispatch({
					type: SUBMIT_CONTENT,
					scope,
					content: data,
					status: response.status,
				});
				if (response.status === 200) {
					dispatch(pushNotification({body: 'successful update', type: 'success'}));
				} else {
					dispatch(pushNotification({body: 'action denied', type: 'warning', status: response.status}));
				}
				resolve();
			});
		});
	});

	return promise;
}
