import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {
	Button,
	FormGroup,
	FormText,
	Label,
	Input,
	Modal,
	ModalHeader,
	ModalBody,
	ModalFooter
} from 'reactstrap';

import T from 'modules/i18n';
import { updateData } from '../../ducks/update';
import { toggleModal, toggleModalSubmit } from '../../ducks/ui/modal';

class ChangePassword extends Component {

	render() {

		const verifyPassword = () => {
			let pass = document.getElementById('new_password').value;
			let re = /^[0-9a-zA-Z_!$@#^&]{6,}$/;
			if (pass.length < 6 || !re.test(pass)) {
				this.props.toggleModalSubmit(false);
				return;
			}
			let pass2 = document.getElementById('verify_password').value;
			this.props.toggleModalSubmit(pass===pass2);
		};

		const submitPassword = (pass) => {
			this.props.toggleModal();
			this.props.updateData( 'profile', { password: pass } );
		};

		return (
			<Modal isOpen={this.props.modalOpen} toggle={this.props.toggleModal} className="modal-sm">
				<ModalHeader toggle={this.props.toggleModal}><T>change password</T></ModalHeader>
				<ModalBody>
					<FormGroup>
						<Label htmlFor="new_password"><T>new password</T></Label>
						<Input onChange={verifyPassword} type="password" id="new_password"/>
					</FormGroup>
					<FormGroup>
						<Label htmlFor="verify_password"><T>repeat password</T></Label>
						<Input onChange={verifyPassword} type="password" id="verify_password"/>
					</FormGroup>
					<FormGroup>
						<FormText>
							<dl>
								<li><T>password length</T></li>
								<li><T>acceptable passwords</T></li>
							</dl>
						</FormText>
					</FormGroup>
				</ModalBody>
				<ModalFooter>
					<Button
						disabled={!this.props.modalSubmitEnabled}
						color="primary"
						onClick={(e) => {submitPassword(document.getElementById('new_password').value)}}
					>
						<T>save</T>
					</Button>
					{' '}
					<Button
						color="secondary"
						onClick={this.props.toggleModal}><T>cancel</T>
					</Button>
				</ModalFooter>
			</Modal>
		);
	}
}

const mapStateToProps = (state) => ({
	modalOpen: state.ui.modal.modalOpen,
	modalSubmitEnabled: state.ui.modal.modalSubmitEnabled,
});

const mapDispatchToProps = (dispatch) => bindActionCreators({
	updateData,
	toggleModal,
	toggleModalSubmit,
}, dispatch);

ChangePassword = connect(mapStateToProps, mapDispatchToProps)(ChangePassword);

export default ChangePassword;