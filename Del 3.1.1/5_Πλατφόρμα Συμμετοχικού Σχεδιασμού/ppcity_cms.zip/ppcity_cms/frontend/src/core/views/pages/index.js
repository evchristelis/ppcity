export { default as Page404 } from './page404';
