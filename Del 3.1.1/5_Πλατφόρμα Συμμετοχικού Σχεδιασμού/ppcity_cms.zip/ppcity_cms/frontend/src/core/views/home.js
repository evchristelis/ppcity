import * as React from 'react';
import { connect } from 'react-redux';
import { Switch, Route, Redirect } from 'react-router-dom';

import { default as coreRoutes } from '../model/routes';
import { routes as moduleRoutes } from 'modules';
import { ErrorBoundary, Loading } from '../components';
import SecureRoute from '../components/secureRoute';
import { Page404 } from './pages';
import * as coreLayout from './layout';
import * as modulesLayout from 'modules/layout';
import { getProfile, pending } from '../ducks/profile';
import Sidebar from './layout/sidebar';

const Components = { ...coreLayout, ...modulesLayout.default };
const routes = { ...coreRoutes, ...moduleRoutes };

class Home extends React.Component {

	constructor(props) {
		super(props);
		this.state = { module: null };
	}

	componentDidMount () {
		this.loadTemplate(this.props.loggedin);
	}

	componentDidUpdate(prevProps) {
		if (prevProps.loggedin !== this.props.loggedin)
			this.loadTemplate(this.props.loggedin);
	}

	loadTemplate(loggedin) {
		let promise = loggedin ? import('coreui/templates/default') : import('default-theme/templates/front');
		promise.then(module => {
			this.setState({module: module.default})
		});
	}

	render() {

		if (this.props.pending || !this.props.location)
			return <Loading/>;
		const {module: Template} = this.state;
		if (!Template)
			return null;

		return (
			<ErrorBoundary>
				<Template routes={routes} sidebar={Sidebar}>
					<ErrorBoundary>
						<Switch>
							{this.props.loggedin &&
								<Redirect from='/login' to='/admin/dashboard' />
							}
							{ Object.keys(routes).map((url) => {
								let route = routes[url];
								const exact = route.exact ? {exact: true} : {};
								if (route.to)
									return <Redirect key={url} from={url} to={route.to} {...exact} />;

								if (!Components[route.component])
									return null;

								let RouteComponent = Components[route.component];

								if (route.role)
									return <SecureRoute key={url} path={url} component={RouteComponent} role={route.role} {...exact} />;

								if (route.props)
									return <Route key={url} path={url} render={(props) => <RouteComponent {...route.props} {...props} />} {...exact} />;

								return <Route key={url} path={url} component={RouteComponent} {...exact} />;
							})};
							<Route component={Page404} />
						</Switch>
						{/*<LoginModal isOpen={this.props.time_out} />*/}
						{ this.props.modal.generalModal &&
							<div>
								{this.props.modal.component}
							</div>
						}
					</ErrorBoundary>
				</Template>
			</ErrorBoundary>
		);
	}
}

const mapStateToProps = (state) => ({
	loggedin: state.profile.loggedin,
	sidebarOpen: state.ui.menu.sidebarOpen,
	sidebarStyle: state.ui.menu.sidebarStyle,
	sidebarMinimized: state.ui.menu.sidebarMinimized,
	sidebarMobileShow: state.ui.menu.sidebarMobileShow,
	hideAsideMenu: state.ui.menu.hideAsideMenu,
	notifications: state.notifications.messages,
	modal: state.ui.modal,
	profile: getProfile(state),
	pending: pending(state),
	time_out: state.profile.time_out
});

Home = connect(mapStateToProps)(Home);

export default Home;
