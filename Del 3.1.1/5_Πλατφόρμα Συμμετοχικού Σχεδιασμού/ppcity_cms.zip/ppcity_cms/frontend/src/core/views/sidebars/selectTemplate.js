import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {
	Nav, NavItem, NavLink,
	TabContent, TabPane, Table,
	Form, FormGroup, Input, Label, Button,
	InputGroup, InputGroupAddon
} from 'reactstrap';

import { StaticRoutes, DynamicRoutes} from '../../model/routes';
import { buildPath, getParameters } from '../../model/lib/urlTools';
import { getContent, setContent } from '../../ducks/forms';
import { deleteData } from '../../ducks/update';
import T from 'modules/i18n';
import { Alert } from '../modals';
import { toggleModal } from '../../ducks/ui/modal';
import { characterConverter } from '../../model/lib';

class SelectTemplate extends Component {

	constructor(props) {
		super(props);
		this.state = {
			activeTab: '0',
			current: '',
			newCategory: '',
			selected: [],
			lastId: -1,
		}
		this.actions = bindActionCreators({toggleModal}, props.dispatch);

		this.toggle = this.toggle.bind(this);
		this.handleSelect = this.handleSelect.bind(this);
		this.handleInputChange = this.handleInputChange.bind(this);
		this.newCategory = this.newCategory.bind(this);
		this.handleCheckbox = this.handleCheckbox.bind(this);
		this.handleDelete = this.handleDelete.bind(this);
	}

	toggle(tab) {
		if (this.state.activeTab !== tab)
			this.setState({activeTab: tab});
	}

	handleSelect(event) {
		const value = event.target.value;
		this.setState({
			current: value
		});
		let path = value==='' ? StaticRoutes.Templates : buildPath(DynamicRoutes.Templates, [value]);
		this.props.history.push(path);
	}

	handleInputChange(event) {
		let value = event.target.value;
		value = value.toLowerCase();
		value = value.split(' ').join('_');
		value = value.split('-').join('_');
		value = characterConverter(value);
		if (!/^([a-zA-Z0-9_]*)$/.test(value))
			return;
		this.setState({newCategory: value});
	}

	newCategory(event) {
		event.preventDefault();
		this.props.dispatch( setContent('template_list', {[this.state.lastId]: this.state.newCategory}) );
		let path = buildPath(DynamicRoutes.Templates, [this.state.newCategory]);
		this.setState({newCategory: '', current: this.state.newCategory, activeTab: '0', lastId: this.state.lastId-1});
		this.props.history.push(path);
	}

	handleCheckbox(event) {
		const { checked, value } = event.target;
		if (checked) {
			this.setState({selected: [...this.state.selected, value]});
		} else {
			const selected = this.state.selected.filter(element => element !== value);
			this.setState({selected});
		}
	}

	handleDelete() {
		if (this.state.selected.length === 0)
			return;
		let selected = this.state.selected.join(';');
		this.props.dispatch(deleteData(`admin/template/type/${selected}`)).then(() => {
			if (this.props.deleteStatus === 200) {
				this.initiate();
				if (this.state.selected.includes(this.state.current))
					this.props.history.push(StaticRoutes.Templates);
				this.setState({selected: []});
			}
		});
	}

	componentDidMount() {
		this.initiate();
	}

	componentDidUpdate(prevProps) {
		// Provide positive id in case a temp type has been saved
		if (prevProps.submitting.template && !this.props.submitting.template)
			if (this.props.httpStatus === 200) {
				const { content, dispatch } = this.props;
				let ids = Object.keys(content.template_list);
				const current_id = ids.filter(id => content.template_list[id] === this.state.current);
				if (current_id[0] < 0) {
					const new_id = Math.max.apply(Math, ids) + 1;
					delete content.template_list[current_id];
					dispatch( setContent('template_list', {[new_id]: this.state.current}) );
				}
			}
	}

	initiate() {
		this.props.dispatch( getContent('admin/template/fields/type', 'template_list') );
		let params = getParameters(this.props.location.pathname);
		this.setState({
			current: (params.template)
				? params.template
				: '',
		});
	}

	render() {

		const { content } = this.props;
		const { messages } = this.props.i18n || {messages: {}};
		if ( !content.template_list )
			return null;
		const { template_list } = content;

		return (
			<React.Fragment>
				<Nav tabs>
					<NavItem>
						<NavLink
							className={this.state.activeTab==='0' ? 'active text-info p-2' : 'border border-secondary p-2'}
							onClick={() => { this.toggle('0'); }}
						>
							<T>templates</T>
						</NavLink>
					</NavItem>
					<NavItem>
						<NavLink
							className={this.state.activeTab==='1' ? 'active text-info p-2' : 'border border-secondary p-2'}
							onClick={() => { this.toggle('1'); }}
						>
							<T>administration</T>
						</NavLink>
					</NavItem>
				</Nav>

				<TabContent activeTab={this.state.activeTab} className="scroller mx-2 mt-2">
					{/*templates list*/}
					<TabPane tabId="0">
						<Form>
							<FormGroup>
								<Input
									type="select"
									value={this.state.current}
									onChange={this.handleSelect}
								>
									<option value="">---{messages['select template'] || 'select template'}---</option>
									{ Object.keys(template_list).map((id) =>
										<option key={`templates_${id}`} value={template_list[id]}>
											{{/*eslint-disable-next-line*/}}
											{id<0 ? '-> ' : ''}{template_list[id]} {id<0 ? ' (' + messages.temp || 'temp' + ')' : ''}
										</option>
									) }
								</Input>
							</FormGroup>
						</Form>
					</TabPane>
					{/*Administration*/}
					<TabPane tabId="1">
						<Form onSubmit={this.newCategory}>
							<FormGroup tag="fieldset">
								<Label htmlFor="new_category_input"><T>new category</T></Label>
								<InputGroup>
									<Input id="new_category_input" value={this.state.newCategory} onChange={this.handleInputChange}/>
									<InputGroupAddon addonType="append">
										<Button type="submit"><i className="fa fa-plus"/></Button>
									</InputGroupAddon>
								</InputGroup>
							</FormGroup>
						</Form>
						<Table>
							<thead>
								<tr><th><T>bulk delete</T></th></tr>
							</thead>
							<tbody>
								{ Object.keys(template_list).map(id =>
									<tr key={`checkbox_${id}`}>
										<td>
											<FormGroup check>
												<Input
													id={`checkbox_${id}`}
													type="checkbox"
													value={template_list[id]}
													checked={this.state.selected.includes(template_list[id])}
													onChange={this.handleCheckbox}
													disabled={id<0}
												/>
												<Label htmlFor={`checkbox_${id}`} check>{template_list[id]}</Label>
											</FormGroup>
										</td>
									</tr>
								)}
							</tbody>
							<tfoot>
								<tr>
									<td className="text-center">
										<Button
											color="danger"
											type="submit"
											onClick={
												() => this.actions.toggleModal(true,
													<Alert
														toggle={this.actions.toggleModal}
														title="drop confirm"
														message="do you wish to continue"
														onConfirm={() => this.handleDelete()}
													/>
												)
											}
										>
											<T>delete selected</T>
										</Button>
									</td>
								</tr>
							</tfoot>
						</Table>
					</TabPane>
				</TabContent>
			</React.Fragment>
		);
	}
}

const mapStateToProps = (state) => ({
	i18n: state.i18n,
	content: state.forms.content,
	submitting: state.forms.submitting,
	deleteStatus: state.update.status,
	httpStatus: state.forms.status,
});

SelectTemplate = connect(mapStateToProps)(SelectTemplate);

export default SelectTemplate;
