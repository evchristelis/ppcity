import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {
	Row,
	Col,
	Button,
	Card,
	CardHeader,
	CardFooter,
	CardBody
} from 'reactstrap';

import ChangePassword from './changePassword';
import Alert from '../modals/alert';
import { Prompt } from '../../components';
import { ProfileForm } from '../forms';
import { toggleModal } from '../../ducks/ui/modal';
import { unsavedData } from '../../ducks/forms';
import T from 'modules/i18n';

class Profile extends Component {

	render() {

		const { toggleModal, pending, unsavedData } = this.props;

		return (
			<div className="animated fadeIn">
				<Row>
					<Col xs="12" lg="12">
						<Card>
							<CardHeader>
								<strong><T>user profile</T></strong>
							</CardHeader>
							<CardBody className={pending ? 'semi-transparent' : undefined}>
								<ProfileForm
									profile={true}
									pending={pending}
									unsubmitted={unsavedData}
								/>
							</CardBody>
							<CardFooter>
								<Button
									onClick={() => toggleModal(true, <ChangePassword/>)}
									type="button"
									size="sm"
									color="primary"
								>
									<i className="fa fa-key"></i> <T>change password</T>
								</Button>
							</CardFooter>
						</Card>
					</Col>
				</Row>
				<Prompt
					when={this.props.unsaved_data}
					action={(onConfirm) => {
						toggleModal(true,
							<Alert
								onConfirm={onConfirm}
								toggle={toggleModal}
								message="unsave_data_alert"
								title="confirm navigation"
							/>
						);
					}}
				/>
			</div>
		);
	};
}

const mapStateToProps = (state) => ({
	profile: state.profile.user,
	pending: state.update.pending,
	unsaved_data: state.forms.unsaved_data,
});

const mapDispatchToProps = (dispatch) => bindActionCreators({
	toggleModal,
	unsavedData,
}, dispatch);

Profile = connect(mapStateToProps, mapDispatchToProps)(Profile);

export default Profile;
