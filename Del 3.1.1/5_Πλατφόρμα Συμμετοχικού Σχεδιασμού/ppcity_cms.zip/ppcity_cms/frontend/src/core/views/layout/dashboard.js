import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Row } from 'reactstrap';

import { getData } from 'core/ducks/update';
import { Loading } from 'core/components';
import { dashboardItems } from 'modules';

import * as roles from '../../model/roles';

class Dashboard extends Component {

	componentDidMount() {
		const { dispatch, role } = this.props;
		if (role && role !== roles.GUEST)
			dispatch( getData('stats') );
	}

	componentDidUpdate(prevProps) {
		const { dispatch, role } = this.props;
		if (!prevProps.role && role && role !== roles.GUEST)
			dispatch( getData('stats') );
	}

	render() {
		let { pending, stats } = this.props;
		if (this.props.role !== roles.GUEST && pending)
			return (<Loading/>);

		return (
			<Row className="mt-4">
				{ dashboardItems.map((Item, index) => <Item key={`dashboard_item_${index}`} />) }
			</Row>
		);
	}
}

const mapStateToProps = (state) => ({
	role: state.profile.user.role,
	stats: state.update.response,
	pending: state.update.pending,
});

Dashboard = connect(mapStateToProps)(Dashboard);

export default Dashboard;
