import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { connect } from 'react-redux';

import { openAside, closeAside} from '../../ducks/ui/menu';

import * as coreSidebars from '../sidebars';
import { sidebars as modulesSidebars } from 'modules/sidebars';

const Sidebars = {...coreSidebars, ...modulesSidebars};

/**
 * A component for displaying contextual information based on the current
 * router state
 *
 * @class ContextSidebar
 * @extends {React.Component}
 */
class ContextSidebar extends Component {

	constructor(props) {
		super(props);
		this.openedAutomatically = false;
		this.state = {
			context: null,
		}
	}

	_getComponent() {
		if (this.props.content && Sidebars[this.props.content])
			return Sidebars[this.props.content];
		return null;
	}

	checkToOpen(context) {
		this.setState({
			context,
		}, () => {
			if ( this.state.context && !this.props.asideIsOpen ) {
				this.props.dispatch( openAside() );
				this.openedAutomatically = true;
			}
		});
	}

	componentDidMount() {
		this.checkToOpen(this._getComponent());
	}

	componentDidUpdate(prevProps) {
		if (prevProps.location.pathname !== this.props.location.pathname) {
			let context = this._getComponent();
			if (context === this.state.context)
				return;
			if (this.openedAutomatically) {
				this.props.dispatch( closeAside() );
				this.openedAutomatically = false;
			}
			this.checkToOpen(context);
		}
	}

	componentWillUnmount() {
		if (this.openedAutomatically)
			this.props.dispatch( closeAside() );
	}

	render() {
		let ContextComponent = this._getComponent();
		let Generic = Sidebars.GenericAside;

		return (
			<div style={{ height: '100%' }}>
				{ContextComponent
					? <ContextComponent {...this.props} />
					: <Generic />
				}
			</div>
		);
	}

}

const mapStateToProps = (state) => ({
	asideIsOpen: !state.ui.menu.hideAsideMenu
});

ContextSidebar = connect(mapStateToProps)(ContextSidebar);

export default withRouter(ContextSidebar);
