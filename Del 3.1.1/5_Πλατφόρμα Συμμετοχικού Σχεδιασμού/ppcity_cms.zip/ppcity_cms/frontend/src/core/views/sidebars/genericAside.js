import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Nav, NavItem, NavLink, TabContent, TabPane } from 'reactstrap';
import { Link } from 'react-router-dom';
import Tree from 'react-ui-tree';

import * as roles from '../../model/roles';
import { SecureContent } from '../../components';
import T from 'modules/i18n';
import { requestData } from '../../ducks/list';

class GenericAside extends Component {

	_isMounted = false;

	constructor(props) {
		super(props);
		this.state = {
			activeTab: '0',
			tree: null
		};
		this.activeRef = React.createRef();

		this.toggle = this.toggle.bind(this);
		this.renderNode = this.renderNode.bind(this);
		this.stopPropagation = this.stopPropagation.bind(this);
	}

	toggle(tab) {
		if (this.state.activeTab !== tab)
			this.setState({activeTab: tab});
	}

	renderNode(node) {
		let rendered_node;
		if (node.path) {
			rendered_node = (
				<Link to={node.path} target="_blank">
					{node.module}
				</Link>
			);
		} else {
			rendered_node = (<span>{node.module}</span>);
		}
		return rendered_node;
	}

	stopPropagation(event) {
		event.stopPropagation();
	}

	componentDidMount() {
		this._isMounted = true;
		if (this.props.role && this.props.role !== roles.GUEST) {
			document.addEventListener("mousemove", this.stopPropagation);
		}
	}

	componentWillUnmount() {
		this._isMounted = false;
		if (this.props.role !== roles.GUEST)
			document.removeEventListener("mousemove", this.stopPropagation);
	}

	render() {
		if (!this.props.role || this.props.login_pending || this.props.role === roles.GUEST)
			return null;

		return (
			<SecureContent role={roles.REVIEWER}>
				<React.Fragment>
					<Nav tabs>
						<NavItem>
							<NavLink
								className={this.state.activeTab==='0' ? 'active text-info p-2' : 'border border-secondary p-2'}
								onClick={() => { this.toggle('0'); }}
							>
								<T>template files</T>
							</NavLink>
						</NavItem>
					</Nav>
					<TabContent activeTab={this.state.activeTab} className="scroller mx-2 mt-2">
						<TabPane tabId="0">
							{ this.state.tree &&
								<Tree
									paddingLeft={10}
									tree={this.state.tree}
									onChange={() => {}}
									renderNode={this.renderNode}
									isNodeCollapsed={true}
								/>
							}
						</TabPane>
					</TabContent>
				</React.Fragment>
			</SecureContent>
		);
	}

}

const mapStateToProps = (state) => ({
	files: state.list.files.data,
	files_pending: state.list.files.pending,
	role: state.profile.user.role,
	login_pending: state.profile.login_pending,
});

GenericAside = connect(mapStateToProps)(GenericAside);

export default GenericAside;
