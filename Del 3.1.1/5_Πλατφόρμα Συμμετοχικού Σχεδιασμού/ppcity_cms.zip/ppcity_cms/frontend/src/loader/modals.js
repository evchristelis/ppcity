import config from  '../../package.json';

let modals = [];
if (config.modules)
	config.modules.forEach((module) => {
		const content = require(`../modules/${module}/config`);
		modals = { ...modals, ...content.modals };
	});

export default {...modals};
