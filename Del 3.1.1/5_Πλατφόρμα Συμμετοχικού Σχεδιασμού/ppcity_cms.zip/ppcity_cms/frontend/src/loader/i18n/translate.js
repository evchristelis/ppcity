import React from 'react';
import config from '../../../package.json';
import components from '../components';

if (!config.multilingual || typeof components.T != 'function')
	components.T = React.Fragment;

export default components.T;
