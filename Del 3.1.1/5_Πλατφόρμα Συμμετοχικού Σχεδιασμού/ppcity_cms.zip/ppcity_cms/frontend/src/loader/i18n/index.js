export { default } from './translate';
export { default as getLocale } from './getLocale';
