import config from  '../../package.json';

export let routes = {};
if (config.modules)
	config.modules.forEach((module) => {
		const content = require(`../modules/${module}/config`);
		routes = { ...routes, ...content.routes };
	});
