import config from  '../../package.json';

let layout = {};
if (config.modules)
	config.modules.forEach((module) => {
		try {
			const content = require(`../modules/${module}/config`);
			layout = { ...layout, ...content.default.layout };
		} catch {}
	});

export default { ...layout };
