import config from  '../../package.json';

export let sidebars = {};
if (config.modules)
	config.modules.forEach((module) => {
		const content = require(`../modules/${module}/config`);
		if (content.default && content.default.sidebars) {
			sidebars = { ...sidebars, ...content.default.sidebars };
		}
	});
